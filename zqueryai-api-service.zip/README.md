# zQueryAI API Service

## 🚀 Project Overview

`zQueryAI API` is a **FastAPI-based microservice** that powers GenAI capabilities for contextual document-based query and summarization workflows. It is designed to operate as a backend service for applications that need to:

- **Ingest structured/unstructured markdown content**
- **Embed and store semantic chunks in Qdrant**
- **Perform contextual retrieval and LLM-based chat**
- **Support multi-product, multi-version filtering and analysis**

This backend works seamlessly with apps like `zRelease`, `zInsights`, or any React frontend that consumes its `/upsert-context` and `/chat` endpoints.

---

## 📦 Architecture Overview

```
              ┌──────────────┐
              │  Frontend UI │
              └──────┬───────┘
                     │ REST API
          ┌──────────▼──────────────┐
          │ zQueryAI FastAPI Server │
          ├──────────┬──────────────┤
  Upsert →│ /api/upsert-context     │
   Chat → │ /api/chat               │
          └──────────┬──────────────┘
                     │
    ┌────────────────┴─────────────┐
    │        Core Components       │
    │ ┌────────────┐ ┌───────────┐ │
    │ │ Embedder   │ │ Retriever │ │
    │ └────────────┘ └───────────┘ │
    └────────┬─────────────┬───────┘
             │             │
        ┌────▼──┐      ┌───▼────┐
        │ Qdrant│      │ Azure  │
        │ Vector│      │ OpenAI │
        └───────┘      └────────┘
```

---

## 🧠 Key Features

- 🔍 **Contextual Search:** Vector similarity retrieval using Qdrant
- 💬 **Context-aware Chat:** GPT-4o-powered chat using retrieved markdown chunks
- 📄 **Markdown Upsert:** Embeds and stores structured text with metadata
- 🔐 **Multi-key API Access:** Supports internal and partner API keys via `x-api-key`

---

## 🧰 Tech Stack

- **Framework:** Python 3.10+ with FastAPI
- **Vector DB:** Qdrant
- **LLM:** Azure OpenAI GPT-4o
- **Embedding Model:** `text-embedding-3-small` (Azure)
- **Dependencies:** See [`requirements.txt`](./requirements.txt)

---

## 📁 Folder Structure

```
zqueryai-api-service/
│
├── app/
│   ├── main.py                # App entry point
│   ├── config.py              # Env config
│   ├── router.py              # Registers API routes
│   ├── schemas.py             # Pydantic models
│   ├── prompts.py             # Prompt templates (optional)
│   ├── auth.py                # API key authorization
│   ├── routes/
│   │   ├── upsert.py          # /api/upsert-context route
│   │   └── chat.py            # /api/chat route
│   └── utils/
│       ├── embedder.py        # Embedding logic + Qdrant upsert
│       └── retriever.py       # Contextual chunk retrieval
│
├── .env                       # Environment variables (not committed)
├── requirements.txt           # Python dependencies
```

---

## ⚙️ Environment Configuration

Create a `.env` file in the root directory:

```env
# Azure OpenAI
AZURE_OPENAI_KEY=your_azure_openai_key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com
AZURE_OPENAI_EMBEDDINGS_MODEL=text-embedding-3-small
AZURE_OPENAI_COMPLETION_MODEL=gpt-4o
AZURE_OPENAI_EMBEDDINGS_API_VERSION=2024-02-15-preview
AZURE_OPENAI_COMPLETIONS_API_VERSION=2024-02-15-preview

# Qdrant
QDRANT_ENDPOINT=http://localhost:6333
QDRANT_API_KEY=your_qdrant_key
COLLECTION_NAME=your_default_collection_name

# Auth
API_KEYS=key1,key2,partnerKey
```

---

## 🧪 Local Development

### 1. 🔧 Install Python dependencies

```bash
python -m venv venv
source venv/bin/activate  # or .\venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### 2. ⚙️ Set up `.env`

Refer to the previous section and create your `.env`.

### 3. 🚀 Run the app

```bash
uvicorn app.main:app --reload
```

API will be available at `http://localhost:8000`

---

## 🔐 Authentication

All API routes require an `x-api-key` header with a valid API key defined in `.env`.

```http
x-api-key: your_api_key
```

---

## 🧵 API Endpoints

### 1. `POST /api/upsert-context`

> Ingests markdown content and stores it in Qdrant for semantic search.

#### Payload:
```json
{
  "markdown": "# Your source converted to markdown...", // Required
  "source": "source_doc_name", // Optional
  "version": "source_doc_version", // Optional
  "collection": "qdrant_collections_name" // Required
}
```

#### Response:
```json
{
  "message": "Context successfully upserted",
  "totalChunks": 8,
  "collection": "zqueryai_rag_collection_12345"
}
```

---

### 2. `POST /api/chat`

> Retrieves top-k context chunks and invokes Azure OpenAI to answer the question.

#### Payload:
```json
{
  "query": "What are the known defects in this release?", // Required
  "collection": "zqueryai_rag_collection_12345", // Required
  "filters": {
    "source": ["source_doc_name"]
  } // Optional
}
```

#### Response:
```json
{
  "response": "The known defects include..."
}
```

---

## 🧠 Embedding Strategy

- Tokenization handled via `tiktoken`
- Markdown is chunked and embedded using Azure’s `text-embedding-3-small`
- Chunks are upserted into Qdrant collections scoped by `source` and `version` and any other optinal metadata that is treated as filters

---

## 📌 Future Enhancements

- ✅ Persistent MongoDB storage of queries and summaries
- ✅ Optional markdown-to-JSON transformation pre-chat
- 🔄 Dynamic chunk merging with scoring
- 📊 Response scoring and tagging
- 🌐 Integration with upstream LLM pipelines like zRelease, zInsights
