# main.py

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from app.router import router
from fastapi.middleware.cors import CORSMiddleware
import uvicorn, logging
from app.config import (
    QDRANT_ENDPOINT,
    QDRANT_API_KEY,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION
)
 
# Create FastAPI app instance
app = FastAPI(title="RAG Assistant API", version="1.0")
 
# Optional: Add CORS middleware (important if calling from frontend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or restrict to specific origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
 
# Register routes
app.include_router(router)
 
# Optional health check
@app.get("/")
def home():
    return {"message": "GenAI RAG API is running"}

# Test connection endpoint
@app.get("/test_connection")
async def test_connection():
    results = {}

    # Test Azure OpenAI Connection
    try:
        from openai import AzureOpenAI
        azure_client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        azure_models = azure_client.models.list()
        results['azure_openai'] = {'status': 'success', 'models': [model.id for model in azure_models.data]}
    except Exception as e:
        results['azure_openai'] = {'status': 'error', 'message': str(e)}

    # Test Qdrant Connection
    try:
        from qdrant_client import QdrantClient
        qdrant_client = QdrantClient(
            url=QDRANT_ENDPOINT,
            api_key=QDRANT_API_KEY,
            prefer_grpc=False,
            https=True,
            timeout=60,
            verify=False
        )
        collections = qdrant_client.get_collections()
        results['qdrant'] = {'status': 'success', 'collections': [c.name for c in collections.collections]}
    except Exception as e:
        results['qdrant'] = {'status': 'error', 'message': str(e)}

    return JSONResponse(content=results)


if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("uvicorn.error")

@app.on_event("startup")
async def startup_event():
    logger.info("Application startup")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Application shutdown")
