# app/schemas.py - Enhanced version with link support and array filtering

from typing import Optional, List, Dict, Union, Any
from pydantic import BaseModel, Field, validator

# ✅ FIXED: Allow arrays and nested dictionaries in metadata and filters
MetaValue = Union[str, int, float, bool, List[str], List[int], List[float], Dict[str, Any], None]

# ✅ Link-related models (unchanged from your version)
class LinkInfo(BaseModel):
    url: str = Field(..., description="The hyperlink URL")
    anchor_text: str = Field(default="", description="The display text of the hyperlink")
    link_type: str = Field(default="hyperlink", description="Type of link: 'hyperlink', 'explicit'")
    context: str = Field(default="", description="Surrounding text context")

class LinksSummary(BaseModel):
    total_links: int = Field(default=0, description="Total number of links found across all documents")
    has_crawlable_links: bool = Field(default=False, description="Whether any crawlable links were found")
    links_by_document: Dict[str, List[LinkInfo]] = Field(
        default_factory=dict,
        description="Links organized by source document filename"
    )

# ✅ File metadata model
class FileMetadata(BaseModel):
    source: str = Field(..., example="document.pdf", description="Source filename of the extracted document")

# ✅ Enhanced ExtractedDocument with links support
class ExtractedDocument(BaseModel):
    markdown: str = Field(
        ..., 
        description="Extracted Markdown content from the file",
        example="## Project Overview\n\nThis document contains project specifications..."
    )
    metadata: FileMetadata = Field(
        ..., 
        description="Metadata containing source information for the extracted file"
    )
    links: List[LinkInfo] = Field(
        default_factory=list,
        description="List of hyperlinks found in this document"
    )

# ✅ Enhanced ExtractResponse with links summary
class ExtractResponse(BaseModel):
    documents: List[ExtractedDocument] = Field(
        ..., 
        description="List of extracted documents with markdown content, metadata, and links"
    )
    tokens_used: int = Field(
        ..., 
        description="Total tokens consumed by OCR operations across all files. Returns 0 if no OCR was performed.",
        example=245
    )
    links_summary: Optional[LinksSummary] = Field(
        default=None,
        description="Summary of all links found across documents"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "documents": [
                    {
                        "markdown": "## Project Title\n\nSee [JIRA ticket](https://company.atlassian.net/browse/PROJ-123) for details...",
                        "metadata": {"source": "project_doc.pdf"},
                        "links": [
                            {
                                "url": "https://company.atlassian.net/browse/PROJ-123",
                                "anchor_text": "JIRA ticket",
                                "link_type": "hyperlink",
                                "context": "See JIRA ticket for details"
                            }
                        ]
                    }
                ],
                "tokens_used": 156,
                "links_summary": {
                    "total_links": 1,
                    "has_crawlable_links": True,
                    "links_by_document": {
                        "project_doc.pdf": [
                            {
                                "url": "https://company.atlassian.net/browse/PROJ-123",
                                "anchor_text": "JIRA ticket",
                                "link_type": "hyperlink",
                                "context": "See JIRA ticket for details"
                            }
                        ]
                    }
                }
            }
        }

# -------------------- UPLOAD & UPSERT --------------------

class UpsertPayload(BaseModel):
    markdown: str = Field(
        ...,
        description="Markdown content to be chunked and embedded into vector database",
        example="## Product Documentation\n\nThis section covers the API specifications and usage guidelines..."
    )
    metadata: Optional[Dict[str, MetaValue]] = Field(
        default=None,
        description="Optional metadata to associate with all chunks created from this document. Values can be strings, numbers, booleans, arrays, or nested objects.",
        example={"source": "api_docs.pdf", "version": "1.0", "department": "engineering", "tags": ["api", "documentation"]}
    )
    collection: str = Field(
        ...,
        description="Target Qdrant collection name for storing the vector embeddings",
        example="user123_knowledge_base"
    )

class UpsertDocument(BaseModel):
    markdown: str = Field(
        ...,
        description="Markdown content for individual document in batch operation",
        example="## User Guide\n\nStep-by-step instructions for getting started..."
    )
    metadata: Optional[Dict[str, MetaValue]] = Field(
        default=None,
        description="Optional metadata specific to this document. Values can be strings, numbers, booleans, arrays, or nested objects.",
        example={"source": "user_guide.pdf", "section": "getting_started", "tags": ["guide", "tutorial"]}
    )

class BatchUpsertPayload(BaseModel):
    documents: List[UpsertDocument] = Field(
        ...,
        description="List of documents to process and upsert in a single batch operation"
    )
    metadata: Optional[Dict[str, MetaValue]] = Field(
        default=None,
        description="Optional metadata to apply to all documents in the batch. Values can be strings, numbers, booleans, arrays, or nested objects.",
        example={"batch_id": "upload_2024_01", "processed_by": "user123", "sources": ["doc1.pdf", "doc2.pdf"]}
    )
    collection: str = Field(
        ...,
        description="Target Qdrant collection for all documents in the batch",
        example="user123_knowledge_base"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "documents": [
                    {
                        "markdown": "## API Reference\n\nComprehensive API documentation...",
                        "metadata": {"source": "api_docs.pdf", "type": "reference"}
                    },
                    {
                        "markdown": "## Troubleshooting Guide\n\nCommon issues and solutions...",
                        "metadata": {"source": "troubleshooting.pdf", "type": "guide"}
                    }
                ],
                "metadata": {"batch_upload": "2024-01-15", "user": "admin"},
                "collection": "company_docs"
            }
        }

# -------------------- UPSERT RESPONSES --------------------

class UpsertResponse(BaseModel):
    message: str = Field(
        ..., 
        example="✅ Document processed and embedded successfully",
        description="Status message describing the upsert operation result"
    )
    collection: str = Field(
        ..., 
        example="user123_knowledge_base",
        description="Name of the collection where vectors were stored"
    )
    chunks: int = Field(
        ..., 
        example=5,
        description="Number of text chunks created and embedded from the document"
    )
    metadata: Dict[str, MetaValue] = Field(
        ...,
        description="Final metadata applied to the embedded chunks including system-generated fields"
    )
    tokens_used: int = Field(
        ..., 
        example=1250,
        description="Total tokens consumed for embedding generation using text-embedding-3-small model"
    )

class UpsertPayloadResponse(BaseModel):
    status: str = Field(
        ..., 
        example="single upsert complete",
        description="Operation status indicator"
    )
    result: UpsertResponse

    class Config:
        json_schema_extra = {
            "example": {
                "status": "single upsert complete",
                "result": {
                    "message": "✅ Document processed and embedded successfully",
                    "collection": "user123_docs",
                    "chunks": 3,
                    "metadata": {
                        "source": "manual.pdf",
                        "creator_api_key_hash": "sha256_hash_here",
                        "processed_at": "2024-01-15T10:30:00Z"
                    },
                    "tokens_used": 892
                }
            }
        }

class BatchUpsertResponse(BaseModel):
    status: str = Field(
        ..., 
        example="batch upsert complete",
        description="Batch operation status indicator"
    )
    results: List[UpsertResponse] = Field(
        ...,
        description="Individual upsert results for each document in the batch"
    )
    total_tokens_used: int = Field(
        ..., 
        example=3450,
        description="Aggregated token consumption across all documents in the batch"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "status": "batch upsert complete",
                "results": [
                    {
                        "message": "✅ Document processed and embedded successfully",
                        "collection": "company_docs",
                        "chunks": 4,
                        "metadata": {"source": "policy.pdf"},
                        "tokens_used": 1200
                    },
                    {
                        "message": "✅ Document processed and embedded successfully", 
                        "collection": "company_docs",
                        "chunks": 6,
                        "metadata": {"source": "handbook.pdf"},
                        "tokens_used": 1850
                    }
                ],
                "total_tokens_used": 3050
            }
        }

# -------------------- CHAT --------------------

class ChatRequest(BaseModel):
    query: str = Field(
        ..., 
        example="What are the main security considerations mentioned in the uploaded documents?",
        description="User question to be answered using the knowledge base"
    )
    collection: str = Field(
        ..., 
        example="user123_knowledge_base",
        description="Qdrant collection to search for relevant context"
    )
    filters: Optional[Dict[str, MetaValue]] = Field(
        default=None,
        description="Optional metadata filters to narrow down the search scope. Values can be strings, numbers, booleans, arrays, or nested objects.",
        example={"source": ["security_policy.pdf", "user_guide.pdf"], "department": "IT"}
    )
    history: Optional[List[Dict[str, str]]] = Field(
        default=None,
        description="Optional conversation history to maintain context across multiple exchanges",
        example=[
            {"role": "user", "content": "What is our data retention policy?"},
            {"role": "assistant", "content": "According to the policy document, data is retained for 7 years..."}
        ]
    )
    skipRetrieval: Optional[bool] = Field(
        default=False,
        description="Skip context retrieval for simple queries like greetings"
    )
    # New fields for context caching
    contextCacheKey: Optional[str] = Field(
        default=None,
        description="Cache key for reusing previous context retrieval"
    )
    forceRefresh: Optional[bool] = Field(
        default=False,
        description="Force fresh context retrieval even if cache exists"
    )
    conversationId: Optional[str] = Field(
        default=None,
        description="Unique conversation identifier for context management"
    )

class RetrievedChunk(BaseModel):
    source: str = Field(
        ..., 
        example="security_guidelines.pdf",
        description="Source document filename where this content was found"
    )
    creator_api_key_hash: str = Field(
        ..., 
        example="sha256_abc123def456",
        description="Hash of the API key that uploaded this content"
    )
    chunkIndex: int = Field(
        ..., 
        example=2,
        description="Sequential index of this chunk within the source document"
    )
    text: str = Field(
        ..., 
        example="## Data Security\n\nAll sensitive data must be encrypted at rest using AES-256...",
        description="The actual text content of the retrieved chunk"
    )

class ChatRequestResponse(BaseModel):
    response: str = Field(
        ..., 
        example="Based on the security guidelines, the main considerations include: 1) Data encryption at rest using AES-256, 2) Regular security audits, 3) Access control implementation...",
        description="AI-generated response based on the retrieved context"
    )
    context: List[RetrievedChunk] = Field(
        ...,
        description="List of relevant document chunks used to generate the response"
    )
    tokens_used: int = Field(
        ..., 
        example=285,
        description="Total tokens consumed including query embedding (text-embedding-3-small) and chat completion (gpt-4o)"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "response": "The main security considerations mentioned in the documents include: 1) Data encryption requirements using AES-256 for data at rest, 2) Implementation of multi-factor authentication for all user accounts, 3) Regular security audits conducted quarterly, and 4) Incident response procedures that must be followed within 24 hours of detection.",
                "context": [
                    {
                        "source": "security_policy.pdf",
                        "creator_api_key_hash": "sha256_hash_example",
                        "chunkIndex": 0,
                        "text": "## Data Security Requirements\n\nAll sensitive data must be encrypted at rest using AES-256 encryption. Additionally, data in transit must use TLS 1.3 or higher."
                    },
                    {
                        "source": "security_policy.pdf", 
                        "creator_api_key_hash": "sha256_hash_example",
                        "chunkIndex": 3,
                        "text": "## Authentication\n\nMulti-factor authentication is required for all user accounts accessing sensitive systems."
                    }
                ],
                "tokens_used": 342
            }
        }

# -------------------- MANAGEMENT --------------------

class DropCollection(BaseModel):
    collection: str = Field(
        ..., 
        example="user123_old_collection",
        description="Name of the Qdrant collection to delete permanently"
    )

class DropCollectionResponse(BaseModel):
    message: str = Field(
        ..., 
        example="✅ Collection 'user123_old_collection' deleted successfully",
        description="Confirmation message for the deletion operation"
    )

class DeleteByMetadata(BaseModel):
    collection: str = Field(
        ..., 
        example="user123_knowledge_base",
        description="Target collection for selective deletion"
    )
    filter: Dict[str, MetaValue] = Field(
        ..., 
        example={"source": ["outdated_policy.pdf", "old_manual.pdf"], "version": 1.0},
        description="Metadata filter to identify vectors for deletion. Values can be strings, numbers, booleans, arrays, or nested objects."
    )

class DeleteByMetadataResponse(BaseModel):
    message: str = Field(
        ..., 
        example="Successfully deleted 15 vectors matching the specified metadata filter",
        description="Details about the deletion operation results"
    )

# -------------------- CRAWL LINKS --------------------

class CrawlLinksRequest(BaseModel):
    collection: str = Field(
        ...,
        description="Target Qdrant collection to store crawled content",
        example="user123_session_abc"
    )
    session_id: str = Field(
        ...,
        description="Session ID for tracking and token management",
        example="session_abc123"
    )
    links: List[str] = Field(
        ...,
        description="List of unique URLs to crawl (duplicates will be filtered)",
        example=[
            "https://company.atlassian.net/browse/PROJ-123",
            "https://company.confluence.com/display/PROJ/Release+Notes",
            "https://example.com/documentation"
        ]
    )
    source_mapping: Optional[Dict[str, str]] = Field(
        default=None,
        description="Optional mapping of URLs to custom source names (e.g., filenames). "
                   "When provided, the mapped names will be used as 'source' in Qdrant instead of URLs, "
                   "enabling consistent filtering in the frontend.",
        example={
            "https://example.com/page1": "crawled-link-1-example.com.link",
            "https://github.com/repo": "crawled-link-2-github.com.link"
        }
    )
    crawl_options: Optional[Dict[str, Union[str, int, bool]]] = Field(
        default_factory=dict,
        description="Optional crawling configuration",
        example={
            "timeout_seconds": 30,
            "max_content_length": 1000000,
            "include_external_links": False
        }
    )

class CrawledContent(BaseModel):
    url: str = Field(..., description="The original URL that was crawled")
    success: bool = Field(..., description="Whether crawling was successful")
    content_type: str = Field(
        ..., 
        description="Type of content crawled",
        example="jira_issue|confluence_page|html_page|error"
    )
    markdown: str = Field(..., description="Extracted content in markdown format")
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata about the crawled content (flexible structure to accommodate any data type)"
    )
    tokens_used: int = Field(
        default=0,
        description="Tokens consumed during crawling (e.g., for API calls to extract content)"
    )
    error_message: Optional[str] = Field(
        default=None,
        description="Error message if crawling failed"
    )

    @validator('metadata', pre=True)
    def clean_metadata(cls, v):
        """Clean up metadata to handle None values properly"""
        if not isinstance(v, dict):
            return {}
        
        # Convert None values to appropriate defaults, but preserve nested structures
        def clean_value(value):
            if value is None:
                return "Unknown"
            elif isinstance(value, dict):
                return {k: clean_value(v) for k, v in value.items()}
            elif isinstance(value, list):
                return [clean_value(item) for item in value]
            else:
                return value
        
        return {key: clean_value(value) for key, value in v.items()}

class CrawlLinksResponse(BaseModel):
    status: str = Field(
        ...,
        example="crawling_complete",
        description="Overall crawling operation status"
    )
    results: List[CrawledContent] = Field(
        ...,
        description="Individual crawling results for each URL"
    )
    summary: Dict[str, Union[int, str]] = Field(
        ...,
        description="Summary statistics about the crawling operation",
        example={
            "total_urls": 5,
            "successful": 4,
            "failed": 1,
            "jira_issues": 2,
            "confluence_pages": 1,
            "html_pages": 1,
            "total_tokens_used": 450,
            "content_stored": True
        }
    )

    class Config:
        json_schema_extra = {
            "example": {
                "status": "crawling_complete",
                "results": [
                    {
                        "url": "https://company.atlassian.net/browse/PROJ-123",
                        "success": True,
                        "content_type": "jira_issue",
                        "markdown": "# PROJ-123: Fix Login Bug\n\n**Status:** In Progress\n**Assignee:** John Doe\n\n## Description\nUsers cannot login...",
                        "metadata": {
                            "issue_key": "PROJ-123",
                            "issue_type": "Bug", 
                            "status": "In Progress",
                            "assignee": "John Doe",
                            "created": "2024-01-15T10:00:00Z",
                            "custom_fields": {
                                "Sprint": "Sprint 23",
                                "Story Points": "5"
                            }
                        },
                        "tokens_used": 0
                    },
                    {
                        "url": "https://company.confluence.com/display/PROJ/Release+Notes",
                        "success": True,
                        "content_type": "confluence_page",
                        "markdown": "# Release Notes\n\n## Version 2.1.0\n\n### New Features\n- Added user management...",
                        "metadata": {
                            "page_title": "Release Notes",
                            "space_key": "PROJ",
                            "page_id": "12345",
                            "last_modified": "2024-01-14T15:30:00Z"
                        },
                        "tokens_used": 0
                    },
                    {
                        "url": "https://example.com/docs",
                        "success": True,
                        "content_type": "html_page",
                        "markdown": "# Documentation\n\nThis is the main documentation page...",
                        "metadata": {
                            "title": "Documentation - Example",
                            "content_length": 5420
                        },
                        "tokens_used": 0
                    }
                ],
                "summary": {
                    "total_urls": 3,
                    "successful": 3,
                    "failed": 0,
                    "jira_issues": 1,
                    "confluence_pages": 1,
                    "html_pages": 1,
                    "total_tokens_used": 0,
                    "content_stored": True
                }
            }
        }