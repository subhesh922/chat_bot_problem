# app/router.py

from fastapi import APIRouter, Depends
from app.routes.extract import router as extract_router
from app.routes.upsert import router as upsert_router
from app.routes.chat import router as chat_router
from app.routes.crawl import router as crawl_router
from app.routes.dropCollection import router as dropCollection_router
from app.routes.deleteByMetadata import router as delete_by_metadata
from app.auth import (verify_api_key)

router = APIRouter()

# Apply API key authentication at route level
router.include_router(extract_router, prefix="/api", dependencies=[Depends(verify_api_key)])
router.include_router(upsert_router, prefix="/api", dependencies=[Depends(verify_api_key)])
router.include_router(chat_router, prefix="/api", dependencies=[Depends(verify_api_key)])
router.include_router(crawl_router, prefix="/api", dependencies=[Depends(verify_api_key)])
router.include_router(dropCollection_router, prefix="/api", dependencies=[Depends(verify_api_key)])
router.include_router(delete_by_metadata, prefix="/api", dependencies=[Depends(verify_api_key)])
