# app/utils/crawlers/html_crawler.py

import httpx
from typing import Dict, Any
import logging
from bs4 import BeautifulSoup
import html2text
from urllib.parse import urljoin, urlparse
from .ocr_crawler_service import ocr_crawler_service

logger = logging.getLogger(__name__)

class HTMLCrawler:
    """Enhanced HTML crawler with shared OCR support for all images"""
    
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
    
    async def crawl_page(self, url: str) -> Dict[str, Any]:
        """
        Crawl any web page with automatic OCR processing for images using shared service
        """
        logger.info(f"=== STARTING HTML CRAWL WITH SHARED OCR ===")
        logger.info(f"URL: {url}")
        
        try:
            # Download the HTML content
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                response = await client.get(url, headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                })
                response.raise_for_status()
                
                html_content = response.text
                logger.info(f"Downloaded HTML: {len(html_content)} characters")
                
                # Process images with OCR using shared service
                logger.info(f"Processing HTML images with shared OCR service...")
                processed_html, ocr_tokens = await ocr_crawler_service.process_html_images_with_ocr(
                    html_content, url  # No auth headers needed for public pages
                )
                
                logger.info(f"OCR processing complete: {ocr_tokens} tokens used")
                
                # Convert processed HTML to markdown
                soup = BeautifulSoup(processed_html, 'html.parser')
                markdown = self._html_to_markdown(soup)
                
                # Extract metadata
                metadata = self._extract_page_metadata(soup, url)
                
                logger.info(f"=== HTML CRAWL COMPLETED ===")
                logger.info(f"Final markdown size: {len(markdown)} characters")
                
                return {
                    "success": True,
                    "markdown": markdown,
                    "metadata": metadata,
                    "tokens_used": ocr_tokens,  # Includes OCR tokens from shared service
                    "error_message": None
                }
                
        except httpx.HTTPStatusError as e:
            error_msg = f"HTTP error {e.response.status_code}: {e.response.text}"
            logger.error(f"HTTP error during HTML crawl: {error_msg}")
            return self._create_error_response(url, error_msg, "http_error")
            
        except httpx.TimeoutException as e:
            error_msg = f"Request timeout after {self.timeout}s"
            logger.error(f"Timeout error: {error_msg}")
            return self._create_error_response(url, error_msg, "timeout_error")
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Unexpected error crawling HTML page {url}: {error_msg}")
            logger.exception("Full traceback:")
            return self._create_error_response(url, error_msg, "unexpected_error")
    
    def _html_to_markdown(self, soup: BeautifulSoup) -> str:
        """Convert HTML to markdown (enhanced to handle OCR content)"""
        try:
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.extract()
            
            # Get text content
            text = soup.get_text()
            
            # Basic cleanup
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            # Simple markdown conversion (you can enhance this)
            # Handle headers
            for i in range(1, 7):
                h_tags = soup.find_all(f'h{i}')
                for h_tag in h_tags:
                    header_text = h_tag.get_text().strip()
                    if header_text:
                        text = text.replace(header_text, f"{'#' * i} {header_text}")
            
            # Handle OCR content specially (preserve the formatting)
            ocr_divs = soup.find_all('div', class_='ocr-extracted-content')
            for ocr_div in ocr_divs:
                ocr_text = ocr_div.get_text()
                # OCR content is already well-formatted, just ensure it's preserved
                
            return text
            
        except Exception as e:
            logger.error(f"Error converting HTML to markdown: {e}")
            return str(soup.get_text()) if soup else "Error converting content"
    
    def _extract_page_metadata(self, soup: BeautifulSoup, url: str) -> dict:
        """Extract metadata from HTML page"""
        try:
            # Extract title
            title_tag = soup.find('title')
            title = title_tag.get_text().strip() if title_tag else "Untitled"
            
            # Extract meta description
            description_tag = soup.find('meta', attrs={'name': 'description'})
            description = description_tag.get('content', '') if description_tag else ''
            
            # Extract meta keywords
            keywords_tag = soup.find('meta', attrs={'name': 'keywords'})
            keywords = keywords_tag.get('content', '') if keywords_tag else ''
            
            return {
                "title": title,
                "description": description,
                "keywords": keywords,
                "url": url,
                "source_type": "html_page"
            }
            
        except Exception as e:
            logger.error(f"Error extracting HTML metadata: {e}")
            return {"url": url, "source_type": "html_page", "error": str(e)}
    
    def _create_error_response(self, url: str, error_msg: str, error_type: str) -> dict:
        """Create standardized error response"""
        logger.error(f"Creating HTML crawler error response: {error_type} - {error_msg}")
        
        return {
            "success": False,
            "markdown": f"<!-- Failed to crawl HTML page {url}: {error_msg} -->",
            "metadata": {
                "url": url, 
                "error": error_type, 
                "error_details": error_msg,
                "source_type": "html_page"
            },
            "tokens_used": 0,
            "error_message": error_msg
        }

# Global instance
html_crawler = HTMLCrawler()