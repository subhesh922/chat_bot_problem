# app/utils/crawlers/ocr_crawler_service.py

import httpx
from typing import Dict, Any, Optional, Tuple
import logging
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re

logger = logging.getLogger(__name__)

class OCRCrawlerService:
    """Centralized OCR service used by all crawlers (HTML, Confluence, etc.)"""
    
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.max_image_size = 10 * 1024 * 1024  # 10MB limit
        self.max_images_per_page = 20  # Limit to prevent abuse
    
    async def process_html_images_with_ocr(self, html_content: str, base_url: str, auth_headers: dict = None) -> tuple[str, int]:
        """Process all images in HTML content with OCR with enhanced debugging"""
        logger.info(f"=== SHARED OCR SERVICE: PROCESSING IMAGES ===")
        logger.info(f"Base URL: {base_url}")
        
        total_tokens_used = 0
        processed_images = 0
        skipped_images = 0
        
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            img_tags = soup.find_all('img')
            logger.info(f"Found {len(img_tags)} image tags")
            
            # Log first few image URLs for debugging
            logger.info(f"=== SAMPLE IMAGES FOUND ===")
            for i, img_tag in enumerate(img_tags[:5], 1):  # Show first 5
                img_src = img_tag.get('src', '')
                img_alt = img_tag.get('alt', f'Image {i}')
                img_url = self._resolve_image_url(img_src, base_url)
                logger.info(f"Sample {i}: {img_url} (alt: '{img_alt}')")
            
            if len(img_tags) > 5:
                logger.info(f"... and {len(img_tags) - 5} more images")
            
            # Limit number of images to process
            if len(img_tags) > self.max_images_per_page:
                logger.warning(f"Too many images ({len(img_tags)}), limiting to {self.max_images_per_page}")
                img_tags = img_tags[:self.max_images_per_page]
            
            # Process with detailed logging
            for i, img_tag in enumerate(img_tags, 1):
                try:
                    img_src = img_tag.get('src', '')
                    img_alt = img_tag.get('alt', f'Image {i}')
                    img_title = img_tag.get('title', '')
                    
                    if not img_src:
                        logger.debug(f"Image {i} has no src, skipping")
                        skipped_images += 1
                        continue
                    
                    img_url = self._resolve_image_url(img_src, base_url)
                    
                    # Check if should skip with detailed logging
                    logger.info(f"=== ANALYZING IMAGE {i}/{len(img_tags)} ===")
                    if self._should_skip_image(img_url, img_alt, img_tag):
                        skipped_images += 1
                        continue
                    
                    logger.info(f"Processing image {i}/{len(img_tags)}: {img_url}")
                    
                    # Download and OCR
                    ocr_result = await self._download_and_ocr_image(img_url, auth_headers)
                    
                    if ocr_result and ocr_result.get("text", "").strip():
                        ocr_text = ocr_result["text"].strip()
                        ocr_tokens = ocr_result.get("tokens_used", 0)
                        total_tokens_used += ocr_tokens
                        processed_images += 1
                        
                        logger.info(f"OCR SUCCESS: {len(ocr_text)} chars, {ocr_tokens} tokens")
                        
                        # Replace image with OCR content
                        ocr_replacement = self._create_ocr_replacement(
                            soup, img_alt, img_title, ocr_text, img_url
                        )
                        img_tag.replace_with(ocr_replacement)
                        
                    else:
                        logger.debug(f"No OCR text from image {i}")
                        skipped_images += 1
                        self._add_image_note(soup, img_tag, img_alt)
                        
                except Exception as e:
                    logger.warning(f"Failed processing image {i}: {e}")
                    skipped_images += 1
                    continue
            
            logger.info(f"OCR complete: {processed_images} processed, {skipped_images} skipped, {total_tokens_used} tokens")
            return str(soup), total_tokens_used
            
        except Exception as e:
            logger.error(f"Error in shared OCR processing: {e}")
            return html_content, 0
    
    async def _download_and_ocr_image(self, img_url: str, auth_headers: dict = None) -> Optional[dict]:
        """Download image and run OCR"""
        try:
            # Default headers
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            
            # Add auth headers if provided (for Confluence, etc.)
            if auth_headers:
                headers.update(auth_headers)
            
            logger.debug(f"Downloading: {img_url}")
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(img_url, headers=headers)
                
                # Check content type
                content_type = response.headers.get('content-type', '').lower()
                if not any(t in content_type for t in ['image/', 'png', 'jpg', 'jpeg']):
                    logger.debug(f"Not an image: {content_type}")
                    return None
                
                if response.status_code == 200:
                    image_bytes = response.content
                    
                    # Size check
                    if len(image_bytes) > self.max_image_size:
                        logger.warning(f"Image too large: {len(image_bytes)} bytes")
                        return None
                    
                    # Import your existing OCR function
                    from app.utils.extractors.ocr_utils import run_ocr_on_image_bytes
                    return await run_ocr_on_image_bytes(image_bytes)
                    
        except Exception as e:
            logger.warning(f"Error downloading/OCR {img_url}: {e}")
            return None
    
    def _resolve_image_url(self, img_src: str, base_url: str) -> str:
        """Resolve relative URLs to absolute"""
        try:
            if img_src.startswith(('http://', 'https://')):
                return img_src
            elif img_src.startswith('//'):
                parsed_base = urlparse(base_url)
                return f"{parsed_base.scheme}:{img_src}"
            else:
                return urljoin(base_url, img_src)
        except Exception:
            return img_src
    
    def _should_skip_image(self, img_url: str, img_alt: str, img_tag) -> bool:
        """Determine if image should be skipped with detailed logging"""
        skip_patterns = [
            r'favicon\.ico', r'logo\.', r'icon\.', r'avatar\.', 
            r'badge\.', r'button\.', r'arrow\.', r'\.svg$',
            r'pixel\.gif', r'spacer\.gif'
        ]
        
        img_url_lower = img_url.lower()
        img_alt_lower = img_alt.lower()
        
        # Log image details for debugging
        logger.debug(f"Analyzing image:")
        logger.debug(f"  URL: {img_url}")
        logger.debug(f"  Alt text: '{img_alt}'")
        
        # Check size attributes
        width = img_tag.get('width')
        height = img_tag.get('height')
        logger.debug(f"  Dimensions: {width} x {height}")
        
        # Skip by URL patterns
        for pattern in skip_patterns:
            if re.search(pattern, img_url_lower):
                logger.debug(f"  SKIPPED: URL matches pattern '{pattern}'")
                return True
        
        # Skip by alt text
        skip_alt_patterns = ['icon', 'logo', 'avatar', 'decoration', 'clap', 'follow']
        for pattern in skip_alt_patterns:
            if pattern in img_alt_lower:
                logger.debug(f"  SKIPPED: Alt text contains '{pattern}'")
                return True
        
        # Skip by size attributes (small images likely icons)
        if width and height:
            try:
                w, h = int(width), int(height)
                if w < 100 or h < 100:  # Changed from 50 to 100 to be more selective
                    logger.debug(f"  SKIPPED: Too small ({w}x{h} pixels)")
                    return True
            except ValueError:
                pass
        
        # Skip Medium-specific patterns
        medium_skip_patterns = [
            r'cdn-images-1\.medium\.com.*avatar',  # Author avatars
            r'cdn-images-1\.medium\.com.*clap',    # Clap buttons  
            r'cdn-images-1\.medium\.com.*follow',  # Follow buttons
            r'miro\.medium\.com.*avatar',          # Profile images
            r'\.medium\.com.*icon',                # Various icons
        ]
        
        for pattern in medium_skip_patterns:
            if re.search(pattern, img_url_lower):
                logger.debug(f"  SKIPPED: Medium-specific pattern '{pattern}'")
                return True
        
        logger.info(f"  WILL PROCESS: Image passed all filters")
        return False
    
    def _create_ocr_replacement(self, soup, img_alt: str, img_title: str, ocr_text: str, img_url: str):
        """Create HTML replacement for OCR'd image"""
        div = soup.new_tag("div", **{"class": "ocr-extracted-content"})
        
        # Header
        header = soup.new_tag("strong")
        header.string = f"[OCR from {img_alt}]:" if img_alt else "[OCR from image]:"
        div.append(header)
        div.append(soup.new_tag("br"))
        
        # OCR text
        div.append(soup.new_string(ocr_text))
        div.append(soup.new_tag("br"))
        
        # Reference
        ref = soup.new_tag("em")
        ref.string = f"(Source: {img_url})"
        div.append(ref)
        
        return div
    
    def _add_image_note(self, soup, img_tag, img_alt: str):
        """Add note to images with no OCR text"""
        note = soup.new_tag("em")
        note.string = f" [Image: {img_alt} - No text detected]"
        img_tag.insert_after(note)

# Global instance
ocr_crawler_service = OCRCrawlerService()