# app/utils/crawlers/confluence_crawler.py

import httpx
from typing import Dict, Any, Optional
import logging
import re
from urllib.parse import parse_qs, urlparse
from app.config import CONFLUENCE_BEARER_TOKEN
from .ocr_crawler_service import ocr_crawler_service

logger = logging.getLogger(__name__)

class ConfluenceServerCrawler:
    """Enhanced crawler for Confluence Server pages using Confluence REST API with shared OCR"""
    
    def __init__(self, bearer_token: str = None):
        self.bearer_token = bearer_token or CONFLUENCE_BEARER_TOKEN
        self.timeout = 30
    
    async def crawl_page(self, url: str, metadata: dict) -> Dict[str, Any]:
        """
        Crawl a Confluence Server page using the REST API with shared OCR for images
        """
        logger.info(f"=== STARTING CONFLUENCE PAGE CRAWL WITH SHARED OCR ===")
        logger.info(f"Original URL: {url}")
        logger.info(f"Input metadata: {metadata}")
        
        try:
            base_url = metadata.get("base_url")
            page_id = metadata.get("page_id")
            space_key = metadata.get("space_key")
            page_title = metadata.get("page_title")
            
            logger.info(f"Extracted parameters - base_url: {base_url}, page_id: {page_id}, space_key: {space_key}, page_title: {page_title}")
            
            # Try to get page_id if we don't have it but have space and title
            if not page_id and space_key and page_title:
                logger.info(f"Page ID not found, attempting to find via space_key and page_title")
                page_id = await self._find_page_id(base_url, space_key, page_title)
                if page_id:
                    logger.info(f"Successfully found page_id via search: {page_id}")
                else:
                    logger.warning(f"Failed to find page_id via space/title search")
            
            # If we still don't have page_id, try to extract from URL params
            if not page_id:
                logger.info(f"Attempting to extract page_id from URL parameters")
                page_id = await self._extract_page_id_from_url(url)
                if page_id:
                    logger.info(f"Successfully extracted page_id from URL: {page_id}")
                else:
                    logger.warning(f"Failed to extract page_id from URL parameters")
            
            if not page_id:
                error_msg = f"Could not determine page ID for Confluence page: {url}"
                logger.error(error_msg)
                return self._create_error_response(url, error_msg, "no_page_id")
            
            # Construct API URL for Confluence Server
            api_url = f"{base_url}/rest/api/content/{page_id}"
            logger.info(f"Making Confluence API request to: {api_url}")
            
            # Request page content with body and metadata
            params = {
                "expand": "body.storage,metadata.labels,space,version,ancestors"
            }
            logger.debug(f"API request parameters: {params}")
            
            # Set up headers for server authentication
            headers = {
                "Authorization": f"Bearer {self.bearer_token}",
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            # Make API request with detailed logging
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                logger.info(f"Sending HTTP request to Confluence API...")
                response = await client.get(api_url, headers=headers, params=params)
                
                logger.info(f"Confluence API response status: {response.status_code}")
                logger.debug(f"Response headers: {dict(response.headers)}")
                
                # Log response size
                content_length = response.headers.get('content-length', 'unknown')
                logger.info(f"Response content length: {content_length} bytes")
                
                response.raise_for_status()
                
                # Parse JSON response
                logger.info(f"Parsing JSON response...")
                page_data = response.json()
                
                # Debug the response structure
                logger.info(f"Successfully retrieved Confluence page data for page_id: {page_id}")
                logger.debug(f"Response top-level keys: {list(page_data.keys())}")
                
                # Log basic page info
                page_title_from_api = page_data.get("title", "Unknown")
                page_type = page_data.get("type", "Unknown")
                page_status = page_data.get("status", "Unknown")
                logger.info(f"Page details - Title: '{page_title_from_api}', Type: {page_type}, Status: {page_status}")
                
                # Check if we have content body
                body = page_data.get("body", {})
                storage = body.get("storage", {})
                html_content = storage.get("value", "")
                content_size = len(html_content) if html_content else 0
                logger.info(f"Page content size: {content_size} characters")
                
                if not html_content:
                    logger.warning(f"No HTML content found in page body - page may be empty or restricted")
                
                # Convert to markdown with shared OCR
                logger.info(f"Converting page content to markdown with shared OCR...")
                markdown, ocr_tokens = await self._convert_page_to_markdown(page_data, base_url)
                markdown_size = len(markdown)
                logger.info(f"Generated markdown size: {markdown_size} characters, OCR tokens: {ocr_tokens}")
                
                # Extract metadata with logging
                logger.info(f"Extracting page metadata...")
                page_metadata = self._extract_page_metadata(page_data, url)
                logger.info(f"Successfully extracted metadata with {len(page_metadata)} fields")
                logger.debug(f"Extracted metadata keys: {list(page_metadata.keys())}")
                
                logger.info(f"=== CONFLUENCE PAGE CRAWL COMPLETED SUCCESSFULLY ===")
                
                return {
                    "success": True,
                    "markdown": markdown,
                    "metadata": page_metadata,
                    "tokens_used": ocr_tokens,  # Now includes OCR tokens!
                    "error_message": None
                }
                
        except httpx.HTTPStatusError as e:
            error_msg = f"Confluence Server API error {e.response.status_code}: {e.response.text}"
            logger.error(f"HTTP error occurred during Confluence crawl:")
            logger.error(f"  Status Code: {e.response.status_code}")
            logger.error(f"  Response Text: {e.response.text}")
            logger.error(f"  Request URL: {e.request.url}")
            logger.error(f"  Request Method: {e.request.method}")
            
            if hasattr(e.response, 'headers'):
                logger.debug(f"  Response Headers: {dict(e.response.headers)}")
            
            return self._create_error_response(url, error_msg, "api_error", e.response.status_code)
            
        except httpx.TimeoutException as e:
            error_msg = f"Confluence API request timeout after {self.timeout}s"
            logger.error(f"Timeout error: {error_msg}")
            logger.error(f"  URL: {url}")
            return self._create_error_response(url, error_msg, "timeout_error")
            
        except httpx.NetworkError as e:
            error_msg = f"Network error connecting to Confluence: {str(e)}"
            logger.error(f"Network error: {error_msg}")
            return self._create_error_response(url, error_msg, "network_error")
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Unexpected error crawling Confluence page {url}: {error_msg}")
            logger.exception("Full traceback:")
            return self._create_error_response(url, error_msg, "unexpected_error")
    
    async def _find_page_id(self, base_url: str, space_key: str, page_title: str) -> Optional[str]:
        """Find page ID using space key and page title with proper URL decoding"""
        logger.info(f"=== SEARCHING FOR PAGE ID ===")
        logger.info(f"Space: {space_key}, Title: '{page_title}'")
        
        try:
             # Import urllib.parse for proper URL decoding
            from urllib.parse import unquote
            
            # First, decode any URL encoding in the title
            decoded_title = unquote(page_title)
            logger.info(f"Original title: '{page_title}'")
            logger.info(f"Decoded title: '{decoded_title}'")
            
            # Clean up the page title further
            cleaned_title = decoded_title.replace('+', ' ').replace('%20', ' ')
            logger.info(f"Cleaned title: '{cleaned_title}'")
            
            # Search for page by title in space
            api_url = f"{base_url}/rest/api/content"
            params = {
                "spaceKey": space_key,
                "title": cleaned_title,
                "limit": 1
            }
            
            headers = {
                "Authorization": f"Bearer {self.bearer_token}",
                "Accept": "application/json"
            }
            
            logger.info(f"Searching via API: {api_url}")
            logger.debug(f"Search parameters: {params}")
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, headers=headers, params=params)
                
                logger.info(f"Search API response status: {response.status_code}")
                actual_url = str(response.request.url)
                logger.debug(f"Actual API URL called: {actual_url}")
                
                if response.status_code == 200:
                    data = response.json()
                    results = data.get("results", [])
                    total_results = len(results)
                    logger.info(f"Found {total_results} search results")
                    
                    if results:
                        page_id = results[0].get("id")
                        result_title = results[0].get("title", "Unknown")
                        logger.info(f"Found matching page - ID: {page_id}, Title: '{result_title}'")
                        
                        if result_title != cleaned_title:
                            logger.info(f"Title match - Searched: '{cleaned_title}' vs Found: '{result_title}'")
                        
                        return page_id
                    else:
                        logger.warning(f"No pages found matching title '{cleaned_title}' in space '{space_key}'")
                        
                        # Try alternative title formats
                        logger.info(f"=== TRYING ALTERNATIVE TITLE FORMATS ===")
                        alternative_titles = [
                            page_title,
                            page_title.replace('+', ' '),
                            unquote(page_title, errors='ignore'),
                            cleaned_title.replace(' ', '+'),
                        ]
                        
                        for i, alt_title in enumerate(alternative_titles):
                            if alt_title != cleaned_title:
                                logger.debug(f"Alternative title {i+1}: '{alt_title}'")
                                alt_params = {"spaceKey": space_key, "title": alt_title, "limit": 1}
                                
                                try:
                                    alt_response = await client.get(api_url, headers=headers, params=alt_params)
                                    if alt_response.status_code == 200:
                                        alt_data = alt_response.json()
                                        alt_results = alt_data.get("results", [])
                                        if alt_results:
                                            page_id = alt_results[0].get("id")
                                            result_title = alt_results[0].get("title", "Unknown")
                                            logger.info(f"SUCCESS with alternative title {i+1} - ID: {page_id}, Title: '{result_title}'")
                                            return page_id
                                except Exception as e:
                                    logger.debug(f"Alternative title {i+1} failed: {e}")
                                    continue
                        
                        logger.warning(f"All alternative title formats failed")
                else:
                    logger.warning(f"Search API returned non-200 status: {response.status_code}")
                    logger.debug(f"Search API response: {response.text}")
                        
        except Exception as e:
            logger.error(f"Error during page ID search: {e}")
            logger.exception("Full traceback:")
        
        logger.info(f"=== PAGE ID SEARCH FAILED ===")
        return None
    
    async def _extract_page_id_from_url(self, url: str) -> Optional[str]:
        """Extract page ID from URL parameters"""
        logger.info(f"=== EXTRACTING PAGE ID FROM URL ===")
        logger.debug(f"URL: {url}")
        
        try:
            parsed_url = urlparse(url)
            query_params = parse_qs(parsed_url.query)
            
            logger.debug(f"Parsed URL components:")
            logger.debug(f"  Query params: {query_params}")
            
            # Check for pageId parameter
            if "pageId" in query_params:
                page_id = query_params["pageId"][0]
                logger.info(f"Found pageId in URL parameters: {page_id}")
                return page_id
            else:
                logger.info(f"No pageId parameter found in URL")
                
            # Check for other possible ID parameters
            possible_id_params = ["id", "contentId", "page_id"]
            for param in possible_id_params:
                if param in query_params:
                    page_id = query_params[param][0]
                    logger.info(f"Found alternative ID parameter '{param}': {page_id}")
                    return page_id
                    
        except Exception as e:
            logger.error(f"Error extracting page ID from URL: {e}")
            logger.exception("Full traceback:")
        
        logger.info(f"=== PAGE ID EXTRACTION FROM URL FAILED ===")
        return None
    
    async def _convert_page_to_markdown(self, page_data: dict, base_url: str) -> tuple[str, int]:
        """Convert Confluence Server page JSON to markdown format with shared OCR"""
        logger.info(f"=== CONVERTING CONFLUENCE PAGE TO MARKDOWN WITH SHARED OCR ===")
        
        try:
            # Basic page information
            title = page_data.get("title", "Untitled Page")
            page_id = page_data.get("id", "Unknown")
            logger.info(f"Converting page: '{title}' (ID: {page_id})")
            
            # Space information
            space = page_data.get("space", {})
            space_name = space.get("name", "Unknown Space")
            space_key = space.get("key", "Unknown")
            logger.debug(f"Space info - Name: '{space_name}', Key: {space_key}")
            
            # Version information
            version = page_data.get("version", {})
            version_number = version.get("number", "Unknown")
            last_modified = version.get("when", "Unknown")
            modified_by_data = version.get("by", {})
            modified_by = modified_by_data.get("displayName", "Unknown") if isinstance(modified_by_data, dict) else "Unknown"
            logger.debug(f"Version info - Number: {version_number}, Modified: {last_modified}, By: {modified_by}")
            
            # Start with page header info
            header_parts = [
                f"# {title}",
                "",
                f"**Space:** {space_name} ({space_key}) | **Version:** {version_number} | **Last Modified:** {last_modified} by {modified_by}",
                "",
                "---",
                ""
            ]
            
            # Page content - get the HTML storage value
            body = page_data.get("body", {})
            storage = body.get("storage", {})
            html_content = storage.get("value", "")
            
            content_length = len(html_content) if html_content else 0
            logger.info(f"HTML content length: {content_length} characters")
            
            if html_content and html_content.strip():
                try:
                    logger.info(f"Processing Confluence images with shared OCR service...")
                    
                    # Auth headers for Confluence images
                    auth_headers = {
                        "Authorization": f"Bearer {self.bearer_token}"
                    }
                    
                    # Process images with shared OCR service
                    processed_html, ocr_tokens = await ocr_crawler_service.process_html_images_with_ocr(
                        html_content, base_url, auth_headers
                    )
                    
                    logger.info(f"OCR processing complete: {ocr_tokens} tokens used")
                    
                    # Convert processed HTML to markdown
                    from .html_crawler import html_crawler
                    from bs4 import BeautifulSoup
                    
                    soup = BeautifulSoup(processed_html, 'html.parser')
                    markdown_content = html_crawler._html_to_markdown(soup)
                    
                    converted_length = len(markdown_content) if markdown_content else 0
                    logger.info(f"Converted markdown length: {converted_length} characters")
                    
                    # Combine header with converted content
                    final_markdown = "\n".join(header_parts) + markdown_content
                    logger.info(f"Final markdown total length: {len(final_markdown)} characters")
                    
                    return final_markdown, ocr_tokens
                    
                except ImportError as e:
                    logger.error(f"Failed to import html_crawler: {e}")
                    return "\n".join(header_parts) + f"*Error: Could not import HTML converter - {str(e)}*", 0
                    
                except Exception as e:
                    logger.error(f"Error during HTML to markdown conversion with OCR: {e}")
                    logger.exception("HTML conversion traceback:")
                    html_snippet = html_content[:500] + "..." if len(html_content) > 500 else html_content
                    return "\n".join(header_parts) + f"*Error converting HTML content: {str(e)}*\n\n```html\n{html_snippet}\n```", 0
            else:
                logger.info(f"No HTML content to convert")
                return "\n".join(header_parts) + "*No content available*", 0
            
        except Exception as e:
            logger.error(f"Error in page to markdown conversion: {e}")
            logger.exception("Full traceback:")
            title = page_data.get("title", "Confluence Page") if isinstance(page_data, dict) else "Confluence Page"
            return f"# {title}\n\n*Error converting page: {str(e)}*", 0
    
    def _extract_page_metadata(self, page_data: dict, original_url: str) -> dict:
        """Extract metadata from Confluence Server page"""
        logger.info(f"=== EXTRACTING PAGE METADATA ===")
        
        try:
            page_id = page_data.get("id", "unknown")
            page_title = page_data.get("title", "Unknown")
            logger.debug(f"Extracting metadata for page: '{page_title}' (ID: {page_id})")
            
            space = page_data.get("space", {})
            space_key = space.get("key", "Unknown")
            space_name = space.get("name", "Unknown")
            logger.debug(f"Space metadata - Key: {space_key}, Name: '{space_name}'")
            
            version = page_data.get("version", {})
            version_number = version.get("number", "Unknown")
            last_modified = version.get("when", "Unknown")
            modified_by_data = version.get("by", {})
            modified_by = modified_by_data.get("displayName", "Unknown") if isinstance(modified_by_data, dict) else "Unknown"
            logger.debug(f"Version metadata - Number: {version_number}, Modified by: {modified_by}")
            
            page_type = page_data.get("type", "page")
            page_status = page_data.get("status", "current")
            
            metadata_section = page_data.get("metadata", {})
            labels = metadata_section.get("labels", {}).get("results", []) if isinstance(metadata_section.get("labels"), dict) else []
            label_names = [label.get("name", "") for label in labels if isinstance(label, dict)]
            logger.debug(f"Found {len(label_names)} labels: {label_names}")
            
            metadata = {
                "page_id": page_id,
                "page_title": page_title,
                "page_type": page_type,
                "page_status": page_status,
                "space_key": space_key,
                "space_name": space_name,
                "version": version_number,
                "last_modified": last_modified,
                "modified_by": modified_by,
                "labels": label_names,
                "original_url": original_url,
                "source_type": "confluence_server",
                "api_version": "v1"
            }
            
            logger.info(f"Successfully extracted metadata with {len(metadata)} fields")
            return metadata
            
        except Exception as e:
            logger.error(f"Error extracting page metadata: {e}")
            logger.exception("Full traceback:")
            
            fallback_metadata = {
                "page_id": page_data.get("id", "unknown") if isinstance(page_data, dict) else "unknown",
                "original_url": original_url,
                "source_type": "confluence_server",
                "error": str(e)
            }
            logger.warning(f"Returning fallback metadata: {fallback_metadata}")
            return fallback_metadata
    
    def _create_error_response(self, url: str, error_msg: str, error_type: str, status_code: int = None) -> dict:
        """Create standardized error response"""
        logger.error(f"=== CREATING ERROR RESPONSE ===")
        logger.error(f"URL: {url}")
        logger.error(f"Error Type: {error_type}")
        logger.error(f"Error Message: {error_msg}")
        if status_code:
            logger.error(f"HTTP Status Code: {status_code}")
        
        error_response = {
            "success": False,
            "markdown": f"<!-- Failed to crawl Confluence page {url}: {error_msg} -->",
            "metadata": {
                "url": url, 
                "error": error_type, 
                "error_details": error_msg,
                "source_type": "confluence_server"
            },
            "tokens_used": 0,
            "error_message": error_msg
        }
        
        if status_code:
            error_response["metadata"]["status_code"] = status_code
        
        return error_response

# Global instance
confluence_crawler = ConfluenceServerCrawler()