# app/utils/crawlers/url_classifier.py

import re
from typing import Dict, Any, Optional
from urllib.parse import urlparse, parse_qs
import logging

logger = logging.getLogger(__name__)

class URLClassifier:
    """Classify URLs to determine the appropriate crawling strategy"""
    
    def __init__(self):
        # Enhanced JIRA patterns with better coverage
        self.jira_patterns = [
            r'https?://jira\.zebra\.com/browse/[A-Z]+-\d+',           # Direct browse URLs
            r'https?://jira\.zebra\.com/.*?([A-Z]+-\d+)',             # Issue key anywhere in zebra JIRA
            r'https?://[^/]*jira[^/]*/browse/[A-Z]+-\d+',            # Generic server JIRA browse
            r'https?://[^/]*jira[^/]*/.*?([A-Z]+-\d+)',              # Issue key anywhere in JIRA URLs
            r'.*/browse/[A-Z]+-\d+',                                 # Fallback browse pattern
        ]
        
        # Enhanced Confluence patterns
        self.confluence_patterns = [
            r'https?://confluence\.zebra\.com/.*',                    # Any zebra confluence URL
            r'https?://[^/]*confluence[^/]*/.*',                      # Generic confluence
            r'https?://confluence\.zebra\.com/display/.*/.*',         # Display URLs
            r'https?://confluence\.zebra\.com/pages/viewpage\.action.*', # View page URLs
            r'https?://confluence\.zebra\.com/spaces/.*/pages/.*',    # Spaces URLs
        ]
    
    def classify_url(self, url: str) -> Dict[str, Any]:
        """
        Classify a URL and extract relevant information
        
        Returns:
            {
                "type": "jira_issue|confluence_page|html_page",
                "crawler": "jira_api|confluence_api|html_crawler",
                "metadata": {...}
            }
        """
        try:
            parsed_url = urlparse(url)
            
            # Check for JIRA URLs
            for pattern in self.jira_patterns:
                if re.match(pattern, url, re.IGNORECASE):
                    return self._classify_jira_url(url, parsed_url)
            
            # Check for Confluence URLs
            for pattern in self.confluence_patterns:
                if re.match(pattern, url, re.IGNORECASE):
                    return self._classify_confluence_url(url, parsed_url)
            
            # Default to HTML crawling
            return {
                "type": "html_page",
                "crawler": "html_crawler",
                "metadata": {
                    "domain": parsed_url.netloc,
                    "scheme": parsed_url.scheme
                }
            }
            
        except Exception as e:
            logger.error(f"Error classifying URL {url}: {e}")
            return {
                "type": "html_page",
                "crawler": "html_crawler", 
                "metadata": {"error": str(e)}
            }
    
    def _classify_jira_url(self, url: str, parsed_url) -> Dict[str, Any]:
        """Enhanced JIRA URL classification"""
        # Try multiple patterns to extract issue key
        issue_key = None
        
        # Pattern 1: Direct browse URL
        browse_match = re.search(r'/browse/([A-Z]+-\d+)', url)
        if browse_match:
            issue_key = browse_match.group(1)
        
        # Pattern 2: Issue key anywhere in the URL (for complex URLs)
        if not issue_key:
            key_match = re.search(r'([A-Z]+-\d+)', url)
            if key_match:
                issue_key = key_match.group(1)
        
        # Extract base URL for API calls
        base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
        
        return {
            "type": "jira_issue",
            "crawler": "jira_api",
            "metadata": {
                "issue_key": issue_key,
                "base_url": base_url,
                "domain": parsed_url.netloc,
                "original_url": url  # Keep original for reference
            }
        }
    
    def _classify_confluence_url(self, url: str, parsed_url) -> Dict[str, Any]:
        """Extract Confluence-specific information from URL"""
        metadata = {
            "base_url": f"{parsed_url.scheme}://{parsed_url.netloc}",
            "domain": parsed_url.netloc
        }
        
        # Extract space key and page title from display URLs
        # Pattern: https://confluence.zebra.com/display/SPACEKEY/Page+Title
        display_match = re.search(r'/display/([^/]+)/([^/?]+)', url)
        if display_match:
            metadata["space_key"] = display_match.group(1)
            metadata["page_title"] = display_match.group(2).replace('+', ' ').replace('%20', ' ')
        
        # Extract page ID from viewpage.action URLs  
        # Pattern: https://confluence.zebra.com/pages/viewpage.action?pageId=123456
        viewpage_match = re.search(r'/pages/viewpage\.action.*pageId=(\d+)', url)
        if viewpage_match:
            metadata["page_id"] = viewpage_match.group(1)
        
        # Extract space and page from other server URL patterns
        # Pattern: https://confluence.zebra.com/spaces/SPACE/pages/123456/Page+Title
        spaces_match = re.search(r'/spaces/([^/]+)/pages/(\d+)', url)
        if spaces_match:
            metadata["space_key"] = spaces_match.group(1)
            metadata["page_id"] = spaces_match.group(2)
        
        return {
            "type": "confluence_page",
            "crawler": "confluence_api",
            "metadata": metadata
        }
    
    def is_crawlable(self, url: str) -> bool:
        """Check if URL is crawlable (basic validation)"""
        try:
            parsed = urlparse(url)
            return parsed.scheme.lower() in ['http', 'https'] and bool(parsed.netloc)
        except Exception:
            return False
    
    def normalize_url(self, url: str) -> str:
        """Normalize URL for deduplication"""
        try:
            # Remove trailing slashes and fragments
            normalized = url.rstrip('/').split('#')[0]
            
            # Remove common tracking parameters
            parsed = urlparse(normalized)
            if parsed.query:
                # Keep only essential parameters, remove tracking ones
                query_params = parse_qs(parsed.query)
                essential_params = {}
                
                # Keep JIRA/Confluence specific parameters
                for key, values in query_params.items():
                    if key.lower() in ['pageid', 'spaceid', 'issueid']:
                        essential_params[key] = values
                
                # Rebuild URL with essential parameters only
                if essential_params:
                    from urllib.parse import urlencode
                    new_query = urlencode(essential_params, doseq=True)
                    normalized = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}"
                else:
                    normalized = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            
            return normalized
            
        except Exception as e:
            logger.debug(f"URL normalization failed for {url}: {e}")
            return url.rstrip('/')

# Global instance
url_classifier = URLClassifier()