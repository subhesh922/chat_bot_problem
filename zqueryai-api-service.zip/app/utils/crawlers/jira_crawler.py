# app/utils/crawlers/jira_crawler.py

import httpx
import re
from typing import Dict, Any, Optional, List
import logging
from app.config import JIRA_BEARER_TOKEN  # Add this to your config

logger = logging.getLogger(__name__)

class JIRAServerCrawler:
    """Enhanced crawler for JIRA Server issues using JIRA REST API v2"""
    
    def __init__(self, bearer_token: str = None):
        self.bearer_token = bearer_token or JIRA_BEARER_TOKEN
        self.timeout = 30
        self._crawled_issues = set()  # Prevent infinite recursion
    
    async def crawl_issue(self, issue_key: str, base_url: str, include_linked: bool = True, max_depth: int = 1) -> Dict[str, Any]:
        """
        Crawl a JIRA Server issue using the REST API with focused data extraction
        """
        # Reset crawled issues tracking for new crawl session
        if issue_key not in self._crawled_issues:
            self._crawled_issues.clear()
        
        try:
            # Construct API URL - get only essential fields to reduce response size
            api_url = f"{base_url}/rest/api/2/issue/{issue_key}"
            
            # Only expand what we need and request specific fields, including comments
            params = {
                "expand": "names",  # We need names for custom field mapping
                "fields": "key,summary,issuetype,status,priority,assignee,reporter,created,updated,duedate,description,issuelinks,project,comment"
            }
            
            # Set up headers for server authentication
            headers = {
                "Authorization": f"Bearer {self.bearer_token}",
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            logger.info(f"Making JIRA API request to: {api_url}")
            
            # Make API request
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, headers=headers, params=params)
                response.raise_for_status()
                
                issue_data = response.json()
                logger.info(f"Successfully retrieved JIRA data for {issue_key}")
                
                # Debug the actual response structure
                logger.debug(f"Response keys: {list(issue_data.keys())}")
                
                # Extract fields from the response
                fields = issue_data.get("fields", {})
                if not fields:
                    logger.error(f"No fields found in JIRA response for {issue_key}")
                    return self._create_error_response(issue_key, "No field data found in response")
                
                logger.info(f"Found {len(fields)} fields in standard JIRA response")
                
                # Mark this issue as crawled
                self._crawled_issues.add(issue_key)
                
                # Extract linked issues if requested
                linked_issues_data = []
                if include_linked and max_depth > 0:
                    linked_issues_data = await self._crawl_linked_issues(
                        issue_data, fields, base_url, max_depth - 1
                    )
                
                # Convert to markdown with focused content including comments
                markdown = await self._convert_issue_to_markdown(issue_data, fields, linked_issues_data)
                
                # Extract minimal metadata including comments
                metadata = self._extract_focused_metadata(issue_data, fields, linked_issues_data)
                
                logger.info(f"Successfully processed JIRA issue {issue_key} with {len(linked_issues_data)} linked issues")
                
                return {
                    "success": True,
                    "markdown": markdown,
                    "metadata": metadata,
                    "tokens_used": 0,  # API calls don't use AI tokens
                    "error_message": None,
                    "linked_issues": linked_issues_data
                }
                
        except httpx.HTTPStatusError as e:
            error_msg = f"JIRA Server API error {e.response.status_code}: {e.response.text}"
            logger.error(f"Failed to crawl JIRA issue {issue_key}: {error_msg}")
            return self._create_error_response(issue_key, error_msg)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Unexpected error crawling JIRA issue {issue_key}: {error_msg}")
            logger.exception("Full traceback:")
            return self._create_error_response(issue_key, error_msg)
    
    def _extract_focused_metadata(self, issue_data: dict, fields: dict, linked_issues: List[Dict[str, Any]]) -> dict:
        """
        Extract only the essential metadata fields we need
        """
        try:
            issue_key = issue_data.get("key", "Unknown")
            
            logger.info(f"=== EXTRACTING FOCUSED METADATA FOR {issue_key} ===")
            
            # Extract core fields
            issue_type = self._extract_field_value(fields, "issuetype", "name", "Unknown")
            status = self._extract_field_value(fields, "status", "name", "Unknown")
            priority = self._extract_field_value(fields, "priority", "name", "Unknown")
            assignee = self._extract_field_value(fields, "assignee", "displayName", "Unassigned")
            reporter = self._extract_field_value(fields, "reporter", "displayName", "Unknown")
            summary = fields.get("summary", "No summary") or "No summary"
            
            # Build focused metadata - only what we need
            metadata = {
                "issue_key": issue_key,
                "issue_type": issue_type,
                "summary": summary,
                "assignee": assignee,
                "reporter": reporter,
                "status": status,
                "priority": priority,
                "source_type": "jira_server",
                "linked_issues_count": len(linked_issues)
            }
            
            # Add linked issues array - just the keys
            if linked_issues:
                linked_keys = [linked.get("issue_key", "Unknown") for linked in linked_issues]
                metadata["linked_issues"] = linked_keys
                
                # Add detailed linked issues info including comments
                linked_details = []
                for linked in linked_issues:
                    detail = {
                        "issue_key": linked.get("issue_key", "Unknown"),
                        "summary": linked.get("summary", "No summary"),
                        "status": linked.get("status", "Unknown"),
                        "assignee": linked.get("assignee", "Unassigned"),
                        "recent_comments": linked.get("recent_comments", [])
                    }
                    linked_details.append(detail)
                metadata["linked_issues_details"] = linked_details
            else:
                metadata["linked_issues"] = []
                metadata["linked_issues_details"] = []
            
            # Add recent comments from parent issue
            comments_data = fields.get("comment", {})
            metadata["recent_comments"] = self._extract_recent_comments(comments_data)
            
            logger.info(f"Successfully extracted focused metadata for {issue_key}: {len(linked_issues)} linked issues")
            return metadata
            
        except Exception as e:
            logger.error(f"Error extracting focused metadata: {e}")
            logger.exception("Full traceback:")
            return self._get_safe_fallback_metadata(
                issue_data.get("key", "Unknown"), 
                {"extraction_error": str(e)}
            )
    
    def _extract_recent_comments(self, comments_data: Dict[str, Any], limit: int = 5) -> List[Dict[str, Any]]:
        """
        Extract recent comments from JIRA comments data
        
        Args:
            comments_data: The comment data from JIRA API response
            limit: Maximum number of recent comments to extract (default: 5)
        
        Returns:
            List of recent comments with author, date, and body
        """
        try:
            if not isinstance(comments_data, dict):
                return []
            
            # Get comments list from the comments data
            comments_list = comments_data.get('comments', [])
            
            if not comments_list:
                return []
            
            recent_comments = []
            
            # Sort comments by creation date (newest first) and take the limit
            # Comments are usually already sorted by date, but let's be safe
            sorted_comments = sorted(
                comments_list, 
                key=lambda x: x.get('created', ''), 
                reverse=True
            )[:limit]
            
            for comment in sorted_comments:
                try:
                    # Extract comment data
                    comment_data = {
                        'author': self._safe_get_author_name(comment.get('author', {})),
                        'created': comment.get('created', ''),
                        'updated': comment.get('updated', ''),
                        'body': self._clean_comment_body(comment.get('body', '')),
                        'id': comment.get('id', '')
                    }
                    
                    # Only add if we have meaningful content
                    if comment_data['body'].strip():
                        recent_comments.append(comment_data)
                        
                except Exception as e:
                    logger.debug(f"Error processing individual comment: {e}")
                    continue
            
            return recent_comments
            
        except Exception as e:
            logger.warning(f"Error extracting recent comments: {e}")
            return []

    def _safe_get_author_name(self, author_data: Dict[str, Any]) -> str:
        """
        Safely extract author name from author data
        """
        try:
            if isinstance(author_data, dict):
                # Try different fields that might contain the author name
                return (
                    author_data.get('displayName') or 
                    author_data.get('name') or 
                    author_data.get('emailAddress', '').split('@')[0] or
                    'Unknown'
                )
            elif isinstance(author_data, str):
                return author_data
            else:
                return 'Unknown'
        except Exception:
            return 'Unknown'

    def _clean_comment_body(self, body: str) -> str:
        """
        Clean and format comment body text
        """
        try:
            if not body:
                return ''
            
            # If it's a string, return as-is (might be plain text)
            if isinstance(body, str):
                return body.strip()
            
            # If it's a dict (Atlassian Document Format), try to extract text
            if isinstance(body, dict):
                return self._extract_text_from_adf(body)
            
            # Fallback: convert to string
            return str(body).strip()
            
        except Exception as e:
            logger.debug(f"Error cleaning comment body: {e}")
            return str(body) if body else ''

    def _extract_text_from_adf(self, adf_content: Dict[str, Any]) -> str:
        """
        Extract plain text from Atlassian Document Format (ADF) content
        """
        try:
            def extract_text_recursive(node):
                if isinstance(node, dict):
                    # If it's a text node, return the text
                    if node.get('type') == 'text':
                        return node.get('text', '')
                    
                    # If it has content, recurse through it
                    content = node.get('content', [])
                    if content:
                        return ' '.join(extract_text_recursive(child) for child in content)
                    
                    # Handle specific node types
                    if node.get('type') == 'paragraph':
                        return '\n'
                    elif node.get('type') == 'hardBreak':
                        return '\n'
                    
                elif isinstance(node, list):
                    return ' '.join(extract_text_recursive(item) for item in node)
                
                return ''
            
            extracted_text = extract_text_recursive(adf_content)
            return ' '.join(extracted_text.split())  # Clean up whitespace
            
        except Exception as e:
            logger.debug(f"Error extracting text from ADF: {e}")
            return str(adf_content)

    def _format_date(self, date_str: str) -> str:
        """
        Format JIRA date string to a more readable format
        """
        try:
            if not date_str:
                return "Unknown"
            
            # JIRA dates are typically in ISO format: 2024-01-15T10:30:00.000+0000
            # Just extract the date part for readability
            if 'T' in date_str:
                date_part = date_str.split('T')[0]
                return date_part
            
            return date_str
        except Exception:
            return date_str or "Unknown"
    
    def _extract_field_value(self, fields: dict, field_key: str, sub_key: str = None, default: str = "Unknown") -> str:
        """
        Helper method to safely extract field values
        """
        try:
            field_value = fields.get(field_key)
            
            if field_value is None:
                return default
            
            if sub_key and isinstance(field_value, dict):
                return field_value.get(sub_key, default) or default
            elif not sub_key:
                if isinstance(field_value, (str, int, float)):
                    return str(field_value)
                elif isinstance(field_value, dict):
                    # Try common keys for object fields
                    for key in ["displayName", "name", "value"]:
                        if key in field_value and field_value[key] is not None:
                            return str(field_value[key])
            
            return default
            
        except Exception:
            return default
    
    async def _crawl_linked_issues(self, issue_data: dict, fields: dict, base_url: str, remaining_depth: int) -> List[Dict[str, Any]]:
        """
        FIXED: Crawl linked issues and Epic children
        """
        linked_issues = []
        issue_key = issue_data.get("key", "Unknown")
        issue_type = self._extract_field_value(fields, "issuetype", "name", "Unknown")
        
        try:
            # Method 1: Regular issue links
            issue_links = fields.get("issuelinks", [])
            
            if issue_links:
                logger.info(f"Found {len(issue_links)} regular issue links to process")
                
                for link in issue_links:
                    linked_issue_key = None
                    link_type = None
                    
                    # JIRA Server format: inwardIssue/outwardIssue structure
                    if "inwardIssue" in link:
                        linked_issue_key = link["inwardIssue"].get("key")
                        link_type = link.get("type", {}).get("inward", "linked to")
                    elif "outwardIssue" in link:
                        linked_issue_key = link["outwardIssue"].get("key")
                        link_type = link.get("type", {}).get("outward", "links to")
                    
                    if linked_issue_key and linked_issue_key not in self._crawled_issues:
                        linked_issue_data = await self._get_linked_issue_details(linked_issue_key, base_url)
                        if linked_issue_data:
                            linked_issues.append({
                                "issue_key": linked_issue_key,
                                "summary": linked_issue_data.get("summary", "No summary"),
                                "status": linked_issue_data.get("status", "Unknown"),
                                "assignee": linked_issue_data.get("assignee", "Unassigned"),
                                "link_type": link_type or "linked",
                                "recent_comments": linked_issue_data.get("recent_comments", [])
                            })
            
            # Method 2: Epic children (if this is an Epic)
            if issue_type.lower() == "epic":
                logger.info(f"Issue {issue_key} is an Epic, searching for child issues")
                epic_children = await self._get_epic_children(issue_key, base_url)
                
                for child in epic_children:
                    linked_issues.append({
                        "issue_key": child.get("issue_key", "Unknown"),
                        "summary": child.get("summary", "No summary"),
                        "status": child.get("status", "Unknown"),
                        "assignee": child.get("assignee", "Unassigned"),
                        "link_type": "epic child",
                        "recent_comments": child.get("recent_comments", [])
                    })
                
                logger.info(f"Found {len(epic_children)} Epic children")
            
            logger.info(f"Total linked issues found: {len(linked_issues)}")
            
        except Exception as e:
            logger.error(f"Error crawling linked issues: {e}")
            logger.exception("Full traceback:")
        
        return linked_issues
    
    async def _get_epic_children(self, epic_key: str, base_url: str) -> List[Dict[str, str]]:
        """
        Search for issues that have this Epic as their Epic Link
        """
        try:
            # Use JIRA search API to find issues linked to this Epic
            search_url = f"{base_url}/rest/api/2/search"
            
            # JQL query to find issues where Epic Link equals this Epic
            jql = f'"Epic Link" = {epic_key}'
            
            params = {
                "jql": jql,
                "fields": "key,summary,status,assignee,comment",
                "maxResults": 100  # Adjust as needed
            }
            
            headers = {
                "Authorization": f"Bearer {self.bearer_token}",
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            logger.info(f"Searching for Epic children with JQL: {jql}")
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(search_url, headers=headers, params=params)
                response.raise_for_status()
                
                search_data = response.json()
                issues = search_data.get("issues", [])
                
                logger.info(f"Found {len(issues)} Epic children for {epic_key}")
                
                epic_children = []
                for issue in issues:
                    fields = issue.get("fields", {})
                    child_info = {
                        "issue_key": issue.get("key", "Unknown"),
                        "summary": fields.get("summary", "No summary") or "No summary",
                        "status": self._extract_field_value(fields, "status", "name", "Unknown"),
                        "assignee": self._extract_field_value(fields, "assignee", "displayName", "Unassigned"),
                        "recent_comments": self._extract_recent_comments(fields.get("comment", {}))
                    }
                    epic_children.append(child_info)
                
                return epic_children
                
        except Exception as e:
            logger.error(f"Failed to get Epic children for {epic_key}: {e}")
            logger.exception("Full traceback:")
            return []

    async def _get_linked_issue_details(self, issue_key: str, base_url: str) -> Optional[Dict[str, Any]]:
        """
        Get basic details for a linked issue via API call
        """
        try:
            api_url = f"{base_url}/rest/api/2/issue/{issue_key}"
            
            # Only get the fields we need
            params = {
                "fields": "key,summary,status,assignee,comment"
            }
            
            headers = {
                "Authorization": f"Bearer {self.bearer_token}",
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(api_url, headers=headers, params=params)
                response.raise_for_status()
                
                issue_data = response.json()
                fields = issue_data.get("fields", {})
                
                return {
                    "summary": fields.get("summary", "No summary") or "No summary",
                    "status": self._extract_field_value(fields, "status", "name", "Unknown"),
                    "assignee": self._extract_field_value(fields, "assignee", "displayName", "Unassigned"),
                    "recent_comments": self._extract_recent_comments(fields.get("comment", {}))
                }
                
        except Exception as e:
            logger.warning(f"Failed to get details for linked issue {issue_key}: {e}")
            return None
    
    async def _convert_issue_to_markdown(self, issue_data: dict, fields: dict, linked_issues: List[Dict[str, Any]]) -> str:
        """Convert JIRA Server issue JSON to focused markdown format"""
        try:
            # Basic issue information
            issue_key = issue_data.get("key", "UNKNOWN")
            summary = fields.get("summary", "No summary") or "No summary"
            description = fields.get("description", "No description provided")
            if description is None or (isinstance(description, str) and not description.strip()):
                description = "No description provided"
            
            # Extract core fields
            issue_type = self._extract_field_value(fields, "issuetype", "name", "Unknown")
            status = self._extract_field_value(fields, "status", "name", "Unknown")
            priority = self._extract_field_value(fields, "priority", "name", "Unknown")
            assignee_name = self._extract_field_value(fields, "assignee", "displayName", "Unassigned")
            reporter_name = self._extract_field_value(fields, "reporter", "displayName", "Unknown")
            
            # Start building focused markdown
            markdown_parts = [
                f"# {issue_key}: {summary}",
                "",
                "## Issue Details",
                f"- **Type:** {issue_type}",
                f"- **Status:** {status}",
                f"- **Priority:** {priority}",
                f"- **Assignee:** {assignee_name}",
                f"- **Reporter:** {reporter_name}",
                ""
            ]
            
            # Add description if available
            if description and description.strip() and description != "No description provided":
                cleaned_description = self._clean_jira_markup(str(description))
                markdown_parts.extend([
                    "## Description",
                    cleaned_description,
                    ""
                ])
            
            # Add linked issues section - focused format with comments
            if linked_issues:
                markdown_parts.extend(["## Linked Issues", ""])
                
                for linked in linked_issues:
                    issue_key_linked = linked.get("issue_key", "UNKNOWN")
                    summary_linked = linked.get("summary", "No summary")
                    status_linked = linked.get("status", "Unknown")
                    assignee_linked = linked.get("assignee", "Unassigned")
                    recent_comments = linked.get("recent_comments", [])
                    
                    markdown_parts.extend([
                        f"### {issue_key_linked}: {summary_linked}",
                        f"- **Status:** {status_linked}",
                        f"- **Assignee:** {assignee_linked}",
                        ""
                    ])
                    
                    # Add recent comments for this linked issue
                    if recent_comments:
                        markdown_parts.append("#### Recent Comments")
                        for comment in recent_comments:
                            author = comment.get("author", "Unknown")
                            created = comment.get("created", "Unknown")
                            body = comment.get("body", "No comment text")
                            
                            markdown_parts.extend([
                                f"**{author}** - {self._format_date(created)}:",
                                f"> {self._clean_jira_markup(body)[:200]}{'...' if len(body) > 200 else ''}",
                                ""
                            ])
                    
                    markdown_parts.append("---")
                    markdown_parts.append("")
            
            # Add comments section for the main issue
            comments_data = fields.get("comment", {})
            recent_comments = self._extract_recent_comments(comments_data)
            
            if recent_comments:
                markdown_parts.extend(["## Recent Comments", ""])
                
                for comment in recent_comments:
                    author = comment.get("author", "Unknown")
                    created = comment.get("created", "Unknown")
                    body = comment.get("body", "No comment text")
                    
                    markdown_parts.extend([
                        f"### {author} - {self._format_date(created)}",
                        self._clean_jira_markup(body),
                        ""
                    ])
            
            return "\n".join(markdown_parts)
            
        except Exception as e:
            logger.error(f"Error converting JIRA issue to markdown: {e}")
            issue_key = issue_data.get("key", "UNKNOWN")
            return f"# JIRA Issue {issue_key}\n\nError converting issue data to markdown: {str(e)}"
    
    def _clean_jira_markup(self, text: str) -> str:
        """Enhanced JIRA Server wiki markup to markdown conversion"""
        if not text or text in ["No comment text", "No description provided"]:
            return text
        
        try:
            # Basic JIRA markup to markdown conversion
            # Bold: *text* -> **text**
            text = re.sub(r'\*([^*]+)\*', r'**\1**', text)
            
            # Italic: _text_ -> *text*
            text = re.sub(r'_([^_]+)_', r'*\1*', text)
            
            # Code: {{text}} -> `text`
            text = re.sub(r'\{\{([^}]+)\}\}', r'`\1`', text)
            
            # Code blocks: {code}...{code} -> ```...```
            text = re.sub(r'\{code(?::[^}]*)?\}(.*?)\{code\}', r'```\1```', text, flags=re.DOTALL)
            
            # Headers: h1. text -> # text
            text = re.sub(r'^h([1-6])\.\s*(.+)$', lambda m: '#' * int(m.group(1)) + ' ' + m.group(2), text, flags=re.MULTILINE)
            
            # Lists: * item -> - item
            text = re.sub(r'^\* ', '- ', text, flags=re.MULTILINE)
            text = re.sub(r'^# ', '1. ', text, flags=re.MULTILINE)  # Numbered lists
            
            # Links: [text|url] -> [text](url)
            text = re.sub(r'\[([^|\]]+)\|([^\]]+)\]', r'[\1](\2)', text)
            
            # Remove excessive newlines
            text = re.sub(r'\n{3,}', '\n\n', text)
            
            return text.strip()
            
        except Exception as e:
            logger.debug(f"Error cleaning JIRA markup: {e}")
            return text
    
    def _create_error_response(self, issue_key: str, error_msg: str) -> dict:
        """Create standardized error response"""
        return {
            "success": False,
            "markdown": f"<!-- Failed to crawl JIRA issue {issue_key}: {error_msg} -->",
            "metadata": self._get_safe_fallback_metadata(issue_key, {"error": "crawl_failed", "error_details": error_msg}),
            "tokens_used": 0,
            "error_message": error_msg,
            "linked_issues": []
        }
    
    def _get_safe_fallback_metadata(self, issue_key: str, extra_data: dict = None) -> dict:
        """Return safe fallback metadata when extraction fails"""
        metadata = {
            "issue_key": issue_key or "Unknown",
            "issue_type": "Unknown",
            "summary": "No summary",
            "assignee": "Unknown",
            "reporter": "Unknown",
            "status": "Unknown",
            "priority": "Unknown",
            "source_type": "jira_server",
            "linked_issues_count": 0,
            "linked_issues": [],
            "linked_issues_details": [],
            "recent_comments": []
        }
        
        if extra_data:
            metadata.update(extra_data)
        
        return metadata

# Global instance
jira_crawler = JIRAServerCrawler()