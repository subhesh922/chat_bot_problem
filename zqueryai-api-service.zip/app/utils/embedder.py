# app/utils/embedder.py

import uuid
import hashlib
from typing import List, Dict, Any
import asyncio
import tiktoken

from app.config import (
    QDRANT_ENDPOINT,
    QDRANT_API_KEY,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_EMBEDDINGS_MODEL,
    AZURE_OPENAI_EMBEDDINGS_API_VERSION
)

# 🔐 Hash API key to store creator reference
def hash_api_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()

# 🧠 Token-based smart chunker
def smart_chunk_markdown(markdown: str, max_tokens=400, overlap=25) -> List[str]:
    """
    Intelligently chunk markdown content based on token count
    """
    tokenizer = tiktoken.get_encoding("cl100k_base")
    tokens = tokenizer.encode(markdown)
    chunks = []
    start = 0
    
    while start < len(tokens):
        end = start + max_tokens
        chunk_tokens = tokens[start:end]
        chunk_text = tokenizer.decode(chunk_tokens)
        chunks.append(chunk_text)
        start += max_tokens - overlap
    
    return chunks

# 🧬 Deterministic ID using hash of content and metadata
def deterministic_id(chunk: str, metadata: Dict[str, Any]) -> str:
    """
    Generate deterministic UUID for chunk based on content and metadata
    """
    base_string = chunk + "|" + str(sorted(metadata.items()))
    hash_value = hashlib.sha256(base_string.encode("utf-8")).digest()[:16]
    return str(uuid.UUID(bytes=hash_value))

# ⚡ Async OpenAI embedding function with token tracking
async def embed_chunk(text: str) -> Dict[str, Any]:
    """
    Generate embedding for a single chunk using text-embedding-3-small
    Returns: {"embedding": List[float], "tokens_used": int}
    """
    from openai import AsyncAzureOpenAI
    
    client = AsyncAzureOpenAI(
        api_key=AZURE_OPENAI_KEY,
        api_version=AZURE_OPENAI_EMBEDDINGS_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT
    )
    
    try:
        response = await client.embeddings.create(
            model=AZURE_OPENAI_EMBEDDINGS_MODEL,
            input=text
        )
        
        return {
            "embedding": response.data[0].embedding,
            "tokens_used": response.usage.total_tokens
        }
    except Exception as e:
        # Return zero vector on error with 0 tokens
        return {
            "embedding": [0.0] * 1536,  # text-embedding-3-small dimension
            "tokens_used": 0
        }

# 🚀 Main async upsert to Qdrant with comprehensive token tracking
async def upsert_to_qdrant(
    markdown: str,
    metadata: Dict[str, Any],
    collection_name: str,
    api_key: str
) -> Dict[str, Any]:
    """
    Process markdown, generate embeddings, and upsert to Qdrant
    Returns comprehensive result including token usage
    """
    if not isinstance(metadata, dict):
        raise ValueError("❌ Metadata must be a dictionary.")

    from qdrant_client import QdrantClient
    from qdrant_client.http.models import PointStruct, VectorParams, Distance

    # Initialize Qdrant client
    qdrant = QdrantClient(
        url=QDRANT_ENDPOINT,
        api_key=QDRANT_API_KEY,
        prefer_grpc=False,
        https=True,
        timeout=60,
        verify=False
    )

    # 🧱 Create collection if missing
    collections = [c.name for c in qdrant.get_collections().collections]
    if collection_name not in collections:
        qdrant.recreate_collection(
            collection_name=collection_name,
            vectors_config=VectorParams(size=1536, distance=Distance.COSINE)
        )

    # Add creator hash to metadata
    metadata['creator_api_key_hash'] = hash_api_key(api_key)

    # 📖 Chunk the markdown content
    chunks = smart_chunk_markdown(markdown)
    
    if not chunks:
        return {
            "message": "✅ Empty document processed",
            "collection": collection_name,
            "chunks": 0,
            "metadata": metadata,
            "tokens_used": 0
        }

    # 🔢 Generate embeddings for all chunks
    embed_results = await asyncio.gather(*[embed_chunk(chunk) for chunk in chunks])

    # 📦 Prepare points for Qdrant
    points = []
    total_tokens = 0

    for i, (chunk, embed_result) in enumerate(zip(chunks, embed_results)):
        embedding = embed_result["embedding"]
        tokens_used = embed_result["tokens_used"]
        total_tokens += tokens_used

        # Prepare payload for this chunk
        payload = {
            **{k: v for k, v in metadata.items() if v is not None},
            "chunkIndex": i,
            "text": chunk
        }
        
        point_id = deterministic_id(chunk, payload)
        points.append(PointStruct(id=point_id, vector=embedding, payload=payload))

    # 🚀 Upsert to Qdrant
    try:
        qdrant.upsert(collection_name=collection_name, points=points)
        message = "✅ Document processed and embedded successfully"
    except Exception as e:
        message = f"⚠️ Partial success - embeddings generated but upsert failed: {str(e)}"

    return {
        "message": message,
        "collection": collection_name,
        "chunks": len(points),
        "metadata": metadata,
        "tokens_used": total_tokens
    }

# 🔄 Batch processing helper
async def batch_upsert_to_qdrant(
    documents: List[Dict[str, Any]],
    collection_name: str,
    api_key: str,
    global_metadata: Dict[str, Any] = None
) -> List[Dict[str, Any]]:
    """
    Process multiple documents in parallel
    Returns list of individual results
    """
    tasks = []
    
    for doc in documents:
        # Merge global metadata with document-specific metadata
        merged_metadata = {
            **(global_metadata or {}),
            **(doc.get("metadata", {}) or {})
        }
        
        tasks.append(
            upsert_to_qdrant(
                markdown=doc["markdown"],
                metadata=merged_metadata,
                collection_name=collection_name,
                api_key=api_key
            )
        )
    
    results = await asyncio.gather(*tasks)
    return results