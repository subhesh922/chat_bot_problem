# app/utils/retriever.py

from typing import List, Dict, Any, Optional, Tuple
from qdrant_client.http.models import Filter, FieldCondition, MatchAny, SearchParams
from app.config import (
    QDRANT_ENDPOINT,
    QDRANT_API_KEY,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_EMBEDDINGS_API_VERSION,
    AZURE_OPENAI_EMBEDDINGS_MODEL
)

# 🔍 Generate embedding vector from user query with token tracking
def embed_query_with_tokens(query: str) -> Tuple[List[float], int]:
    """
    Generate embedding for user query using text-embedding-3-small
    Returns: (embedding_vector, tokens_used)
    """
    from openai import AzureOpenAI
    
    client = AzureOpenAI(
        api_key=AZURE_OPENAI_KEY,
        api_version=AZURE_OPENAI_EMBEDDINGS_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT
    )
    
    try:
        response = client.embeddings.create(
            model=AZURE_OPENAI_EMBEDDINGS_MODEL,
            input=query
        )
        
        embedding_vector = response.data[0].embedding
        tokens_used = response.usage.total_tokens
        
        return embedding_vector, tokens_used
        
    except Exception as e:
        # Return zero vector and 0 tokens on error
        return [0.0] * 1536, 0

# 🔍 Legacy function for backward compatibility (no token tracking)
def embed_query(query: str) -> List[float]:
    """
    Generate embedding vector from user query (legacy - no token tracking)
    For backward compatibility only
    """
    embedding_vector, _ = embed_query_with_tokens(query)
    return embedding_vector

# 🧠 Build Qdrant filter from dict of key:value or key:[values] - FIXED VERSION
def build_filter(filters: Dict[str, Any]) -> Optional[Filter]:
    """
    Convert filter dictionary to Qdrant Filter object
    Supports both single values and lists of values
    """
    if not filters:
        return None

    conditions = []
    for key, value in filters.items():
        # ✅ Handle different value types properly
        if isinstance(value, list):
            # Value is already a list - use as is
            conditions.append(FieldCondition(key=key, match=MatchAny(any=value)))
        elif isinstance(value, (str, int, float, bool)):
            # Single value - wrap in list for MatchAny
            conditions.append(FieldCondition(key=key, match=MatchAny(any=[value])))
        else:
            # For any other type, convert to string and wrap in list
            conditions.append(FieldCondition(key=key, match=MatchAny(any=[str(value)])))
    
    return Filter(must=conditions)

# 📥 Main retrieval function with token tracking
def retrieve_top_chunks_with_tokens(
    query: str,
    collection: str,
    filters: Dict[str, Any] = {},
    top_k: int = 8
) -> Tuple[List[Dict[str, Any]], int]:
    """
    Retrieve top-k unique context chunks from Qdrant with token tracking
    Returns: (chunks, query_embedding_tokens_used)
    """
    from qdrant_client import QdrantClient
    
    # Initialize Qdrant client
    qdrant = QdrantClient(
        url=QDRANT_ENDPOINT,
        api_key=QDRANT_API_KEY,
        prefer_grpc=False,
        https=True,
        timeout=60,
        verify=False
    )

    # Generate query embedding with token tracking
    vector, tokens_used = embed_query_with_tokens(query)
    
    # Build filter with proper array handling
    qdrant_filter = build_filter(filters)

    try:
        # Log the filter being applied for debugging
        if qdrant_filter:
            print(f"🔍 Applying Qdrant filter: {filters}")
        
        # Perform semantic search
        results = qdrant.search(
            collection_name=collection,
            query_vector=vector,
            limit=top_k,
            search_params=SearchParams(hnsw_ef=128),
            query_filter=qdrant_filter
        )

        # Deduplicate chunks based on text content
        seen_texts = set()
        unique_chunks = []
        
        for hit in results:
            payload = hit.payload or {}
            text = payload.get("text", "")
            
            if text and text not in seen_texts:
                unique_chunks.append(payload)
                seen_texts.add(text)

        print(f"📊 Retrieved {len(unique_chunks)} unique chunks from {len(results)} total results")
        return unique_chunks, tokens_used
        
    except Exception as e:
        print(f"❌ Retrieval error: {str(e)}")
        # Return empty results on error
        return [], tokens_used

# 📥 Legacy function for backward compatibility (no token tracking)
def retrieve_top_chunks(
    query: str,
    collection: str,
    filters: Dict[str, Any] = {},
    top_k: int = 8
) -> List[Dict[str, Any]]:
    """
    Retrieve top-k unique context chunks from Qdrant (legacy - no token tracking)
    For backward compatibility only
    """
    chunks, _ = retrieve_top_chunks_with_tokens(query, collection, filters, top_k)
    return chunks

# 🔍 Enhanced retrieval with metadata enrichment
def retrieve_with_metadata_enrichment(
    query: str,
    collection: str,
    filters: Dict[str, Any] = {},
    top_k: int = 8,
    include_scores: bool = False
) -> Tuple[List[Dict[str, Any]], int, Dict[str, Any]]:
    """
    Enhanced retrieval with additional metadata about the search operation
    Returns: (chunks, tokens_used, search_metadata)
    """
    from qdrant_client import QdrantClient
    
    qdrant = QdrantClient(
        url=QDRANT_ENDPOINT,
        api_key=QDRANT_API_KEY,
        prefer_grpc=False,
        https=True,
        timeout=60,
        verify=False
    )

    # Generate query embedding with token tracking
    vector, tokens_used = embed_query_with_tokens(query)
    qdrant_filter = build_filter(filters)

    try:
        # Perform search
        results = qdrant.search(
            collection_name=collection,
            query_vector=vector,
            limit=top_k,
            search_params=SearchParams(hnsw_ef=128),
            query_filter=qdrant_filter
        )

        # Process results
        seen_texts = set()
        unique_chunks = []
        scores = []
        
        for hit in results:
            payload = hit.payload or {}
            text = payload.get("text", "")
            
            if text and text not in seen_texts:
                if include_scores:
                    payload["similarity_score"] = hit.score
                unique_chunks.append(payload)
                scores.append(hit.score)
                seen_texts.add(text)

        # Prepare search metadata
        search_metadata = {
            "total_results_found": len(results),
            "unique_chunks_returned": len(unique_chunks),
            "filters_applied": bool(filters),
            "collection_searched": collection,
            "average_similarity_score": sum(scores) / len(scores) if scores else 0.0,
            "query_embedding_tokens": tokens_used
        }

        return unique_chunks, tokens_used, search_metadata
        
    except Exception as e:
        # Return empty results with error info
        error_metadata = {
            "error": str(e),
            "total_results_found": 0,
            "unique_chunks_returned": 0,
            "filters_applied": bool(filters),
            "collection_searched": collection,
            "query_embedding_tokens": tokens_used
        }
        return [], tokens_used, error_metadata