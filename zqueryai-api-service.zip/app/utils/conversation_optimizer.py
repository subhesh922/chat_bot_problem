# app/utils/conversation_optimizer.py

import tiktoken
from typing import List, Dict, Any, Optional

class ConversationOptimizer:
    """Optimizes conversation history for token efficiency"""
    
    def __init__(self, max_history_tokens: int = 4000, max_exchanges: int = 10):
        self.max_history_tokens = max_history_tokens
        self.max_exchanges = max_exchanges
        self.tokenizer = tiktoken.get_encoding("cl100k_base")
    
    def optimize_conversation_history(self, history: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Optimize conversation history to stay within token limits"""
        if not history:
            return []
        
        # Step 1: Limit to recent exchanges
        recent_history = self._limit_recent_exchanges(history)
        
        # Step 2: Check token count
        token_count = self._count_history_tokens(recent_history)
        
        # Step 3: If still too many tokens, trim further
        if token_count > self.max_history_tokens:
            recent_history = self._trim_by_tokens(recent_history)
        
        # Step 4: Remove redundant context from history
        optimized_history = self._remove_redundant_context(recent_history)
        
        return optimized_history
    
    def _limit_recent_exchanges(self, history: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Keep only the most recent N exchanges"""
        # An exchange is a user message + assistant response
        # So we need pairs of messages
        
        if len(history) <= (self.max_exchanges * 2):
            return history
        
        # Take the last max_exchanges * 2 messages (user + assistant pairs)
        return history[-(self.max_exchanges * 2):]
    
    def _count_history_tokens(self, history: List[Dict[str, str]]) -> int:
        """Count total tokens in conversation history"""
        total_tokens = 0
        for message in history:
            content = message.get("content", "")
            total_tokens += len(self.tokenizer.encode(content))
        return total_tokens
    
    def _trim_by_tokens(self, history: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Trim history to fit within token limit"""
        if not history:
            return []
        
        # Start from the end and work backwards
        trimmed_history = []
        current_tokens = 0
        
        for message in reversed(history):
            content = message.get("content", "")
            message_tokens = len(self.tokenizer.encode(content))
            
            if current_tokens + message_tokens <= self.max_history_tokens:
                trimmed_history.insert(0, message)
                current_tokens += message_tokens
            else:
                # If we can't fit the full message, try to truncate it
                if not trimmed_history:  # Always keep at least one message
                    truncated_content = self._truncate_message_content(
                        content, self.max_history_tokens
                    )
                    trimmed_message = {**message, "content": truncated_content}
                    trimmed_history.insert(0, trimmed_message)
                break
        
        return trimmed_history
    
    def _truncate_message_content(self, content: str, max_tokens: int) -> str:
        """Truncate message content to fit within token limit"""
        tokens = self.tokenizer.encode(content)
        if len(tokens) <= max_tokens:
            return content
        
        # Truncate to max_tokens and add ellipsis
        truncated_tokens = tokens[:max_tokens - 10]  # Reserve tokens for ellipsis
        truncated_content = self.tokenizer.decode(truncated_tokens)
        return truncated_content + "... [truncated]"
    
    def _remove_redundant_context(self, history: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Remove redundant context information from assistant responses"""
        optimized_history = []
        
        for message in history:
            if message.get("role") == "assistant":
                # Remove source citations and metadata from history
                content = message.get("content", "")
                cleaned_content = self._clean_assistant_response(content)
                optimized_message = {**message, "content": cleaned_content}
                optimized_history.append(optimized_message)
            else:
                optimized_history.append(message)
        
        return optimized_history
    
    def _clean_assistant_response(self, content: str) -> str:
        """Clean assistant response by removing redundant information"""
        # Remove source citations that might be repeated
        import re
        
        # Remove patterns like "According to [source]" at the beginning
        content = re.sub(r'^According to [^,]+,\s*', '', content)
        content = re.sub(r'^Based on [^,]+,\s*', '', content)
        
        # Remove repeated context indicators
        content = re.sub(r'As mentioned in the (document|context|file)[^.]*\.\s*', '', content)
        
        # Clean up extra whitespace
        content = re.sub(r'\n\s*\n', '\n\n', content)
        content = content.strip()
        
        return content
    
    def should_summarize_old_context(self, history: List[Dict[str, str]]) -> bool:
        """Determine if old conversation should be summarized"""
        if len(history) < 16:  # Less than 8 exchanges
            return False
        
        total_tokens = self._count_history_tokens(history)
        return total_tokens > (self.max_history_tokens * 1.5)
    
    def create_conversation_summary(self, old_history: List[Dict[str, str]]) -> str:
        """Create a summary of older conversation parts"""
        if not old_history:
            return ""
        
        # Extract key topics and decisions from old conversation
        topics = []
        for i, message in enumerate(old_history):
            if message.get("role") == "user":
                user_query = message.get("content", "")
                # Get the next assistant response if available
                if i + 1 < len(old_history) and old_history[i + 1].get("role") == "assistant":
                    assistant_response = old_history[i + 1].get("content", "")
                    # Create a brief summary of this exchange
                    topic_summary = self._extract_topic_summary(user_query, assistant_response)
                    if topic_summary:
                        topics.append(topic_summary)
        
        if topics:
            return "Previous conversation summary: " + " | ".join(topics[:5])  # Limit to 5 topics
        
        return ""
    
    def _extract_topic_summary(self, user_query: str, assistant_response: str) -> str:
        """Extract a brief topic summary from a user-assistant exchange"""
        # Simple extraction - could be enhanced with NLP
        user_query = user_query.strip()
        
        # Limit to first 50 characters of user query
        if len(user_query) > 50:
            user_query = user_query[:47] + "..."
        
        # Try to extract key finding from assistant response
        sentences = assistant_response.split('.')
        key_finding = ""
        if sentences:
            # Take first meaningful sentence
            for sentence in sentences[:2]:
                if len(sentence.strip()) > 20:
                    key_finding = sentence.strip()[:80] + "..." if len(sentence) > 80 else sentence.strip()
                    break
        
        if key_finding:
            return f"Q: {user_query} A: {key_finding}"
        else:
            return f"Q: {user_query}"

# Global optimizer instance
conversation_optimizer = ConversationOptimizer(max_history_tokens=4000, max_exchanges=8)