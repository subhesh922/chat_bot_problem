# app/utils/extractors/excel_extractor.py

from fastapi import UploadFile
from typing import Dict, Any
import pandas as pd
from io import BytesIO
import openpyxl

def find_column_regions(row, max_gap=1):
    """Find contiguous non-empty column regions split by empty columns"""
    regions = []
    start = None
    gap_count = 0

    for i, val in enumerate(row):
        if val is not None:
            if start is None:
                start = i
            gap_count = 0
        else:
            if start is not None:
                gap_count += 1
                if gap_count > max_gap:
                    regions.append((start, i - gap_count))
                    start = None
                    gap_count = 0

    if start is not None:
        regions.append((start, len(row) - 1))

    return regions

def extract_tables_from_sheet(ws):
    """Extract tables from worksheet"""
    rows = list(ws.values)
    tables = []
    current_rows = []

    for i, row in enumerate(rows):
        if all(cell is None for cell in row):
            if current_rows:
                tables.extend(process_row_group(current_rows))
                current_rows = []
        else:
            current_rows.append(row)

    if current_rows:
        tables.extend(process_row_group(current_rows))

    return tables

def process_row_group(row_group):
    """Detects multiple horizontally separated tables in a row group"""
    if not row_group:
        return []

    first_row = row_group[0]
    col_regions = find_column_regions(first_row)

    tables = []
    for idx, (start_col, end_col) in enumerate(col_regions):
        extracted = []
        for row in row_group:
            segment = row[start_col:end_col + 1]
            if any(cell is not None for cell in segment):
                extracted.append(segment)

        df = pd.DataFrame(extracted)
        df.dropna(how='all', inplace=True)
        df.dropna(axis=1, how='all', inplace=True)

        if df.shape[0] >= 2:
            df.columns = df.iloc[0]
            df = df[1:]
            tables.append((f"Table {len(tables)+1}", df.reset_index(drop=True)))

    return tables

async def extract_excel_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract content from Excel file with token tracking and link support
    
    Note: Excel files typically don't contain images requiring OCR,
    so this will usually return 0 tokens unless embedded images are found.
    Links are not extracted from Excel files currently.
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        markdown_output = []
        total_tokens_used = 0  # Excel typically has no OCR content

        wb = openpyxl.load_workbook(filename=BytesIO(contents), data_only=True)
        
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            markdown_output.append(f"### {sheet_name}\n")

            tables = extract_tables_from_sheet(ws)
            if not tables:
                markdown_output.append("_No tables detected._\n")
                continue

            for table_name, df in tables:
                markdown_output.append(f"#### {table_name}\n\n")
                try:
                    markdown_output.append(df.to_markdown(index=False))
                except Exception as e:
                    # Fallback if to_markdown fails
                    markdown_output.append(f"_Table conversion failed: {str(e)}_")
                markdown_output.append("\n\n---\n")

        wb.close()
        
        final_markdown = "\n".join(markdown_output) if markdown_output else "*No content found in Excel file.*"
        
        return {
            "markdown": final_markdown,
            "tokens_used": total_tokens_used,  # Usually 0 for Excel files
            "links": []  # No link extraction for Excel currently
        }
        
    except Exception as e:
        return {
            "markdown": f"<!-- Excel extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_excel(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking)
    """
    try:
        result = await extract_excel_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        return f"<!-- Excel extraction failed: {str(e)} -->"
