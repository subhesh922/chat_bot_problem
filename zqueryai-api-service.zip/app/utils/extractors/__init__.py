# app/utils/extractors/__init__.py

import os
import io
import mimetypes
from pathlib import Path
from fastapi import UploadFile
from typing import Dict, Any

from app.utils.extractors.pdf_extractor import extract_pdf_with_tokens
from app.utils.extractors.txt_extractor import extract_txt_with_tokens
from app.utils.extractors.docx_extractor import extract_docx_with_tokens
from app.utils.extractors.pptx_extractor import extract_pptx_with_tokens
from app.utils.extractors.excel_extractor import extract_excel_with_tokens
from app.utils.extractors.csv_extractor import extract_csv_with_tokens
from app.utils.extractors.img_extractor import extract_image_with_tokens
from app.utils.extractors.other_extractor import extract_other_with_tokens
from app.utils.extractors.link_extractor import link_extractor

# Enhanced MIME map for token-tracking extractors with link support
MIME_MAP_WITH_TOKENS = {
    "application/pdf": extract_pdf_with_tokens,
    "text/plain": extract_txt_with_tokens,
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": extract_docx_with_tokens,
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": extract_pptx_with_tokens,
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": extract_excel_with_tokens,
    "application/vnd.ms-excel": extract_excel_with_tokens,
    "text/csv": extract_csv_with_tokens,
    "image/jpg": extract_image_with_tokens,
    "image/jpeg": extract_image_with_tokens,
    "image/png": extract_image_with_tokens,
    "image/svg+xml": extract_image_with_tokens,
}

EXT_MAP_WITH_TOKENS = {
    ".pdf": extract_pdf_with_tokens,
    ".txt": extract_txt_with_tokens,
    ".docx": extract_docx_with_tokens,
    ".pptx": extract_pptx_with_tokens,
    ".xlsx": extract_excel_with_tokens,
    ".xls": extract_excel_with_tokens,
    ".csv": extract_csv_with_tokens,
    ".jpg": extract_image_with_tokens,
    ".jpeg": extract_image_with_tokens,
    ".png": extract_image_with_tokens,
    ".svg": extract_image_with_tokens,
}

# Legacy imports for backward compatibility
from app.utils.extractors.pdf_extractor import extract_pdf
from app.utils.extractors.txt_extractor import extract_txt
from app.utils.extractors.docx_extractor import extract_docx
from app.utils.extractors.pptx_extractor import extract_pptx
from app.utils.extractors.excel_extractor import extract_excel
from app.utils.extractors.csv_extractor import extract_csv
from app.utils.extractors.img_extractor import extract_image
from app.utils.extractors.other_extractor import extract_other

# Legacy MIME map (for backward compatibility)
MIME_MAP = {
    "application/pdf": extract_pdf,
    "text/plain": extract_txt,
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": extract_docx,
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": extract_pptx,
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": extract_excel,
    "application/vnd.ms-excel": extract_excel,
    "text/csv": extract_csv,
    "image/jpg": extract_image,
    "image/jpeg": extract_image,
    "image/png": extract_image,
    "image/svg+xml": extract_image,
}

EXT_MAP = {
    ".pdf": extract_pdf,
    ".txt": extract_txt,
    ".docx": extract_docx,
    ".pptx": extract_pptx,
    ".xlsx": extract_excel,
    ".xls": extract_excel,
    ".csv": extract_csv,
    ".jpg": extract_image,
    ".jpeg": extract_image,
    ".png": extract_image,
    ".svg": extract_image,
}

async def extract_file_as_markdown_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Enhanced extraction function that returns markdown, token usage, and links
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        
        # Get file extension and MIME type
        ext = Path(file.filename).suffix.lower() if file.filename else ""
        mime, _ = mimetypes.guess_type(file.filename) if file.filename else (None, None)
        
        # Find appropriate token-tracking extractor
        extractor = EXT_MAP_WITH_TOKENS.get(ext) or MIME_MAP_WITH_TOKENS.get(mime)
        
        if extractor:
            # Use specific extractor with token tracking and link detection
            result = await extractor(UploadFile(filename=file.filename, file=io.BytesIO(contents)))
        else:
            # Fallback to generic extractor
            result = await extract_other_with_tokens(UploadFile(filename=file.filename, file=io.BytesIO(contents)))
        
        # Ensure result format consistency
        if isinstance(result, dict) and "markdown" in result and "tokens_used" in result:
            # Add links if not present (for extractors that don't support links yet)
            if "links" not in result:
                result["links"] = []
            return result
        elif isinstance(result, str):
            # Legacy extractor returned just string
            return {"markdown": result, "tokens_used": 0, "links": []}
        else:
            # Unexpected format
            return {"markdown": str(result), "tokens_used": 0, "links": []}
            
    except Exception as e:
        # Return error markdown with 0 tokens and no links on failure
        return {
            "markdown": f"<!-- Extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_file_as_markdown(file: UploadFile) -> str:
    """
    Legacy extraction function for backward compatibility
    Returns only the markdown string (no token tracking or links)
    """
    try:
        contents = await file.read()
        
        ext = Path(file.filename).suffix.lower() if file.filename else ""
        mime, _ = mimetypes.guess_type(file.filename) if file.filename else (None, None)
        
        # Use legacy extractors
        extractor = EXT_MAP.get(ext) or MIME_MAP.get(mime)
        
        if extractor:
            return await extractor(UploadFile(filename=file.filename, file=io.BytesIO(contents)))
        else:
            return await extract_other(UploadFile(filename=file.filename, file=io.BytesIO(contents)))
            
    except Exception as e:
        return f"<!-- Extraction failed: {str(e)} -->"

def get_supported_formats() -> Dict[str, Any]:
    """
    Get information about supported file formats and their capabilities
    """
    return {
        "supported_extensions": list(EXT_MAP_WITH_TOKENS.keys()),
        "supported_mime_types": list(MIME_MAP_WITH_TOKENS.keys()),
        "token_tracking_support": {
            "pdf": "OCR for embedded images + link extraction",
            "docx": "OCR for embedded images + link extraction", 
            "pptx": "OCR for embedded images + link extraction",
            "xlsx": "OCR for embedded images",
            "txt": "No tokens (text-only)",
            "csv": "No tokens (text-only)",
            "images": "Full OCR processing"
        },
        "link_extraction_support": {
            "pdf": "Hyperlink annotations + explicit URLs",
            "docx": "Document hyperlinks + explicit URLs",
            "pptx": "Slide hyperlinks + explicit URLs",
            "xlsx": "Limited support",
            "other_formats": "Not supported"
        },
        "extractor_mapping": {
            "text_files": [".txt", ".csv"],
            "office_documents": [".docx", ".pptx", ".xlsx", ".xls"],
            "pdf_documents": [".pdf"],
            "images": [".jpg", ".jpeg", ".png", ".svg"]
        }
    }

def get_extractor_info(filename: str) -> Dict[str, Any]:
    """
    Get information about which extractor would be used for a given filename
    """
    ext = Path(filename).suffix.lower()
    mime, _ = mimetypes.guess_type(filename)
    
    extractor = EXT_MAP_WITH_TOKENS.get(ext) or MIME_MAP_WITH_TOKENS.get(mime)
    
    # Determine link extraction capability
    link_capable_extensions = [".pdf", ".docx", ".pptx"]
    supports_links = ext in link_capable_extensions
    
    return {
        "filename": filename,
        "extension": ext,
        "mime_type": mime,
        "extractor_function": extractor.__name__ if extractor else "extract_other_with_tokens",
        "token_tracking_enabled": True,
        "link_extraction_enabled": supports_links,
        "expected_token_usage": (
            "High (OCR processing)" if ext in [".jpg", ".jpeg", ".png", ".svg"] 
            else "Low (potential embedded images)" if ext in [".pdf", ".docx", ".pptx", ".xlsx", ".xls"]
            else "None (text-only processing)"
        ),
        "expected_link_extraction": (
            "Hyperlinks + explicit URLs" if ext in [".pdf", ".docx", ".pptx"]
            else "Not supported"
        )
    }