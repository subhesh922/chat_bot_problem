# app/utils/extractors/pdf_extractor.py

from fastapi import UploadFile
from typing import Dict, Any, List
import fitz  # PyMuPDF
from .ocr_utils import run_ocr_on_image_bytes
from .link_extractor import link_extractor
import re
import logging

logger = logging.getLogger(__name__)

def extract_pdf_links(doc: fitz.Document, text_content: str) -> List[Dict[str, Any]]:
    """
    Extract hyperlinks from PDF document with deduplication
    """
    links = []
    
    try:
        for page_num, page in enumerate(doc):
            # Extract link annotations
            for link in page.get_links():
                if 'uri' in link and link['uri']:
                    url = link['uri']
                    
                    # Get the rectangle coordinates for context
                    rect = link.get('from', None)
                    anchor_text = ""
                    context = ""
                    
                    if rect:
                        try:
                            # Extract text within the link rectangle
                            link_rect = fitz.Rect(rect)
                            anchor_text = page.get_textbox(link_rect).strip()
                            
                            # Get broader context around the link
                            expanded_rect = link_rect + fitz.Rect(-50, -20, 50, 20)  # Expand rectangle
                            context = page.get_textbox(expanded_rect).strip()
                        except Exception as e:
                            logger.debug(f"Could not extract link text context: {e}")
                    
                    links.append({
                        'url': url,
                        'anchor_text': anchor_text,
                        'link_type': 'hyperlink',
                        'context': context,
                        'page': page_num + 1
                    })
            
            # Also look for explicit URLs in the text content with deduplication
            page_text = page.get_text()
            url_matches = re.finditer(r'https?://[^\s<>"{}|\\^`\[\]]+', page_text, re.IGNORECASE)
            
            # Create a set of already found URLs (normalized) to avoid duplicates
            existing_urls = set()
            for link in links:
                # Normalize URLs by removing trailing slashes for comparison
                normalized_url = link['url'].rstrip('/')
                existing_urls.add(normalized_url)
            
            for match in url_matches:
                url = match.group()
                start_pos = match.start()
                
                # Normalize URL for comparison
                normalized_url = url.rstrip('/')
                
                # Only add if we haven't already captured this URL as a hyperlink
                if normalized_url not in existing_urls:
                    # Extract context around the URL
                    context_start = max(0, start_pos - 50)
                    context_end = min(len(page_text), match.end() + 50)
                    context = page_text[context_start:context_end].strip()
                    
                    links.append({
                        'url': url,
                        'anchor_text': url,  # For explicit URLs, anchor text is the URL itself
                        'link_type': 'explicit',
                        'context': context,
                        'page': page_num + 1
                    })
                    
                    # Add to existing URLs set
                    existing_urls.add(normalized_url)
    
    except Exception as e:
        logger.error(f"Error extracting links from PDF: {e}")
    
    return links

async def extract_pdf_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract content from PDF with token tracking for OCR operations and link detection
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        doc = fitz.open(stream=contents, filetype="pdf")
        
        markdown_parts = []
        total_tokens_used = 0
        all_text_content = ""

        for i, page in enumerate(doc, start=1):
            section = [f"### Page {i}"]

            # Extract native text (no tokens used)
            text = page.get_text().strip()
            if text:
                section.append(text)
                all_text_content += f" {text}"  # Accumulate for link context

            # Extract and process images with OCR
            for img_index, img_info in enumerate(page.get_images(full=True)):
                xref = img_info[0]
                try:
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    
                    # Run OCR with token tracking
                    ocr_result = await run_ocr_on_image_bytes(image_bytes)
                    ocr_text = ocr_result.get("text", "")
                    ocr_tokens = ocr_result.get("tokens_used", 0)
                    
                    # Add tokens to total
                    total_tokens_used += ocr_tokens
                    
                    if ocr_text and ocr_text.strip():
                        section.append(f"**[Image {img_index + 1}: OCR Text]**\n{ocr_text}")
                        all_text_content += f" {ocr_text}"  # Include OCR text for link context
                    else:
                        section.append(f"*Image {img_index + 1}: No text detected*")
                        
                except Exception as e:
                    section.append(f"*Failed OCR on image {img_index + 1}: {str(e)}*")
                    # No tokens added for failed OCR

            markdown_parts.append("\n\n".join(section))

        # Extract links from the PDF
        extracted_links = extract_pdf_links(doc, all_text_content)
        processed_links = link_extractor.process_links(extracted_links, file.filename or "document.pdf")

        doc.close()
        
        final_markdown = "\n\n".join(markdown_parts) if markdown_parts else "*No content found in PDF.*"
        
        return {
            "markdown": final_markdown,
            "tokens_used": total_tokens_used,
            "links": processed_links
        }
        
    except Exception as e:
        logger.error(f"PDF extraction failed: {e}")
        return {
            "markdown": f"<!-- PDF extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_pdf(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking or links)
    """
    try:
        result = await extract_pdf_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        logger.error(f"PDF extraction failed: {e}")
        return f"<!-- PDF extraction failed: {str(e)} -->"