# app/utils/extractors/other_extractor.py

from fastapi import UploadFile
from typing import Dict, Any

async def extract_other_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Fallback extractor for unsupported file types with token tracking and link support
    
    Note: This extractor doesn't process content, just returns file info,
    so this will always return 0 tokens and no links.
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        file_size = len(contents)
        
        markdown = f"*No supported extractor found for {file.filename}.*\n\n*File size:* {file_size:,} bytes"
        
        return {
            "markdown": markdown,
            "tokens_used": 0,  # No processing done, no tokens used
            "links": []  # No link extraction for unsupported files
        }
        
    except Exception as e:
        return {
            "markdown": f"<!-- Failed to read file {file.filename}: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_other(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking)
    """
    try:
        result = await extract_other_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        return f"<!-- Failed to read file {file.filename}: {str(e)} -->"