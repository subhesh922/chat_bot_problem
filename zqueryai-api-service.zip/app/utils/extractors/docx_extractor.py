# app/utils/extractors/docx_extractor.py

from fastapi import UploadFile
from typing import Dict, Any, List
import docx
import os
import re
from .ocr_utils import run_ocr_on_image_bytes
from .link_extractor import link_extractor
import logging

logger = logging.getLogger(__name__)

def extract_docx_links(doc) -> List[Dict[str, Any]]:
    """
    Extract hyperlinks from DOCX document using same approach as PDF extractor
    """
    links = []
    
    try:
        # Get full document text for context
        full_text = '\n'.join([para.text for para in doc.paragraphs])
        
        # Method 1: Extract hyperlinks from document relationships (similar to PDF link annotations)
        rels = doc.part.rels
        hyperlink_rels = {rel.rId: rel.target_ref for rel in rels.values() 
                         if rel.reltype.endswith('/hyperlink')}
        
        # Method 2: Find hyperlink elements in document (similar to PDF link extraction)
        document_element = doc.element
        for elem in document_element.iter():
            if elem.tag.endswith('}hyperlink'):
                try:
                    # Get relationship ID
                    r_id = None
                    for attr_name, attr_value in elem.attrib.items():
                        if attr_name.endswith('}id'):
                            r_id = attr_value
                            break
                    
                    # Get anchor text
                    anchor_text = ""
                    for text_elem in elem.iter():
                        if text_elem.tag.endswith('}t') and text_elem.text:
                            anchor_text += text_elem.text
                    
                    # Get URL from relationships
                    url = None
                    if r_id and r_id in hyperlink_rels:
                        url = hyperlink_rels[r_id]
                    
                    if url and anchor_text:
                        # Get context around the anchor text (same as PDF)
                        context = ""
                        if anchor_text in full_text:
                            anchor_pos = full_text.find(anchor_text)
                            context_start = max(0, anchor_pos - 50)
                            context_end = min(len(full_text), anchor_pos + len(anchor_text) + 50)
                            context = full_text[context_start:context_end].strip()
                        
                        links.append({
                            'url': url,
                            'anchor_text': anchor_text.strip(),
                            'link_type': 'hyperlink',
                            'context': context
                        })
                        
                except Exception as e:
                    logger.debug(f"Could not extract hyperlink: {e}")
                    continue
        
        # Method 3: Look for explicit URLs in text content (EXACT same as PDF)
        url_matches = re.finditer(r'https?://[^\s<>"{}|\\^`\[\]]+', full_text, re.IGNORECASE)
        
        # Create a set of already found URLs (normalized) to avoid duplicates
        existing_urls = set()
        for link in links:
            # Normalize URLs by removing trailing slashes for comparison
            normalized_url = link['url'].rstrip('/')
            existing_urls.add(normalized_url)
        
        for match in url_matches:
            url = match.group()
            start_pos = match.start()
            
            # Normalize URL for comparison
            normalized_url = url.rstrip('/')
            
            # Only add if we haven't already captured this URL as a hyperlink
            if normalized_url not in existing_urls:
                # Extract context around the URL (same as PDF)
                context_start = max(0, start_pos - 50)
                context_end = min(len(full_text), match.end() + 50)
                context = full_text[context_start:context_end].strip()
                
                links.append({
                    'url': url,
                    'anchor_text': url,  # For explicit URLs, anchor text is the URL itself
                    'link_type': 'explicit',
                    'context': context
                })
                
                # Add to existing URLs set
                existing_urls.add(normalized_url)
    
    except Exception as e:
        logger.error(f"Error extracting links from DOCX: {e}")
    
    return links

async def extract_docx_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract content from DOCX file with token tracking for OCR operations and link detection
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    temp_path = "/tmp/temp_doc.docx"
    
    try:
        contents = await file.read()
        
        # Write to temporary file
        with open(temp_path, "wb") as f:
            f.write(contents)

        doc = docx.Document(temp_path)
        result_parts = []
        total_tokens_used = 0

        # Extract paragraph text
        paragraph_text = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        if paragraph_text:
            result_parts.append("**Document Text**\n\n" + "\n\n".join(paragraph_text))

        # Extract tables
        for table_idx, table in enumerate(doc.tables):
            rows = [[cell.text.strip().replace("\n", " ") for cell in row.cells] for row in table.rows]
            if rows:
                max_cols = max(len(r) for r in rows)
                for row in rows:
                    while len(row) < max_cols:
                        row.append("")
                
                header = rows[0] if any(rows[0]) else [f"Col{i+1}" for i in range(max_cols)]
                lines = [
                    f"\n**[Table {table_idx + 1}]**",
                    "| " + " | ".join(header) + " |",
                    "| " + " | ".join(["---"] * max_cols) + " |"
                ]
                for row in rows[1:]:
                    lines.append("| " + " | ".join(row) + " |")
                result_parts.append("\n".join(lines))

        # Extract headers and footers
        for section in doc.sections:
            headers = [p.text.strip() for p in section.header.paragraphs if p.text.strip()]
            footers = [p.text.strip() for p in section.footer.paragraphs if p.text.strip()]
            if headers:
                result_parts.append("**Headers**\n" + "\n".join(headers))
            if footers:
                result_parts.append("**Footers**\n" + "\n".join(footers))

        # Extract and process images with OCR token tracking
        image_count = 0
        for rel in doc.part.rels.values():
            if "image" in rel.reltype:
                image_count += 1
                try:
                    image_bytes = rel.target_part.blob
                    ocr_result = await run_ocr_on_image_bytes(image_bytes)
                    
                    # Track tokens from OCR operation
                    ocr_text = ocr_result.get("text", "")
                    ocr_tokens = ocr_result.get("tokens_used", 0)
                    total_tokens_used += ocr_tokens
                    
                    if ocr_text and ocr_text.strip():
                        result_parts.append(f"**[Image {image_count}: OCR Text]**\n{ocr_text}")
                    else:
                        result_parts.append(f"*Image {image_count}: No text detected*")
                        
                except Exception as e:
                    result_parts.append(f"*Failed OCR on image {image_count}: {str(e)}*")
                    # No tokens added for failed OCR

        # Extract hyperlinks from the document
        extracted_links = extract_docx_links(doc)
        processed_links = link_extractor.process_links(extracted_links, file.filename or "document.docx")

        # Clean up temporary file
        try:
            os.remove(temp_path)
        except:
            pass  # Ignore cleanup errors

        final_markdown = "\n\n".join(result_parts) if result_parts else "*No extractable text or image content found.*"
        
        return {
            "markdown": final_markdown,
            "tokens_used": total_tokens_used,
            "links": processed_links
        }
        
    except Exception as e:
        # Clean up temporary file on error
        try:
            os.remove(temp_path)
        except:
            pass
            
        logger.error(f"DOCX extraction failed: {e}")
        return {
            "markdown": f"<!-- DOCX extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_docx(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking or links)
    """
    try:
        result = await extract_docx_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        logger.error(f"DOCX extraction failed: {e}")
        return f"<!-- DOCX extraction failed: {str(e)} -->"