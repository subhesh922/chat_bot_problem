# app/utils/extractors/txt_extractor.py

from fastapi import UploadFile
from typing import Dict, Any

async def extract_txt_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract content from TXT file with token tracking and link support
    
    Note: TXT files are plain text and don't require OCR,
    so this will always return 0 tokens. Links are not extracted from plain text.
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        text = contents.decode("utf-8", errors="ignore").strip()
        
        return {
            "markdown": text if text else "*Empty text file.*",
            "tokens_used": 0,  # Text files don't use OCR
            "links": []  # No link extraction for plain text
        }
        
    except Exception as e:
        return {
            "markdown": f"<!-- TXT extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_txt(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking)
    """
    try:
        contents = await file.read()
        text = contents.decode("utf-8", errors="ignore").strip()
        return text if text else "*Empty text file.*"
    except Exception as e:
        return f"<!-- TXT extraction failed: {str(e)} -->"