# app/utils/extractors/link_extractor.py

import re
from typing import List, Dict, Any, Set
from urllib.parse import urlparse, urljoin
import logging

logger = logging.getLogger(__name__)

class LinkExtractor:
    """Utility class for extracting and processing hyperlinks from various document types"""
    
    def __init__(self):
        # Patterns for different types of links
        self.url_patterns = {
            # Standard HTTP/HTTPS URLs
            'http_url': re.compile(r'https?://[^\s<>"{}|\\^`\[\]]+', re.IGNORECASE),
            
            # Common internal link patterns (can be customized)
            'jira_ticket': re.compile(r'\b[A-Z]+-\d+\b'),  # e.g., PROJ-123, DQRS-1234
            'confluence_page': re.compile(r'\b(?:page|wiki|confluence)\s*[:#]\s*([^\s]+)', re.IGNORECASE),
        }
        
        # File extensions to exclude (binary files, media, documents)
        self.blocked_extensions = {
            # Documents (we already extract these, no need to crawl linked versions)
            '.pdf', '.doc', '.docx', '.ppt', '.pptx', '.xls', '.xlsx',
            # Archives and executables
            '.zip', '.rar', '.7z', '.tar', '.gz', '.exe', '.msi', '.dmg', '.pkg',
            # Media files
            '.jpg', '.jpeg', '.png', '.gif', '.svg', '.bmp', '.webp',
            '.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv', '.webm',
            '.mp3', '.wav', '.flac', '.ogg', '.m4a', '.wma',
            # Other binary formats
            '.iso', '.bin', '.apk', '.deb', '.rpm'
        }
        
        # Domain patterns to exclude (cloud storage, media platforms, etc.)
        self.blocked_domain_patterns = {
            # Cloud storage
            'sharepoint.com', 'onedrive.com', 'drive.google.com', 'dropbox.com',
            'box.com', 'icloud.com', 's3.amazonaws.com', 'blob.core.windows.net',
            # Media platforms
            'youtube.com', 'youtu.be', 'vimeo.com', 'twitch.tv', 'spotify.com',
            'soundcloud.com', 'instagram.com', 'tiktok.com',
            # Social media (usually not useful for KB)
            'facebook.com', 'twitter.com', 'x.com', 'linkedin.com/posts',
            # Github repo links (not issues/discussions which might be useful)
            # We'll handle github specially in blocked_path_patterns
        }
        
        # URL path patterns to exclude
        self.blocked_path_patterns = {
            # Download indicators
            '/download/', '/downloads/', '/attachments/', '/files/',
            # Github repo browsing (but allow issues/discussions)
            'github.com/.*/(tree|blob|commit|releases|archive)',
            # Common binary endpoints
            '/api/download', '/export/', '/backup/',
            # Media endpoints
            '/video/', '/audio/', '/images/', '/media/',
        }
        
        # Allowed domain patterns (these bypass other filters for known good domains)
        self.allowed_domain_patterns = {
            # Documentation sites
            'docs.', 'help.', 'support.', 'kb.', 'wiki.',
            # Confluence and JIRA
            'confluence.com', 'atlassian.net',
            # Developer docs
            'stackoverflow.com', 'github.com/.*/(issues|discussions|wiki)',
            # Common knowledge bases
            'notion.so', 'gitbook.io', 'readthedocs.io',
        }
    
    def has_blocked_extension(self, url: str) -> bool:
        """Check if URL has a blocked file extension"""
        try:
            parsed = urlparse(url)
            path = parsed.path.lower()
            
            # Check for direct extension match
            for ext in self.blocked_extensions:
                if path.endswith(ext):
                    return True
            
            # Check for extension with query parameters (e.g., file.pdf?version=1)
            if '.' in path:
                potential_ext = '.' + path.split('.')[-1].split('?')[0].split('#')[0]
                if potential_ext in self.blocked_extensions:
                    return True
                    
            return False
        except Exception:
            return False
    
    def is_blocked_domain(self, url: str) -> bool:
        """Check if URL is from a blocked domain"""
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            
            # Check exact domain matches and subdomains
            for blocked_pattern in self.blocked_domain_patterns:
                if domain == blocked_pattern or domain.endswith('.' + blocked_pattern):
                    return True
                    
            return False
        except Exception:
            return False
    
    def matches_blocked_path_pattern(self, url: str) -> bool:
        """Check if URL matches blocked path patterns"""
        try:
            for pattern in self.blocked_path_patterns:
                if re.search(pattern, url, re.IGNORECASE):
                    return True
            return False
        except Exception:
            return False
    
    def is_allowed_domain(self, url: str) -> bool:
        """Check if URL is from an explicitly allowed domain (bypasses other filters)"""
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            full_url = url.lower()
            
            for allowed_pattern in self.allowed_domain_patterns:
                # Handle regex patterns for github
                if 'github.com' in allowed_pattern and 'github.com' in domain:
                    if re.search(allowed_pattern, full_url):
                        return True
                # Handle subdomain patterns (docs., help., etc.)
                elif allowed_pattern.startswith('.') or allowed_pattern.endswith('.'):
                    if allowed_pattern.endswith('.'):
                        # Pattern like "docs." - check if domain starts with this
                        if domain.startswith(allowed_pattern) or f".{allowed_pattern}" in domain:
                            return True
                    else:
                        # Pattern like ".com" - check if domain ends with this
                        if domain.endswith(allowed_pattern):
                            return True
                # Handle exact domain matches
                elif domain == allowed_pattern or domain.endswith('.' + allowed_pattern):
                    return True
                    
            return False
        except Exception:
            return False
    
    def has_download_indicators(self, url: str) -> bool:
        """Check for download-related indicators in URL"""
        download_indicators = [
            'download', 'attachment', 'export', 'backup',
            'file_download', 'get_file', 'raw_file'
        ]
        
        url_lower = url.lower()
        return any(indicator in url_lower for indicator in download_indicators)
    
    def is_jql_query_link(self, url: str) -> bool:
        """
        Detect JQL (Jira Query Language) links that return multiple issues
        vs. direct issue links that point to specific tickets
        """
        try:
            parsed = urlparse(url)
            path = parsed.path.lower()
            query = parsed.query.lower()
            
            # Check if it's a JIRA domain first
            if not ('atlassian.net' in parsed.netloc or 'jira' in parsed.netloc):
                return False
            
            # JQL indicators in the URL
            jql_indicators = [
                'jql=',           # Direct JQL parameter
                '/issues/?',      # Issues search endpoint
                '/issues?',       # Issues search endpoint (no trailing slash)
                'filter=',        # Saved filter
                'search?',        # General search
                'query=',         # Query parameter
            ]
            
            # Check for JQL in query parameters
            if any(indicator in query for indicator in jql_indicators):
                return True
            
            # Check for JQL in path
            if any(indicator.rstrip('=?') in path for indicator in jql_indicators):
                return True
            
            # Specific pattern: /issues/ path without a specific issue ID
            if '/issues/' in path and not re.search(r'/browse/[A-Z]+-\d+', url):
                return True
                
            return False
            
        except Exception as e:
            logger.debug(f"Error checking JQL pattern for {url}: {e}")
            return False
    
    def is_specific_jira_issue(self, url: str) -> bool:
        """
        Check if URL points to a specific JIRA issue (should be allowed)
        """
        try:
            # Pattern for specific JIRA issues: /browse/PROJECT-123
            jira_issue_pattern = r'/browse/[A-Z]+-\d+'
            return bool(re.search(jira_issue_pattern, url))
        except Exception:
            return False
    
    def is_relevant_for_extraction(self, url: str) -> bool:
        """
        Main filtering method - determines if a link should be shown to users
        
        Returns True if the link is relevant for KB query assistance
        """
        try:
            # First check if it's from an explicitly allowed domain
            if self.is_allowed_domain(url):
                # Even for allowed domains, filter out JQL queries but keep specific issues
                if self.is_jql_query_link(url) and not self.is_specific_jira_issue(url):
                    logger.debug(f"Filtered out JQL query link: {url}")
                    return False
                return True
            
            # Check basic crawlability (HTTP/HTTPS only)
            if not self.is_crawlable_url(url):
                return False
            
            # For JIRA links specifically: allow specific issues, block JQL queries
            if 'atlassian.net' in url or 'jira' in url.lower():
                if self.is_specific_jira_issue(url):
                    return True
                elif self.is_jql_query_link(url):
                    logger.debug(f"Filtered out JQL query link: {url}")
                    return False
            
            # Filter out file extensions
            if self.has_blocked_extension(url):
                logger.debug(f"Filtered out URL with blocked extension: {url}")
                return False
            
            # Filter out blocked domains
            if self.is_blocked_domain(url):
                logger.debug(f"Filtered out URL from blocked domain: {url}")
                return False
            
            # Filter out blocked path patterns
            if self.matches_blocked_path_pattern(url):
                logger.debug(f"Filtered out URL with blocked path pattern: {url}")
                return False
            
            # Filter out download indicators
            if self.has_download_indicators(url):
                logger.debug(f"Filtered out URL with download indicators: {url}")
                return False
            
            return True
            
        except Exception as e:
            logger.warning(f"Error filtering URL {url}: {e}")
            return False  # When in doubt, filter it out
    
    def is_crawlable_url(self, url: str) -> bool:
        """
        Determine if a URL is crawlable (HTTP/HTTPS only for now)
        """
        try:
            parsed = urlparse(url)
            return parsed.scheme.lower() in ['http', 'https']
        except Exception:
            return False
    
    def extract_context(self, text: str, url: str, context_length: int = 100) -> str:
        """
        Extract surrounding context for a URL within text
        """
        try:
            url_pos = text.find(url)
            if url_pos == -1:
                return ""
            
            start = max(0, url_pos - context_length // 2)
            end = min(len(text), url_pos + len(url) + context_length // 2)
            
            context = text[start:end].strip()
            return context
        except Exception:
            return ""
    
    def process_links(self, links: List[Dict[str, Any]], source_filename: str) -> List[Dict[str, Any]]:
        """
        Process and clean extracted links with smart filtering
        """
        processed_links = []
        seen_urls = set()
        filtered_count = 0
        
        for link in links:
            url = link.get('url', '').strip()
            if not url or url in seen_urls:
                continue
            
            # Apply smart filtering - this is the key change!
            if not self.is_relevant_for_extraction(url):
                filtered_count += 1
                continue
            
            # Clean and process the link
            processed_link = {
                'url': url,
                'anchor_text': link.get('anchor_text', '').strip(),
                'link_type': link.get('link_type', 'hyperlink'),
                'context': link.get('context', '').strip()
            }
            
            processed_links.append(processed_link)
            seen_urls.add(url)
        
        if filtered_count > 0:
            logger.info(f"Filtered out {filtered_count} irrelevant links from {source_filename}")
        
        return processed_links
    
    def create_links_summary(self, documents_with_links: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Create a summary of all links found across documents
        """
        total_links = 0
        has_crawlable_links = False
        links_by_document = {}
        
        for doc in documents_with_links:
            source = doc.get('metadata', {}).get('source', 'unknown')
            links = doc.get('links', [])
            
            if links:
                links_by_document[source] = links
                total_links += len(links)
                
                # All links that make it through processing are crawlable by definition
                has_crawlable_links = True
        
        return {
            'total_links': total_links,
            'has_crawlable_links': has_crawlable_links,
            'links_by_document': links_by_document
        }
    
    def get_filtering_stats(self) -> Dict[str, Any]:
        """
        Get information about what types of links are being filtered
        (Useful for debugging and monitoring)
        """
        return {
            'blocked_extensions': list(self.blocked_extensions),
            'blocked_domains': list(self.blocked_domain_patterns),
            'blocked_path_patterns': list(self.blocked_path_patterns),
            'allowed_domains': list(self.allowed_domain_patterns),
            'total_filters': len(self.blocked_extensions) + len(self.blocked_domain_patterns) + len(self.blocked_path_patterns)
        }

# Global instance for use across extractors
link_extractor = LinkExtractor()

# Example usage in PDF extractor (showing how filtering is now automatic):
"""
def extract_pdf_links(doc: fitz.Document, text_content: str) -> List[Dict[str, Any]]:
    # ... existing extraction logic remains the same ...
    # Just extract ALL links, filtering happens in process_links()
    
    # At the end:
    return links  # Raw links, no filtering here

async def extract_pdf_with_tokens(file: UploadFile) -> Dict[str, Any]:
    # ... existing logic ...
    
    # Extract links from the PDF (gets ALL links)
    extracted_links = extract_pdf_links(doc, all_text_content)
    
    # Filtering happens automatically in process_links()
    processed_links = link_extractor.process_links(extracted_links, file.filename or "document.pdf")
    
    # processed_links now only contains relevant links!
"""