# app/utils/extractors/pptx_extractor.py

from fastapi import UploadFile
from typing import Dict, Any, List
from pptx import Presentation
from .ocr_utils import run_ocr_on_image_bytes
from .link_extractor import link_extractor
import os
import re
import logging

logger = logging.getLogger(__name__)

def extract_pptx_links(prs: Presentation) -> List[Dict[str, Any]]:
    """
    Extract hyperlinks from PPTX presentation with deduplication
    """
    links = []
    
    try:
        for slide_num, slide in enumerate(prs.slides, 1):
            slide_text = ""
            
            # Collect all text from the slide for context
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    slide_text += f" {shape.text}"
            
            # Extract hyperlinks from slide shapes
            for shape in slide.shapes:
                try:
                    # Check if shape has hyperlink
                    if hasattr(shape, 'click_action') and shape.click_action.hyperlink:
                        hyperlink = shape.click_action.hyperlink
                        if hyperlink.address:
                            anchor_text = getattr(shape, 'text', '') or ""
                            
                            links.append({
                                'url': hyperlink.address,
                                'anchor_text': anchor_text,
                                'link_type': 'hyperlink',
                                'context': slide_text.strip(),
                                'slide': slide_num
                            })
                    
                    # Also check text runs within shapes for hyperlinks
                    if hasattr(shape, 'text_frame'):
                        for paragraph in shape.text_frame.paragraphs:
                            for run in paragraph.runs:
                                if run.hyperlink and run.hyperlink.address:
                                    links.append({
                                        'url': run.hyperlink.address,
                                        'anchor_text': run.text,
                                        'link_type': 'hyperlink',
                                        'context': slide_text.strip(),
                                        'slide': slide_num
                                    })
                
                except Exception as e:
                    logger.debug(f"Could not extract hyperlinks from shape: {e}")
                    continue
            
            # Extract explicit URLs from slide text with deduplication
            url_matches = re.finditer(r'https?://[^\s<>"{}|\\^`\[\]]+', slide_text, re.IGNORECASE)
            
            # Create a set of already found URLs (normalized) to avoid duplicates
            existing_urls = set()
            for link in links:
                if link.get('slide') == slide_num:  # Only check URLs from current slide
                    # Normalize URLs by removing trailing slashes for comparison
                    normalized_url = link['url'].rstrip('/')
                    existing_urls.add(normalized_url)
            
            for match in url_matches:
                url = match.group()
                start_pos = match.start()
                
                # Normalize URL for comparison
                normalized_url = url.rstrip('/')
                
                # Only add if we haven't already captured this URL as a hyperlink
                if normalized_url not in existing_urls:
                    # Extract context around the URL
                    context_start = max(0, start_pos - 50)
                    context_end = min(len(slide_text), match.end() + 50)
                    context = slide_text[context_start:context_end].strip()
                    
                    links.append({
                        'url': url,
                        'anchor_text': url,
                        'link_type': 'explicit',
                        'context': context,
                        'slide': slide_num
                    })
                    
                    # Add to existing URLs set
                    existing_urls.add(normalized_url)
    
    except Exception as e:
        logger.error(f"Error extracting links from PPTX: {e}")
    
    return links

async def extract_pptx_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract content from PPTX with token tracking for OCR operations and link detection
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    temp_path = "/tmp/temp_pptx.pptx"
    
    try:
        contents = await file.read()
        with open(temp_path, "wb") as f:
            f.write(contents)

        prs = Presentation(temp_path)
        slides = []
        total_tokens_used = 0

        for i, slide in enumerate(prs.slides, start=1):
            section = [f"### Slide {i}"]

            has_text = False
            has_images = False
            ocr_texts = []

            # 1. Extract native text (no tokens used)
            texts = [shape.text.strip() for shape in slide.shapes if hasattr(shape, "text") and shape.text.strip()]
            if texts:
                has_text = True
                section.append("\n".join(texts))

            # 2. Process image shapes with OCR
            for shape in slide.shapes:
                if shape.shape_type == 13 or getattr(shape, "has_picture", False):
                    try:
                        image_bytes = shape.image.blob
                        ocr_result = await run_ocr_on_image_bytes(image_bytes)
                        
                        ocr_text = ocr_result.get("text", "")
                        ocr_tokens = ocr_result.get("tokens_used", 0)
                        
                        # Add tokens to total
                        total_tokens_used += ocr_tokens
                        
                        if ocr_text and ocr_text.strip():
                            has_images = True
                            ocr_texts.append(f"**[OCR Image]**\n{ocr_text}")
                            
                    except Exception:
                        continue

            if ocr_texts:
                section.append("\n\n".join(ocr_texts))

            # 3. Fallback: If no text or OCR images found, look for background-style images
            if not has_text and not has_images:
                largest_image_bytes = None
                largest_image_size = 0
                
                for shape in slide.shapes:
                    if hasattr(shape, "image") and shape.shape_type == 13:
                        try:
                            image_bytes = shape.image.blob
                            if len(image_bytes) > largest_image_size:
                                largest_image_bytes = image_bytes
                                largest_image_size = len(image_bytes)
                        except Exception:
                            continue

                if largest_image_bytes:
                    try:
                        fallback_ocr = await run_ocr_on_image_bytes(largest_image_bytes)
                        fallback_text = fallback_ocr.get("text", "")
                        fallback_tokens = fallback_ocr.get("tokens_used", 0)
                        
                        # Add fallback tokens to total
                        total_tokens_used += fallback_tokens
                        
                        if fallback_text and fallback_text.strip():
                            section.append(f"**[OCR Fallback: Full Slide Image]**\n{fallback_text}")
                        else:
                            section.append("*No extractable content found on this slide.*")
                            
                    except Exception as e:
                        section.append(f"*Failed OCR fallback: {str(e)}*")
                else:
                    section.append("*No extractable content found on this slide.*")

            slides.append("\n\n".join(section))

        # Extract hyperlinks from the presentation
        extracted_links = extract_pptx_links(prs)
        processed_links = link_extractor.process_links(extracted_links, file.filename or "presentation.pptx")

        # Clean up temporary file
        try:
            os.remove(temp_path)
        except:
            pass

        final_markdown = "\n\n".join(slides) if slides else "*No content found in PPTX.*"
        
        return {
            "markdown": final_markdown,
            "tokens_used": total_tokens_used,
            "links": processed_links
        }
        
    except Exception as e:
        # Clean up temporary file on error
        try:
            os.remove(temp_path)
        except:
            pass
            
        logger.error(f"PPTX extraction failed: {e}")
        return {
            "markdown": f"<!-- PPTX extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_pptx(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking or links)
    """
    try:
        result = await extract_pptx_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        logger.error(f"PPTX extraction failed: {e}")
        return f"<!-- PPTX extraction failed: {str(e)} -->"