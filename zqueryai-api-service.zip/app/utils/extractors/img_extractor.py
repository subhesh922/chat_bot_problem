# app/utils/extractors/img_extractor.py

from fastapi import UploadFile
from typing import Dict, Any
from .ocr_utils import run_ocr_on_image_bytes

async def extract_image_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract text from image using OCR with token tracking and link support
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        ocr_result = await run_ocr_on_image_bytes(contents)
        
        ocr_text = ocr_result.get("text", "")
        tokens_used = ocr_result.get("tokens_used", 0)
        
        if ocr_text and ocr_text.strip():
            markdown = f"### {file.filename}\n\n{ocr_text}"
        else:
            markdown = f"*No text found in {file.filename}*"
        
        return {
            "markdown": markdown,
            "tokens_used": tokens_used,
            "links": []  # No link extraction from images currently
        }
        
    except Exception as e:
        return {
            "markdown": f"*Failed to extract text from {file.filename}: {str(e)}*",
            "tokens_used": 0,
            "links": []
        }

async def extract_image(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking)
    """
    try:
        result = await extract_image_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        return f"*Failed to extract text from {file.filename}: {str(e)}*"