# app/utils/extractors/ocr_utils.py

import base64
import httpx
import hashlib
import imghdr
from typing import Dict, Any

from app.config import (
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_MODEL,
    AZURE_OPENAI_API_VERSION
)

# 🔁 In-memory cache: { image_hash: { text: ..., tokens_used: ... } }
ocr_cache: dict[str, dict] = {}

# 🔒 Compute SHA256 hash to uniquely identify image bytes
def hash_image_bytes(image_bytes: bytes) -> str:
    return hashlib.sha256(image_bytes).hexdigest()

# 📦 Detect actual image MIME type from bytes
def get_mime_type(image_bytes: bytes) -> str:
    img_type = imghdr.what(None, h=image_bytes)
    return f"image/{img_type}" if img_type else "image/png"  # fallback

# 🤖 Main OCR function using Azure Vision (GPT-4o vision)
async def run_ocr_on_image_bytes(image_bytes: bytes) -> Dict[str, Any]:
    """
    Run OCR on image bytes using Azure Vision API
    Returns: {"text": str, "tokens_used": int}
    """
    image_hash = hash_image_bytes(image_bytes)

    # ✅ Use cache if image already processed
    if image_hash in ocr_cache:
        return ocr_cache[image_hash]

    # 🧠 Encode and prepare vision payload
    base64_image = base64.b64encode(image_bytes).decode("utf-8")
    mime_type = get_mime_type(image_bytes)

    payload = {
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Extract all visible text from this image. If it contains a table, preserve it in Markdown format. Be precise and thorough."
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{mime_type};base64,{base64_image}"
                        }
                    }
                ]
            }
        ],
        "temperature": 0.1,
        "max_tokens": 1000
    }

    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_OPENAI_KEY
    }

    url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{AZURE_OPENAI_MODEL}/chat/completions?api-version={AZURE_OPENAI_API_VERSION}"

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            response = await client.post(url, json=payload, headers=headers)
            response.raise_for_status()

            result = response.json()
            ocr_text = result["choices"][0]["message"]["content"].strip()
            usage = result.get("usage", {})

            # 👇 Return in expected format
            parsed = {
                "text": ocr_text,
                "tokens_used": usage.get("total_tokens", 0)
            }

            # ✅ Cache result
            ocr_cache[image_hash] = parsed
            return parsed
            
    except Exception as e:
        # Return empty result with 0 tokens on error
        error_result = {
            "text": "",
            "tokens_used": 0
        }
        ocr_cache[image_hash] = error_result
        return error_result

# 🆕 Helper function for extractors to process multiple images
async def process_images_with_ocr(image_bytes_list: list[bytes]) -> Dict[str, Any]:
    """
    Process multiple images and return aggregated OCR results
    Returns: {"texts": List[str], "total_tokens_used": int}
    """
    if not image_bytes_list:
        return {"texts": [], "total_tokens_used": 0}
    
    texts = []
    total_tokens = 0
    
    for image_bytes in image_bytes_list:
        try:
            ocr_result = await run_ocr_on_image_bytes(image_bytes)
            texts.append(ocr_result["text"])
            total_tokens += ocr_result["tokens_used"]
        except Exception:
            texts.append("")  # Add empty text on error
            # tokens remain 0 for failed OCR
    
    return {
        "texts": texts,
        "total_tokens_used": total_tokens
    }