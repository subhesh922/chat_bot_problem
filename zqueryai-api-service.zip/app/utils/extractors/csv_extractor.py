# app/utils/extractors/csv_extractor.py

from fastapi import UploadFile
from typing import Dict, Any
import pandas as pd
from io import StringIO

def find_column_regions(row, max_gap=1):
    """Finds contiguous non-empty column regions split by empty columns"""
    regions = []
    start = None
    gap_count = 0

    for i, val in enumerate(row):
        if pd.notna(val) and str(val).strip() != '':
            if start is None:
                start = i
            gap_count = 0
        else:
            if start is not None:
                gap_count += 1
                if gap_count > max_gap:
                    regions.append((start, i - gap_count))
                    start = None
                    gap_count = 0
    if start is not None:
        regions.append((start, len(row) - 1))
    return regions

def process_row_group(row_group):
    """Processes a row group and extracts multiple horizontally split tables"""
    if not row_group:
        return []

    df = pd.DataFrame(row_group)
    tables = []

    regions = find_column_regions(df.iloc[0].tolist())
    for idx, (start_col, end_col) in enumerate(regions):
        sub_df = df.iloc[:, start_col:end_col+1].copy()
        sub_df.dropna(how='all', inplace=True)
        sub_df.dropna(axis=1, how='all', inplace=True)

        if sub_df.shape[0] >= 2:
            sub_df.columns = sub_df.iloc[0]
            sub_df = sub_df[1:]
            tables.append((f"Table {len(tables)+1}", sub_df.reset_index(drop=True)))

    return tables

def extract_tables_from_csv(df):
    """Splits vertical blocks and extracts multiple tables"""
    tables = []
    current_rows = []

    for _, row in df.iterrows():
        if row.isna().all():
            if current_rows:
                tables.extend(process_row_group(current_rows))
                current_rows = []
        else:
            current_rows.append(row.tolist())

    if current_rows:
        tables.extend(process_row_group(current_rows))

    return tables

async def extract_csv_with_tokens(file: UploadFile) -> Dict[str, Any]:
    """
    Extract content from CSV file with token tracking and link support
    
    Note: CSV files are text-only and don't require OCR,
    so this will always return 0 tokens. Links are not extracted from CSV.
    
    Returns:
        {
            "markdown": str,
            "tokens_used": int,
            "links": List[Dict[str, Any]]
        }
    """
    try:
        contents = await file.read()
        text = contents.decode("utf-8", errors="ignore")

        # Try parsing with pandas
        try:
            df = pd.read_csv(StringIO(text), header=None)
        except Exception as e:
            return {
                "markdown": f"❌ Failed to parse CSV: {str(e)}",
                "tokens_used": 0,
                "links": []
            }

        markdown_output = []

        tables = extract_tables_from_csv(df)
        if not tables:
            return {
                "markdown": "_No tables detected._",
                "tokens_used": 0,
                "links": []
            }

        for table_name, sub_df in tables:
            markdown_output.append(f"#### {table_name}\n\n")
            try:
                markdown_output.append(sub_df.to_markdown(index=False))
            except Exception as e:
                # Fallback if to_markdown fails
                markdown_output.append(f"_Table conversion failed: {str(e)}_")
            markdown_output.append("\n\n---\n")

        final_markdown = "\n".join(markdown_output)
        
        return {
            "markdown": final_markdown,
            "tokens_used": 0,  # CSV files don't use OCR
            "links": []  # No link extraction for CSV
        }
        
    except Exception as e:
        return {
            "markdown": f"<!-- CSV extraction failed: {str(e)} -->",
            "tokens_used": 0,
            "links": []
        }

async def extract_csv(file: UploadFile) -> str:
    """
    Legacy function for backward compatibility
    Returns only the markdown content (no token tracking)
    """
    try:
        result = await extract_csv_with_tokens(file)
        return result["markdown"]
    except Exception as e:
        return f"<!-- CSV extraction failed: {str(e)} -->"