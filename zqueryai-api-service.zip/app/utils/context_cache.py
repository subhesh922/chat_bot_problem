# app/utils/context_cache.py

import hashlib
import time
import re
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import json

@dataclass
class CachedContext:
    """Represents cached context data"""
    context_chunks: List[Dict[str, Any]]
    query_embedding_tokens: int
    filters_used: Dict[str, Any]
    timestamp: float
    original_query: str
    cache_key: str

class ContextCacheManager:
    """Manages context caching for conversations"""
    
    def __init__(self, cache_ttl: int = 1800):  # 30 minutes default TTL
        self.cache: Dict[str, CachedContext] = {}
        self.cache_ttl = cache_ttl
    
    def generate_cache_key(self, query: str, collection: str, filters: Dict[str, Any] = None) -> str:
        """Generate a unique cache key based on semantic content"""
        # Normalize query for better caching
        normalized_query = self._normalize_query_for_caching(query)
        
        # Create hash from normalized query + collection + filters
        cache_input = f"{normalized_query}|{collection}|{json.dumps(filters or {}, sort_keys=True)}"
        return hashlib.md5(cache_input.encode()).hexdigest()
    
    def _normalize_query_for_caching(self, query: str) -> str:
        """Normalize query to detect semantically similar questions"""
        # Convert to lowercase
        query = query.lower().strip()
        
        # Remove common question words that don't affect semantics
        replacements = [
            (r'\bcan you\b', ''),
            (r'\bplease\b', ''),
            (r'\bcould you\b', ''),
            (r'\bi need to know\b', ''),
            (r'\btell me about\b', ''),
            (r'\bwhat about\b', ''),
            (r'\bhow about\b', ''),
            (r'\bshow me\b', ''),
            (r'\bgive me\b', ''),
        ]
        
        for pattern, replacement in replacements:
            query = re.sub(pattern, replacement, query)
        
        # Remove extra whitespace
        query = re.sub(r'\s+', ' ', query).strip()
        
        return query
    
    def should_use_cache(self, query: str, collection: str, filters: Dict[str, Any] = None, 
                        conversation_history: List[Dict[str, str]] = None) -> Tuple[bool, Optional[str]]:
        """Determine if we should use cached context or fetch fresh"""
        
        # Check if this is a follow-up question
        if self._is_followup_question(query, conversation_history):
            # For follow-ups, try to find recent cache
            recent_cache_key = self._find_recent_cache_key(collection, filters)
            if recent_cache_key and recent_cache_key in self.cache:
                return True, recent_cache_key
        
        # Check for exact semantic match
        cache_key = self.generate_cache_key(query, collection, filters)
        if cache_key in self.cache and not self._is_cache_expired(cache_key):
            return True, cache_key
        
        # Check for similar cached queries
        similar_key = self._find_similar_cached_query(query, collection, filters)
        if similar_key:
            return True, similar_key
        
        return False, None
    
    def _is_followup_question(self, query: str, history: List[Dict[str, str]] = None) -> bool:
        """Detect if this is a follow-up question to previous context"""
        if not history or len(history) < 2:
            return False
        
        query_lower = query.lower()
        
        # Follow-up indicators
        followup_patterns = [
            r'\bwhat about\b', r'\bhow about\b', r'\band what\b', r'\balso\b',
            r'\bthen\b', r'\bnext\b', r'\bother\b', r'\belse\b', r'\bmore\b',
            r'\badditional\b', r'\bfurther\b', r'\banother\b', r'\bsame\b',
            r'\bsimilar\b', r'\brelated\b', r'\bcontinue\b', r'\bfollow\b'
        ]
        
        # Pronouns suggesting reference to previous context
        pronoun_patterns = [
            r'\bthat\b', r'\bthis\b', r'\bthose\b', r'\bthese\b', r'\bit\b',
            r'\bthey\b', r'\bthem\b', r'\btheir\b'
        ]
        
        # Check for follow-up patterns
        for pattern in followup_patterns + pronoun_patterns:
            if re.search(pattern, query_lower):
                return True
        
        # Check if query is very short (likely a follow-up)
        if len(query.split()) <= 3:
            return True
        
        return False
    
    def _find_recent_cache_key(self, collection: str, filters: Dict[str, Any] = None) -> Optional[str]:
        """Find the most recent cache entry for the same collection/filters"""
        recent_key = None
        recent_time = 0
        
        for key, cached_context in self.cache.items():
            if (cached_context.filters_used == (filters or {}) and 
                not self._is_cache_expired(key) and 
                cached_context.timestamp > recent_time):
                recent_key = key
                recent_time = cached_context.timestamp
        
        return recent_key
    
    def _find_similar_cached_query(self, query: str, collection: str, 
                                 filters: Dict[str, Any] = None) -> Optional[str]:
        """Find semantically similar cached queries"""
        normalized_query = self._normalize_query_for_caching(query)
        query_words = set(normalized_query.split())
        
        best_match_key = None
        best_similarity = 0.0
        
        for key, cached_context in self.cache.items():
            if self._is_cache_expired(key):
                continue
            
            cached_normalized = self._normalize_query_for_caching(cached_context.original_query)
            cached_words = set(cached_normalized.split())
            
            # Calculate Jaccard similarity
            intersection = query_words.intersection(cached_words)
            union = query_words.union(cached_words)
            
            if union:
                similarity = len(intersection) / len(union)
                
                # Require at least 60% similarity for cache reuse
                if similarity > 0.6 and similarity > best_similarity:
                    best_similarity = similarity
                    best_match_key = key
        
        return best_match_key
    
    def store_context(self, cache_key: str, context_chunks: List[Dict[str, Any]], 
                     query_embedding_tokens: int, query: str, 
                     filters: Dict[str, Any] = None) -> None:
        """Store context in cache"""
        self.cache[cache_key] = CachedContext(
            context_chunks=context_chunks,
            query_embedding_tokens=query_embedding_tokens,
            filters_used=filters or {},
            timestamp=time.time(),
            original_query=query,
            cache_key=cache_key
        )
        
        # Clean up expired entries
        self._cleanup_expired_cache()
    
    def get_cached_context(self, cache_key: str) -> Optional[CachedContext]:
        """Retrieve cached context"""
        if cache_key in self.cache and not self._is_cache_expired(cache_key):
            return self.cache[cache_key]
        return None
    
    def _is_cache_expired(self, cache_key: str) -> bool:
        """Check if cache entry is expired"""
        if cache_key not in self.cache:
            return True
        
        return (time.time() - self.cache[cache_key].timestamp) > self.cache_ttl
    
    def _cleanup_expired_cache(self) -> None:
        """Remove expired cache entries"""
        current_time = time.time()
        expired_keys = [
            key for key, cached_context in self.cache.items()
            if (current_time - cached_context.timestamp) > self.cache_ttl
        ]
        
        for key in expired_keys:
            del self.cache[key]
    
    def clear_cache(self) -> None:
        """Clear all cached context"""
        self.cache.clear()
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        active_entries = sum(1 for key in self.cache.keys() if not self._is_cache_expired(key))
        
        return {
            "total_entries": len(self.cache),
            "active_entries": active_entries,
            "expired_entries": len(self.cache) - active_entries,
            "cache_ttl_seconds": self.cache_ttl
        }

# Global cache instance
context_cache = ContextCacheManager(cache_ttl=1800)  # 30 minutes