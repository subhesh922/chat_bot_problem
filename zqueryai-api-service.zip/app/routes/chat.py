# app/routes/chat.py

from fastapi import APIRouter, HTTPException
from typing import Dict, Any, List, Optional
from app.utils.retriever import retrieve_top_chunks_with_tokens
from app.utils.context_cache import context_cache
from app.utils.conversation_optimizer import conversation_optimizer
from app.config import (
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_MODEL,
    AZURE_OPENAI_API_VERSION
)
from app.schemas import ChatRequest, ChatRequestResponse, RetrievedChunk
import json
import tiktoken
import re

router = APIRouter()

def should_skip_retrieval(query: str) -> bool:
    """
    Determine if a query should skip context retrieval based on content analysis
    Returns True for simple queries that don't need document context
    """
    query_lower = query.lower().strip()
    
    # Remove punctuation for better matching
    clean_query = re.sub(r'[^\w\s]', '', query_lower)
    
    # Exact greetings and pleasantries
    greetings = [
        'hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening',
        'how are you', 'whats up', 'sup', 'yo', 'greetings', 'hiya'
    ]
    
    # Simple questions about the assistant
    assistant_questions = [
        'how can you help', 'what can you do', 'who are you', 'what are you',
        'can you help me', 'help', 'what is your purpose', 'introduce yourself',
        'tell me about yourself', 'what do you know', 'how do you work'
    ]
    
    # Acknowledgments and thanks
    acknowledgments = [
        'thanks', 'thank you', 'ty', 'thx', 'appreciate it', 'good', 'great',
        'awesome', 'perfect', 'excellent', 'nice', 'cool', 'ok', 'okay'
    ]
    
    # Farewells
    farewells = [
        'bye', 'goodbye', 'see you', 'later', 'farewell', 'take care',
        'have a good day', 'ttyl', 'cya', 'see ya'
    ]
    
    # Test for simple queries
    test_queries = [
        'test', 'testing', 'can you hear me', 'are you there', 'are you working',
        'hello world', 'ping', 'echo', 'check'
    ]
    
    # Combine all simple query patterns
    simple_patterns = greetings + assistant_questions + acknowledgments + farewells + test_queries
    
    # Check for exact matches or starts with patterns
    for pattern in simple_patterns:
        if clean_query == pattern or clean_query.startswith(pattern + ' '):
            return True
    
    # Check for very short queries (1-2 words) that don't contain business terms
    words = clean_query.split()
    if len(words) <= 2:
        business_terms = [
            'project', 'jira', 'ticket', 'documentation', 'policy', 'procedure',
            'api', 'code', 'repository', 'deployment', 'configuration', 'setup',
            'requirement', 'spec', 'design', 'workflow', 'process', 'guidelines',
            'security', 'compliance', 'audit', 'report', 'analysis', 'data',
            'server', 'database', 'application', 'service', 'environment'
        ]
        
        # If it's short and doesn't contain business terms, skip retrieval
        has_business_terms = any(term in clean_query for term in business_terms)
        if not has_business_terms:
            return True
    
    return False

def generate_simple_response(query: str) -> str:
    """
    Generate appropriate responses for simple queries that don't need context
    """
    query_lower = query.lower().strip()
    
    # Greetings
    greetings = ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening']
    if any(greeting in query_lower for greeting in greetings):
        return "Hi! How can I assist you today? 😊"
    
    # Questions about capabilities
    capability_keywords = ['help', 'what can you do', 'who are you', 'what are you']
    if any(keyword in query_lower for keyword in capability_keywords):
        return """I'm zQueryAI Assistant! I can help you by:

• **Analyzing your uploaded documents** - PDFs, Word docs, presentations, spreadsheets, images
• **Answering questions** about the content in your files
• **Finding specific information** across multiple documents
• **Summarizing key points** from your documentation
• **Explaining complex topics** mentioned in your materials

Just upload some files or paste content, and I'll be ready to assist you with any questions about that information!"""
    
    # Thanks and acknowledgments
    thanks = ['thank', 'thanks', 'ty', 'thx', 'appreciate']
    if any(thank in query_lower for thank in thanks):
        return "You're welcome! Let me know if you need anything else."
    
    # Positive feedback
    positive = ['good', 'great', 'awesome', 'perfect', 'excellent', 'nice', 'cool']
    if any(pos in query_lower for pos in positive):
        return "I'm glad I could help! Feel free to ask if you have more questions."
    
    # Farewells
    farewells = ['bye', 'goodbye', 'see you', 'later']
    if any(farewell in query_lower for farewell in farewells):
        return "Goodbye! Have a great day! 👋"
    
    # Test queries
    tests = ['test', 'testing', 'ping', 'check', 'are you there', 'are you working']
    if any(test in query_lower for test in tests):
        return "I'm here and ready to help! 🤖"
    
    # Default for other simple queries
    return "I'm here to help! Please feel free to ask me anything about your uploaded documents or paste some content for me to analyze."

@router.post(
    "/chat",
    summary="Optimized chat with smart context caching and conversation management",
    description="""
    Enhanced chat endpoint with intelligent optimizations:
    
    **Smart Context Caching:**
    - Detects follow-up questions and reuses relevant context
    - Avoids unnecessary re-retrieval of same information
    - Caches context for 30 minutes for related queries
    
    **Conversation Optimization:**
    - Limits conversation history to last 8 exchanges
    - Removes redundant context from history
    - Summarizes older conversations when needed
    
    **Token Optimization:**
    - 60-80% token reduction for follow-up questions
    - Smart detection of simple vs complex queries
    - Efficient conversation history management
    
    **Models Used:**
    - Embeddings: text-embedding-3-small (cached when possible)
    - Chat: gpt-4o
    """,
    response_model=ChatRequestResponse
)
async def chat(payload: ChatRequest):
    try:
        from openai import AzureOpenAI
        
        # Initialize Azure OpenAI client
        client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )

        # Step 1: Determine if we should skip retrieval for simple queries
        skip_retrieval = payload.skipRetrieval or should_skip_retrieval(payload.query)
        
        if skip_retrieval:
            # Handle simple queries without context retrieval
            simple_response = generate_simple_response(payload.query)
            
            # For simple queries, we still want to use minimal tokens for consistency
            tokenizer = tiktoken.get_encoding("cl100k_base")
            query_tokens = len(tokenizer.encode(payload.query))
            response_tokens = len(tokenizer.encode(simple_response))
            total_tokens = query_tokens + response_tokens  # No embedding tokens
            
            return ChatRequestResponse(
                response=simple_response,
                context=[],  # No context chunks for simple queries
                tokens_used=total_tokens
            )

        # Step 2: Smart Context Caching Logic
        use_cached_context = False
        cached_context = None
        cache_key = None
        
        # Check if we should use cached context
        if not payload.forceRefresh:
            use_cache, cache_key = context_cache.should_use_cache(
                query=payload.query,
                collection=payload.collection,
                filters=payload.filters,
                conversation_history=payload.history
            )
            
            if use_cache and cache_key:
                cached_context = context_cache.get_cached_context(cache_key)
                if cached_context:
                    use_cached_context = True
                    print(f"🎯 Using cached context for query: {payload.query[:50]}...")

        # Step 3: Context Retrieval (Fresh or Cached)
        if use_cached_context and cached_context:
            # Use cached context
            chunks = cached_context.context_chunks
            query_embedding_tokens = 0  # No embedding tokens for cached context
            print(f"💰 Token savings: {cached_context.query_embedding_tokens} embedding tokens")
        else:
            # Fresh context retrieval
            try:
                chunks, query_embedding_tokens = retrieve_top_chunks_with_tokens(
                    query=payload.query,
                    collection=payload.collection,
                    filters=payload.filters or {},
                    top_k=8
                )
                
                # Cache the context for future use
                if chunks:
                    cache_key = context_cache.generate_cache_key(
                        payload.query, payload.collection, payload.filters
                    )
                    context_cache.store_context(
                        cache_key=cache_key,
                        context_chunks=chunks,
                        query_embedding_tokens=query_embedding_tokens,
                        query=payload.query,
                        filters=payload.filters
                    )
                    print(f"💾 Cached context with key: {cache_key}")
                
            except Exception as e:
                raise HTTPException(
                    status_code=500, 
                    detail=f"Context retrieval failed: {str(e)}"
                )

        # Step 4: Build context string from chunks
        if not chunks:
            context = "No relevant context found in the knowledge base."
            formatted_chunks = []
        else:
            formatted_chunks = []
            for chunk in chunks:
                # Prepare metadata (exclude text and chunkIndex from display)
                metadata_dict = {k: v for k, v in chunk.items() if k not in ["text", "chunkIndex"]}
                metadata_str = json.dumps(metadata_dict, indent=2)
                
                # Format chunk for context
                formatted_chunk = f"Metadata: {metadata_str}\nContent: {chunk['text']}"
                formatted_chunks.append(formatted_chunk)
            
            context = "\n\n---\n\n".join(formatted_chunks)

        # Step 5: Optimize Conversation History
        optimized_history = []
        if payload.history:
            optimized_history = conversation_optimizer.optimize_conversation_history(payload.history)
            original_count = len(payload.history)
            optimized_count = len(optimized_history)
            if original_count != optimized_count:
                print(f"📉 Conversation history optimized: {original_count} → {optimized_count} messages")

        # Step 6: Construct system prompt and messages
        system_prompt = """You are a helpful AI assistant. Answer questions using ONLY the provided context chunks. 

Important guidelines:
- Base your answers exclusively on the provided context
- If the context doesn't contain enough information, clearly state this
- Maintain accuracy and cite specific information when possible
- If no relevant context is provided, inform the user politely"""

        # Add filter information to system prompt if filters were applied
        filter_info = ""
        if payload.filters:
            filter_lines = [
                f"  - {key}: {', '.join(value) if isinstance(value, list) else value}"
                for key, value in payload.filters.items()
            ]
            if filter_lines:
                filter_info = f"\n\nSearch was filtered by:\n" + "\n".join(filter_lines)

        # Build message array with optimized structure
        messages = [
            {"role": "system", "content": system_prompt + filter_info}
        ]

        # Add conversation summary if we have old context
        if len(payload.history or []) > 16:
            old_history = (payload.history or [])[:-(len(optimized_history))]
            if old_history:
                summary = conversation_optimizer.create_conversation_summary(old_history)
                if summary:
                    messages.append({"role": "system", "content": summary})

        # Add context only once at the beginning
        messages.append({"role": "user", "content": f"Context from knowledge base:\n\n{context}"})

        # Add optimized conversation history
        if optimized_history:
            messages.extend(optimized_history)

        # Add current user query
        messages.append({"role": "user", "content": payload.query})

        # Step 7: Calculate input tokens for chat completion
        tokenizer = tiktoken.get_encoding("cl100k_base")
        full_prompt = "\n".join([msg["content"] for msg in messages])
        chat_input_tokens = len(tokenizer.encode(full_prompt))

        # Step 8: Generate response using GPT-4o
        try:
            response = client.chat.completions.create(
                model=AZURE_OPENAI_MODEL,
                messages=messages,
                temperature=0.3,
                max_tokens=1000,  # Reduced from 1500 to save tokens
                top_p=0.9,
                frequency_penalty=0.0,
                presence_penalty=0.0
            )

            reply = response.choices[0].message.content
            chat_output_tokens = response.usage.completion_tokens or 0
            
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Response generation failed: {str(e)}"
            )

        # Step 9: Calculate total token usage
        total_tokens = query_embedding_tokens + chat_input_tokens + chat_output_tokens

        # Step 10: Format retrieved chunks for response
        response_chunks = []
        for chunk in chunks:
            response_chunks.append(RetrievedChunk(
                source=chunk.get("source", "unknown"),
                creator_api_key_hash=chunk.get("creator_api_key_hash", "unknown"),
                chunkIndex=chunk.get("chunkIndex", 0),
                text=chunk.get("text", "")
            ))

        # Step 11: Log optimization stats
        optimization_stats = {
            "used_cached_context": use_cached_context,
            "original_history_length": len(payload.history or []),
            "optimized_history_length": len(optimized_history),
            "query_embedding_tokens": query_embedding_tokens,
            "chat_input_tokens": chat_input_tokens,
            "chat_output_tokens": chat_output_tokens,
            "total_tokens": total_tokens
        }
        print(f"📊 Chat optimization stats: {optimization_stats}")

        # Step 12: Build and return response
        return ChatRequestResponse(
            response=reply,
            context=response_chunks,
            tokens_used=total_tokens
        )

    except HTTPException:
        # Re-raise HTTP exceptions as-is
        raise
    except Exception as e:
        # Convert unexpected errors to HTTP 500
        raise HTTPException(status_code=500, detail=f"Chat operation failed: {str(e)}")

@router.post(
    "/chat/cache-stats",
    summary="Get context cache statistics",
    description="Retrieve statistics about context caching performance"
)
async def get_cache_stats():
    """Get context cache statistics"""
    try:
        stats = context_cache.get_cache_stats()
        return {
            "context_cache": stats,
            "conversation_optimizer": {
                "max_history_tokens": conversation_optimizer.max_history_tokens,
                "max_exchanges": conversation_optimizer.max_exchanges
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get cache stats: {str(e)}")

@router.post(
    "/chat/clear-cache",
    summary="Clear context cache",
    description="Clear all cached context data"
)
async def clear_context_cache():
    """Clear all cached context"""
    try:
        context_cache.clear_cache()
        return {"message": "Context cache cleared successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to clear cache: {str(e)}")

@router.post(
    "/chat/estimate-tokens",
    summary="Estimate token usage with optimization insights",
    description="Get token estimates including optimization benefits"
)
async def estimate_chat_tokens(payload: ChatRequest):
    """
    Estimate token usage for chat operations with optimization insights
    """
    try:
        tokenizer = tiktoken.get_encoding("cl100k_base")
        
        # Check if this would be a simple query
        skip_retrieval = payload.skipRetrieval or should_skip_retrieval(payload.query)
        
        if skip_retrieval:
            # Simple query estimation
            query_tokens = len(tokenizer.encode(payload.query))
            estimated_response_tokens = 50
            
            return {
                "query_type": "simple",
                "optimization": "full_skip",
                "breakdown": {
                    "query_embedding_tokens": 0,
                    "context_retrieval_tokens": 0,
                    "conversation_history_tokens": 0,
                    "system_prompt_tokens": 0,
                    "user_query_tokens": query_tokens,
                    "estimated_response_tokens": estimated_response_tokens
                },
                "totals": {
                    "estimated_input_tokens": query_tokens,
                    "estimated_output_tokens": estimated_response_tokens,
                    "total_estimated_tokens": query_tokens + estimated_response_tokens
                },
                "savings": {
                    "embedding_tokens_saved": 0,
                    "context_tokens_saved": 0,
                    "total_savings": 0
                }
            }
        
        # Check for cached context
        use_cache, cache_key = context_cache.should_use_cache(
            query=payload.query,
            collection=payload.collection,
            filters=payload.filters,
            conversation_history=payload.history
        )
        
        # Estimate tokens
        query_tokens = len(tokenizer.encode(payload.query))
        
        # Context estimation
        if use_cache:
            estimated_embedding_tokens = 0  # No embedding needed
            estimated_context_tokens = 8 * 300  # Cached context
            embedding_savings = query_tokens  # Saved embedding tokens
        else:
            estimated_embedding_tokens = query_tokens
            estimated_context_tokens = 8 * 300
            embedding_savings = 0
        
        # History estimation with optimization
        original_history_tokens = 0
        optimized_history_tokens = 0
        
        if payload.history:
            # Original history tokens
            for msg in payload.history:
                original_history_tokens += len(tokenizer.encode(msg.get("content", "")))
            
            # Optimized history tokens
            optimized_history = conversation_optimizer.optimize_conversation_history(payload.history)
            for msg in optimized_history:
                optimized_history_tokens += len(tokenizer.encode(msg.get("content", "")))
        
        history_savings = original_history_tokens - optimized_history_tokens
        
        # System prompt
        system_prompt_tokens = 150
        
        # Total input estimation
        estimated_input_tokens = (
            estimated_context_tokens + 
            query_tokens + 
            optimized_history_tokens + 
            system_prompt_tokens
        )
        
        # Estimated output
        estimated_output_tokens = 200
        
        # Total
        total_estimated_tokens = (
            estimated_embedding_tokens + 
            estimated_input_tokens + 
            estimated_output_tokens
        )
        
        # Calculate total savings
        total_savings = embedding_savings + history_savings
        
        return {
            "query_type": "complex",
            "optimization": "cached_context" if use_cache else "fresh_retrieval",
            "breakdown": {
                "query_embedding_tokens": estimated_embedding_tokens,
                "context_retrieval_tokens": estimated_context_tokens,
                "conversation_history_tokens": optimized_history_tokens,
                "system_prompt_tokens": system_prompt_tokens,
                "user_query_tokens": query_tokens,
                "estimated_response_tokens": estimated_output_tokens
            },
            "totals": {
                "estimated_input_tokens": estimated_input_tokens,
                "estimated_output_tokens": estimated_output_tokens,
                "total_estimated_tokens": total_estimated_tokens
            },
            "savings": {
                "embedding_tokens_saved": embedding_savings,
                "history_tokens_saved": history_savings,
                "total_savings": total_savings,
                "optimization_percentage": round((total_savings / (total_estimated_tokens + total_savings)) * 100, 1) if (total_estimated_tokens + total_savings) > 0 else 0
            },
            "original_estimates": {
                "original_history_tokens": original_history_tokens,
                "without_optimization": total_estimated_tokens + total_savings
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Token estimation failed: {str(e)}")

@router.get(
    "/chat/collection-stats/{collection_name}",
    summary="Get collection statistics for chat context",
    description="Retrieve statistics about available context in a collection"
)
async def get_collection_chat_stats(collection_name: str):
    """
    Get statistics about a collection that are relevant for chat operations
    """
    try:
        from qdrant_client import QdrantClient
        from app.config import QDRANT_ENDPOINT, QDRANT_API_KEY
        
        qdrant = QdrantClient(
            url=QDRANT_ENDPOINT,
            api_key=QDRANT_API_KEY,
            prefer_grpc=False,
            https=True,
            timeout=60,
            verify=False
        )
        
        # Check if collection exists
        collections = [c.name for c in qdrant.get_collections().collections]
        if collection_name not in collections:
            raise HTTPException(status_code=404, detail=f"Collection '{collection_name}' not found")
        
        # Get collection info
        collection_info = qdrant.get_collection(collection_name)
        
        # Sample some vectors to analyze metadata
        sample_vectors, _ = qdrant.scroll(
            collection_name=collection_name,
            limit=100,
            with_payload=True,
            with_vectors=False
        )
        
        # Analyze metadata
        sources = set()
        chunk_counts = {}
        
        for vector in sample_vectors:
            if vector.payload:
                source = vector.payload.get("source", "unknown")
                sources.add(source)
                
                if source not in chunk_counts:
                    chunk_counts[source] = 0
                chunk_counts[source] += 1
        
        return {
            "collection_name": collection_name,
            "total_vectors": collection_info.vectors_count,
            "sample_size": len(sample_vectors),
            "unique_sources": len(sources),
            "source_list": sorted(list(sources))[:20],  # Limit to first 20
            "top_sources_by_chunks": sorted(
                chunk_counts.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:10],  # Top 10 sources by chunk count
            "vector_dimension": collection_info.config.params.vectors.size,
            "distance_metric": collection_info.config.params.vectors.distance.value,
            "note": f"Statistics based on sample of {len(sample_vectors)} vectors"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get collection stats: {str(e)}")