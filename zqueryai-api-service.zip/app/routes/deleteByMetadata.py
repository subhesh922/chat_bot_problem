# app/routes/deleteByMetadata.py

from fastapi import APIRouter, HTTPException, Header
from app.schemas import DeleteByMetadata, DeleteByMetadataResponse
import hashlib

from app.config import QDRANT_ENDPOINT, QDRANT_API_KEY
from qdrant_client import QdrantClient
from qdrant_client.http.models import Filter, FieldCondition, MatchValue, FilterSelector

router = APIRouter()

def hash_api_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()

@router.post(
    "/delete-by-metadata",
    summary="Delete vectors from Qdrant collection based on metadata filter",
    response_model=DeleteByMetadataResponse
)
async def delete_by_metadata(
    payload: DeleteByMetadata,
    x_api_key: str = Header(..., description="API key for validating ownership")
):
    try:
        collection = payload.collection
        filter_dict = payload.filter

        # Connect to Qdrant
        qdrant = QdrantClient(
            url=QDRANT_ENDPOINT,
            api_key=QDRANT_API_KEY,
            prefer_grpc=False,
            https=True,
            timeout=60,
            verify=False
        )

        # Validate ownership using creator_api_key_hash
        points, _ = qdrant.scroll(collection_name=collection, limit=1)
        if not points:
            raise HTTPException(status_code=404, detail="Collection is empty or not found.")

        creator_api_key_hash = points[0].payload.get("creator_api_key_hash")
        if not creator_api_key_hash:
            raise HTTPException(status_code=403, detail="Missing creator hash in metadata.")

        hashed_provided_key = hash_api_key(x_api_key)
        if hashed_provided_key != creator_api_key_hash:
            raise HTTPException(status_code=403, detail="API key does not match the creator of this collection.")

        # Build metadata filter
        conditions = [
            FieldCondition(
                key=key,
                match=MatchValue(value=value)
            )
            for key, value in filter_dict.items()
        ]
        qdrant_filter = Filter(must=conditions)

        # Check if any vectors match the filter
        matched_points, _ = qdrant.scroll(
            collection_name=collection,
            scroll_filter=qdrant_filter,
            limit=1
        )
        if not matched_points:
            return {
                "message": f"No vectors found in collection '{collection}' matching metadata: {filter_dict}"
            }

        # Delete matching vectors
        qdrant.delete(
            collection_name=collection,
            points_selector=FilterSelector(filter=qdrant_filter)
        )

        return {
            "message": f"Successfully deleted vectors in collection '{collection}' matching metadata: {filter_dict}"
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
