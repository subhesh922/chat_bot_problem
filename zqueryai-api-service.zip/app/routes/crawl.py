# app/routes/crawl.py

from fastapi import APIRouter, HTTPException, Header
from typing import List, Dict, Any, Optional
import asyncio
import logging
from app.schemas import CrawlLinksRequest, CrawlLinksResponse, CrawledContent
from app.utils.crawlers.url_classifier import url_classifier
from app.utils.crawlers.jira_crawler import jira_crawler
from app.utils.crawlers.confluence_crawler import confluence_crawler
from app.utils.crawlers.html_crawler import html_crawler
from app.utils.embedder import upsert_to_qdrant

router = APIRouter()
logger = logging.getLogger(__name__)

@router.post(
    "/crawl-links",
    summary="Crawl and process discovered links with intelligent routing and custom source mapping",
    description="""
    Crawl links discovered during document extraction and add them to the knowledge base.
    
    **Enhanced Features:**
    - **Custom Source Mapping**: Maps URLs to custom source names (e.g., filenames) for consistent filtering
    - **Intelligent Link Processing**: Routes to specialized crawlers based on URL patterns
    - **JIRA Issues**: Uses JIRA Server REST API to extract structured issue data
    - **Confluence Pages**: Uses Confluence Server REST API + HTML conversion 
    - **Web Pages**: Generic HTML crawling with content extraction and cleaning
    
    **Source Mapping:**
    - Optional `source_mapping` parameter maps URLs to custom source names
    - Enables frontend filtering by filename instead of URL
    - Maintains URL metadata for reference while using friendly display names
    
    **Deduplication:**
    - Automatically deduplicates URLs (removes trailing slashes, normalizes)
    - Each unique URL is crawled only once per request
    - Crawled content includes attribution to all source documents
    
    **Authentication:**
    - JIRA/Confluence: Uses configured bearer tokens for zebra.com instances
    - Web Pages: Standard HTTP requests with appropriate headers
    
    **Content Processing:**
    - Converts all content to clean markdown format
    - Stores in same Qdrant collection as uploaded documents
    - Enables unified search across uploaded files and crawled content
    """,
    response_model=CrawlLinksResponse
)
async def crawl_links(
    payload: CrawlLinksRequest,
    x_api_key: str = Header(..., description="API key for vector ownership and access control")
):
    """
    Main endpoint for crawling discovered links with optional source mapping
    """
    try:
        if not payload.links:
            raise HTTPException(status_code=400, detail="No links provided for crawling")
        
        # Extract source mapping if provided
        source_mapping = getattr(payload, 'source_mapping', None) or {}
        
        # Deduplicate and normalize URLs
        unique_urls = []
        seen_normalized = set()
        url_to_source_map = {}  # Maps URL to its custom source name
        
        for url in payload.links:
            normalized = url_classifier.normalize_url(url)
            if normalized not in seen_normalized and url_classifier.is_crawlable(normalized):
                unique_urls.append(url)  # Keep original URL for crawling
                seen_normalized.add(normalized)
                
                # ✅ Map URL to custom source name if provided
                custom_source = source_mapping.get(url, url)
                url_to_source_map[url] = custom_source
        
        if not unique_urls:
            raise HTTPException(status_code=400, detail="No crawlable links found after deduplication")
        
        logger.info(f"Crawling {len(unique_urls)} unique URLs from {len(payload.links)} total links")
        if source_mapping:
            logger.info(f"Using custom source mapping for {len(source_mapping)} URLs")
        
        # Process all URLs concurrently (but with reasonable limits)
        max_concurrent = min(5, len(unique_urls))  # Limit concurrent requests
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def crawl_single_url(url: str) -> CrawledContent:
            async with semaphore:
                # ✅ Pass the custom source name to the crawler
                custom_source = url_to_source_map.get(url, url)
                return await _crawl_url(url, custom_source)
        
        # Execute crawling tasks
        crawl_tasks = [crawl_single_url(url) for url in unique_urls]
        results = await asyncio.gather(*crawl_tasks, return_exceptions=True)
        
        # Process results and handle any exceptions
        crawled_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                url = unique_urls[i]
                custom_source = url_to_source_map.get(url, url)
                logger.error(f"Crawling failed for {url}: {result}")
                crawled_results.append(CrawledContent(
                    url=url,
                    success=False,
                    content_type="error",
                    markdown=f"<!-- Crawling failed: {str(result)} -->",
                    metadata={
                        "error": str(result),
                        "custom_source": custom_source,
                        "original_url": url
                    },
                    tokens_used=0,
                    error_message=str(result)
                ))
            else:
                crawled_results.append(result)
        
        # Upsert successful results to Qdrant with custom source names
        successful_results = [r for r in crawled_results if r.success]
        total_upsert_tokens = 0
        
        if successful_results:
            total_upsert_tokens = await _upsert_crawled_content(
                successful_results, 
                payload.collection, 
                payload.session_id,
                x_api_key,
                url_to_source_map  # ✅ Pass source mapping to upsert function
            )
        
        # Generate summary statistics
        summary = _generate_crawl_summary(crawled_results, total_upsert_tokens)
        
        return CrawlLinksResponse(
            status="crawling_complete",
            results=crawled_results,
            summary=summary
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Crawl links operation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Crawling operation failed: {str(e)}")

async def _crawl_url(url: str, custom_source: str = None) -> CrawledContent:
    """
    Crawl a single URL using the appropriate crawler
    
    Args:
        url: The URL to crawl
        custom_source: Optional custom source name to use instead of URL
    """
    try:
        # Classify the URL to determine crawler
        classification = url_classifier.classify_url(url)
        crawler_type = classification["crawler"]
        url_type = classification["type"]
        metadata = classification["metadata"]
        
        # ✅ Add custom source information to metadata
        metadata.update({
            "original_url": url,
            "custom_source": custom_source or url,
            "source_mapped": custom_source is not None
        })
        
        logger.info(f"Crawling {url} using {crawler_type} (detected as {url_type})")
        if custom_source and custom_source != url:
            logger.info(f"Using custom source name: {custom_source}")
        
        # Route to appropriate crawler
        if crawler_type == "jira_api":
            issue_key = metadata.get("issue_key")
            base_url = metadata.get("base_url")
            
            if not issue_key:
                return CrawledContent(
                    url=url,
                    success=False,
                    content_type="error",
                    markdown="<!-- Could not extract JIRA issue key from URL -->",
                    metadata=metadata,
                    tokens_used=0,
                    error_message="Could not extract JIRA issue key"
                )
            
            try:
                result = await jira_crawler.crawl_issue(
                    issue_key=issue_key,
                    base_url=base_url,
                    include_linked=True,
                    max_depth=1
                )
                
                # ✅ Log linked issues info if available
                if result.get("linked_issues"):
                    linked_count = len(result["linked_issues"])
                    logger.info(f"Crawled JIRA issue {issue_key} with {linked_count} linked issues")
                
            except Exception as jira_error:
                logger.error(f"JIRA crawler failed for {issue_key}: {jira_error}")
                # Fallback to HTML crawling if JIRA API fails
                logger.info(f"Falling back to HTML crawling for {url}")
                result = await html_crawler.crawl_page(url)
                # Update metadata to reflect the fallback
                metadata.update({
                    "crawl_method": "html_fallback",
                    "jira_api_error": str(jira_error)
                })
            
        elif crawler_type == "confluence_api":
            result = await confluence_crawler.crawl_page(url, metadata)
            
        elif crawler_type == "html_crawler":
            result = await html_crawler.crawl_page(url)
            
        else:
            return CrawledContent(
                url=url,
                success=False,
                content_type="error",
                markdown="<!-- Unknown crawler type -->",
                metadata={**metadata, "error": f"Unknown crawler type: {crawler_type}"},
                tokens_used=0,
                error_message=f"Unknown crawler type: {crawler_type}"
            )
        
        # Convert crawler result to CrawledContent with enhanced metadata
        enhanced_metadata = {**metadata, **result["metadata"]}
        
        return CrawledContent(
            url=url,
            success=result["success"],
            content_type=url_type,
            markdown=result["markdown"],
            metadata=enhanced_metadata,
            tokens_used=result["tokens_used"],
            error_message=result.get("error_message")
        )
        
    except Exception as e:
        logger.error(f"Error crawling URL {url}: {e}")
        return CrawledContent(
            url=url,
            success=False,
            content_type="error",
            markdown=f"<!-- Crawling error: {str(e)} -->",
            metadata={
                "error": str(e),
                "original_url": url,
                "custom_source": custom_source or url
            },
            tokens_used=0,
            error_message=str(e)
        )

async def _upsert_crawled_content(
    successful_results: List[CrawledContent], 
    collection: str,
    session_id: str,
    api_key: str,
    url_to_source_map: Dict[str, str] = None
) -> int:
    """
    Upsert crawled content to Qdrant with custom source names and return total tokens used
    
    Args:
        successful_results: List of successfully crawled content
        collection: Qdrant collection name
        session_id: Session ID for tracking
        api_key: API key for authentication
        url_to_source_map: Optional mapping of URLs to custom source names
    """
    total_tokens = 0
    url_to_source_map = url_to_source_map or {}
    
    try:
        for result in successful_results:
            # ✅ Use custom source name if available, otherwise use URL
            source_name = url_to_source_map.get(result.url, result.url)
            
            # Prepare metadata for Qdrant storage
            upsert_metadata = {
                "source": source_name,  # ✅ Use custom source name for filtering
                "original_url": result.url,  # Keep original URL as metadata
                "source_type": "crawled_link",
                "content_type": result.content_type,
                "session_id": session_id,
                **result.metadata
            }
            
            # Remove any None values from metadata
            upsert_metadata = {k: v for k, v in upsert_metadata.items() if v is not None}
            
            logger.info(f"Upserting content with source: {source_name} (original URL: {result.url})")
            
            # Upsert to Qdrant using existing embedder
            upsert_result = await upsert_to_qdrant(
                markdown=result.markdown,
                metadata=upsert_metadata,
                collection_name=collection,
                api_key=api_key
            )
            
            total_tokens += upsert_result.get("tokens_used", 0)
            logger.info(f"Upserted crawled content from {result.url} as '{source_name}' - {upsert_result.get('chunks', 0)} chunks")
        
    except Exception as e:
        logger.error(f"Error upserting crawled content: {e}")
        # Don't fail the entire operation if upsert fails
    
    return total_tokens

def _generate_crawl_summary(results: List[CrawledContent], upsert_tokens: int) -> Dict[str, Any]:
    """Enhanced summary with linked issues info"""
    total_urls = len(results)
    successful = len([r for r in results if r.success])
    failed = total_urls - successful
    
    # Count by content type
    content_types = {}
    total_crawl_tokens = 0
    total_linked_issues = 0
    
    for result in results:
        content_type = result.content_type
        content_types[content_type] = content_types.get(content_type, 0) + 1
        total_crawl_tokens += result.tokens_used
        
        # ✅ Count linked issues if available
        if "linked_issues_count" in result.metadata:
            total_linked_issues += result.metadata["linked_issues_count"]
    
    summary = {
        "total_urls": total_urls,
        "successful": successful,
        "failed": failed,
        "jira_issues": content_types.get("jira_issue", 0),
        "confluence_pages": content_types.get("confluence_page", 0),  
        "html_pages": content_types.get("html_page", 0),
        "crawl_tokens_used": total_crawl_tokens,
        "upsert_tokens_used": upsert_tokens,
        "total_tokens_used": total_crawl_tokens + upsert_tokens,
        "content_stored": successful > 0,
        "total_linked_issues": total_linked_issues  # ✅ New field
    }
    
    return summary