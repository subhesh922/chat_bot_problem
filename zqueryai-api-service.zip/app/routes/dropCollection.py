# app/routes/dropCollection.py

from fastapi import APIRouter, HTTPException, Header
from app.schemas import DropCollection, DropCollectionResponse
from app.config import QDRANT_ENDPOINT, QDRANT_API_KEY
import hashlib

router = APIRouter()


def hash_api_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


# 🚮 Collection deletion function
def drop_collection(collection_name: str) -> dict:
    try:
        from qdrant_client import QdrantClient
        qdrant = QdrantClient(
            url=QDRANT_ENDPOINT,
            api_key=QDRANT_API_KEY,
            prefer_grpc=False,
            https=True,
            timeout=60,
            verify=False
        )
        qdrant.delete_collection(collection_name=collection_name)
        return {
            "message": f"✅ Collection '{collection_name}' deleted successfully."
        }
    except Exception as e:
        return {
            "message": f"❌ Failed to delete collection '{collection_name}'.",
            "error": str(e)
        }


@router.post(
    "/drop-collection",
    summary="Drop a Qdrant collection with API key validation",
    response_model=DropCollectionResponse
)
async def drop_collection_route(
    payload: DropCollection,
    x_api_key: str = Header(..., description="API key used to validate ownership of the collection")
):
    collection_name = payload.collection

    from qdrant_client import QdrantClient
    qdrant = QdrantClient(
        url=QDRANT_ENDPOINT,
        api_key=QDRANT_API_KEY,
        prefer_grpc=False,
        https=True,
        timeout=60,
        verify=False
    )

    try:
        # Fetch one point from the collection to read creator metadata
        points, _ = qdrant.scroll(collection_name=collection_name, limit=1)

        if not points:
            raise HTTPException(status_code=404, detail="Collection is empty or not found.")

        creator_api_key_hash = points[0].payload.get("creator_api_key_hash")
        if creator_api_key_hash is None:
            raise HTTPException(status_code=403, detail="No creator API key hash found in the collection.")

        hashed_provided_api_key = hash_api_key(x_api_key)
        if creator_api_key_hash != hashed_provided_api_key:
            raise HTTPException(status_code=403, detail="API key does not match the collection creator's key.")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    result = drop_collection(collection_name)

    if "error" in result:
        raise HTTPException(status_code=400, detail=result["message"])

    return result
