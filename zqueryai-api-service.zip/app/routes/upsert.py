# app/routes/upsert.py

from fastapi import APIRouter, HTTPException, Body, Header
from fastapi.responses import JSONResponse
from typing import Union, List
from app.schemas import (
    UpsertPayload,
    BatchUpsertPayload,
    UpsertPayloadResponse,
    BatchUpsertResponse,
    UpsertResponse
)
from app.utils.embedder import upsert_to_qdrant, batch_upsert_to_qdrant
import asyncio

router = APIRouter()

@router.post(
    "/upsert",
    summary="Upsert documents to Qdrant with comprehensive token tracking",
    description="""
    Process and upsert markdown documents to Qdrant vector database.
    
    **Single Document Upsert:**
    - Processes one markdown document
    - Chunks content intelligently based on token limits
    - Generates embeddings using text-embedding-3-small
    - Returns detailed token usage information
    
    **Batch Document Upsert:**
    - Processes multiple documents in parallel
    - Aggregates token usage across all documents
    - Provides individual results plus total summary
    
    **Token Usage:**
    - Uses text-embedding-3-small model for embeddings
    - Tracks tokens for each chunk embedding operation
    - Returns total tokens consumed for the operation
    
    **Authentication:**
    - Requires X-API-Key header for ownership tracking
    - API key is hashed and stored with vectors for access control
    """,
    response_model=Union[UpsertPayloadResponse, BatchUpsertResponse]
)
async def upsert(
    payload: Union[UpsertPayload, BatchUpsertPayload] = Body(...),
    x_api_key: str = Header(
        ..., 
        description="API key for vector ownership and access control",
        example="your-api-key-here"
    )
):
    try:
        # ✅ Determine if this is a batch or single upsert
        is_batch = hasattr(payload, "documents")
        
        if is_batch:
            # **BATCH UPSERT PROCESSING**
            batch_payload = payload
            
            # Validate batch payload
            if not batch_payload.documents:
                raise HTTPException(
                    status_code=400, 
                    detail="Batch payload must contain at least one document"
                )
            
            # Prepare documents for batch processing
            documents_to_process = []
            for doc in batch_payload.documents:
                # Merge global metadata with document-specific metadata
                merged_metadata = {
                    **(batch_payload.metadata or {}),
                    **(doc.metadata or {})
                }
                
                documents_to_process.append({
                    "markdown": doc.markdown,
                    "metadata": merged_metadata
                })
            
            # Process batch in parallel
            results = await batch_upsert_to_qdrant(
                documents=documents_to_process,
                collection_name=batch_payload.collection,
                api_key=x_api_key,
                global_metadata=batch_payload.metadata
            )
            
            # Calculate total tokens used across all documents
            total_tokens_used = sum(result["tokens_used"] for result in results)
            
            # Format individual results for response
            formatted_results = []
            for result in results:
                formatted_results.append(UpsertResponse(
                    message=result["message"],
                    collection=result["collection"],
                    chunks=result["chunks"],
                    metadata=result["metadata"],
                    tokens_used=result["tokens_used"]
                ))
            
            return BatchUpsertResponse(
                status="batch upsert complete",
                results=formatted_results,
                total_tokens_used=total_tokens_used
            )
        
        else:
            # **SINGLE UPSERT PROCESSING**
            single_payload = payload
            
            # Validate single payload
            if not single_payload.markdown.strip():
                raise HTTPException(
                    status_code=400,
                    detail="Markdown content cannot be empty"
                )
            
            # Process single document
            result = await upsert_to_qdrant(
                markdown=single_payload.markdown,
                metadata=single_payload.metadata or {},
                collection_name=single_payload.collection,
                api_key=x_api_key
            )
            
            # Format result for response
            formatted_result = UpsertResponse(
                message=result["message"],
                collection=result["collection"],
                chunks=result["chunks"],
                metadata=result["metadata"],
                tokens_used=result["tokens_used"]
            )
            
            return UpsertPayloadResponse(
                status="single upsert complete",
                result=formatted_result
            )

    except HTTPException:
        # Re-raise HTTP exceptions as-is
        raise
    except Exception as e:
        # Convert other exceptions to HTTP 500
        raise HTTPException(status_code=500, detail=f"Upsert operation failed: {str(e)}")

@router.post(
    "/upsert/estimate-tokens",
    summary="Estimate token usage for upsert operation",
    description="Get an estimate of tokens that would be consumed by an upsert operation"
)
async def estimate_upsert_tokens(
    payload: Union[UpsertPayload, BatchUpsertPayload] = Body(...),
    x_api_key: str = Header(..., description="API key for estimation context")
):
    """
    Estimate token usage for upsert operations without actually processing
    """
    try:
        import tiktoken
        tokenizer = tiktoken.get_encoding("cl100k_base")
        
        is_batch = hasattr(payload, "documents")
        
        if is_batch:
            # Estimate for batch operation
            estimates = []
            total_estimated_tokens = 0
            
            for i, doc in enumerate(payload.documents):
                markdown = doc.markdown
                token_count = len(tokenizer.encode(markdown))
                
                # Estimate chunks (assuming 400 tokens per chunk with 25 overlap)
                estimated_chunks = max(1, (token_count + 375 - 25) // 375)  # Ceiling division
                estimated_tokens = token_count  # Embedding tokens ≈ input tokens
                
                estimates.append({
                    "document_index": i,
                    "estimated_chunks": estimated_chunks,
                    "estimated_tokens": estimated_tokens,
                    "input_token_count": token_count
                })
                
                total_estimated_tokens += estimated_tokens
            
            return {
                "operation_type": "batch_upsert",
                "total_documents": len(payload.documents),
                "estimates": estimates,
                "total_estimated_tokens": total_estimated_tokens,
                "model_used": "text-embedding-3-small",
                "note": "Estimates are approximate. Actual usage may vary."
            }
        
        else:
            # Estimate for single operation
            markdown = payload.markdown
            token_count = len(tokenizer.encode(markdown))
            estimated_chunks = max(1, (token_count + 375 - 25) // 375)
            estimated_tokens = token_count
            
            return {
                "operation_type": "single_upsert",
                "estimated_chunks": estimated_chunks,
                "estimated_tokens": estimated_tokens,
                "input_token_count": token_count,
                "model_used": "text-embedding-3-small",
                "note": "Estimates are approximate. Actual usage may vary."
            }
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Token estimation failed: {str(e)}")

@router.get(
    "/upsert/collection-info/{collection_name}",
    summary="Get information about a collection",
    description="Retrieve metadata and statistics about a specific collection"
)
async def get_collection_info(
    collection_name: str,
    x_api_key: str = Header(..., description="API key for access verification")
):
    """
    Get detailed information about a collection including vector count and metadata
    """
    try:
        from qdrant_client import QdrantClient
        from app.config import QDRANT_ENDPOINT, QDRANT_API_KEY
        from app.utils.embedder import hash_api_key
        
        qdrant = QdrantClient(
            url=QDRANT_ENDPOINT,
            api_key=QDRANT_API_KEY,
            prefer_grpc=False,
            https=True,
            timeout=60,
            verify=False
        )
        
        # Check if collection exists
        collections = [c.name for c in qdrant.get_collections().collections]
        if collection_name not in collections:
            raise HTTPException(status_code=404, detail=f"Collection '{collection_name}' not found")
        
        # Get collection info
        collection_info = qdrant.get_collection(collection_name)
        
        # Get user's vectors (filter by API key hash)
        user_api_key_hash = hash_api_key(x_api_key)
        
        # Count user's vectors
        from qdrant_client.http.models import Filter, FieldCondition, MatchValue
        user_filter = Filter(
            must=[FieldCondition(key="creator_api_key_hash", match=MatchValue(value=user_api_key_hash))]
        )
        
        user_vectors = qdrant.scroll(
            collection_name=collection_name,
            scroll_filter=user_filter,
            limit=1,
            with_payload=False,
            with_vectors=False
        )[1]  # Get count only
        
        return {
            "collection_name": collection_name,
            "total_vectors": collection_info.vectors_count,
            "your_vectors": len(user_vectors) if user_vectors else 0,
            "vector_size": collection_info.config.params.vectors.size,
            "distance_metric": collection_info.config.params.vectors.distance.value,
            "indexed": collection_info.status.value == "green",
            "your_api_key_hash": user_api_key_hash
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get collection info: {str(e)}")