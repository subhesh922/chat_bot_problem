# app/routes/extract.py

import io
from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
from app.schemas import ExtractedDocument, ExtractResponse, LinksSummary
from app.utils.extractors import extract_file_as_markdown_with_tokens
from app.utils.extractors.link_extractor import link_extractor

router = APIRouter()

# File size limits
MAX_FILE_SIZE_MB = 50
MAX_TOTAL_SIZE_MB = 200
MAX_FILE_SIZE = MAX_FILE_SIZE_MB * 1024 * 1024
MAX_TOTAL_SIZE = MAX_TOTAL_SIZE_MB * 1024 * 1024

@router.post(
    "/extract",
    summary="Extract content from uploaded files with comprehensive token tracking and link detection",
    description="""
    Extracts Markdown content from uploaded files with full token usage tracking and hyperlink detection.
    
    **Supported file types:**
    - **Images**: PNG, JPG, JPEG (uses Azure Vision OCR)
    - **Documents**: PDF, PPTX, XLSX, DOCX (may use OCR for embedded images + link extraction)
    - **Text**: TXT, CSV files (no OCR needed)
    
    **Token usage:**
    - OCR operations consume tokens when processing images
    - Non-image content extraction returns 0 tokens
    - Embedded images in documents are processed with OCR
    
    **Link extraction:**
    - PDF: Extracts hyperlink annotations and explicit URLs
    - DOCX: Extracts document hyperlinks and explicit URLs  
    - PPTX: Extracts slide hyperlinks and explicit URLs
    - Other formats: Limited or no link extraction
    
    **Limits:**
    - Max file size: 50MB per file
    - Max total upload: 200MB per request
    """,
    response_model=ExtractResponse
)
async def extract_files(
    files: List[UploadFile] = File(
        ..., 
        description="Upload PDF, PPTX, XLSX, DOCX, PNG, JPG, JPEG, CSV, or TXT files"
    )
):
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded.")

    extracted_content = []
    total_size = 0
    total_tokens_used = 0
    documents_with_links = []

    for file in files:
        # Read file contents
        try:
            contents = await file.read()
            file_size = len(contents)
        except Exception as e:
            raise HTTPException(
                status_code=400, 
                detail=f"Failed to read file '{file.filename}': {str(e)}"
            )

        # Check individual file size limit
        if file_size > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=413, 
                detail=f"File '{file.filename}' ({file_size / (1024*1024):.1f}MB) exceeds {MAX_FILE_SIZE_MB}MB limit."
            )
        
        # Check total upload size limit
        total_size += file_size
        if total_size > MAX_TOTAL_SIZE:
            raise HTTPException(
                status_code=413, 
                detail=f"Total upload size ({total_size / (1024*1024):.1f}MB) exceeds {MAX_TOTAL_SIZE_MB}MB limit."
            )

        # Rewrap file for downstream processing
        file.file = io.BytesIO(contents)

        # Process file using appropriate extractor with token tracking and link detection
        try:
            extraction_result = await extract_file_as_markdown_with_tokens(file)
            markdown = extraction_result["markdown"]
            file_tokens = extraction_result["tokens_used"]
            file_links = extraction_result.get("links", [])
        except Exception as e:
            # Fallback on extraction error
            markdown = f"<!-- Extraction failed for {file.filename}: {str(e)} -->"
            file_tokens = 0
            file_links = []

        # Create document object
        document = {
            "markdown": (markdown or "").strip(),
            "metadata": {"source": file.filename or "unknown"},
            "links": file_links
        }

        # Add to results
        extracted_content.append(document)
        documents_with_links.append(document)
        total_tokens_used += file_tokens

    # Create links summary across all documents
    links_summary = None
    if documents_with_links:
        summary_data = link_extractor.create_links_summary(documents_with_links)
        if summary_data["total_links"] > 0:
            links_summary = LinksSummary(**summary_data)

    # Build response
    response_data = {
        "documents": extracted_content,
        "tokens_used": total_tokens_used
    }

    # Add links summary if links were found
    if links_summary:
        response_data["links_summary"] = links_summary

    return response_data

@router.get(
    "/extract/supported-formats",
    summary="Get list of supported file formats",
    description="Returns information about supported file formats and their processing methods"
)
async def get_supported_formats():
    """
    Get comprehensive information about supported file formats
    """
    from app.utils.extractors import get_supported_formats
    return get_supported_formats()

@router.post(
    "/extract/estimate-tokens",
    summary="Estimate token usage for files before processing",
    description="Get an estimate of token usage without actually processing the files"
)
async def estimate_extraction_tokens(
    files: List[UploadFile] = File(..., description="Files to estimate token usage for")
):
    """
    Provide token usage estimates based on file types and sizes
    """
    from app.utils.extractors import get_extractor_info
    
    estimates = []
    total_estimated_tokens = 0
    total_estimated_links = 0
    
    for file in files:
        try:
            # Get file info
            contents = await file.read()
            file_size = len(contents)
            
            # Get extractor info
            extractor_info = get_extractor_info(file.filename or "unknown")
            
            # Estimate tokens based on file type and size
            if extractor_info["expected_token_usage"] == "High (OCR processing)":
                # Image files - estimate based on size
                if file_size < 100_000:  # < 100KB
                    estimated_tokens = 50
                elif file_size < 500_000:  # < 500KB
                    estimated_tokens = 150
                elif file_size < 2_000_000:  # < 2MB
                    estimated_tokens = 300
                else:
                    estimated_tokens = 500
            elif extractor_info["expected_token_usage"] == "Low (potential embedded images)":
                # Document files - conservative estimate for potential embedded images
                estimated_tokens = 20
            else:
                # Text-only files
                estimated_tokens = 0
            
            # Estimate potential links based on file type
            estimated_links = 0
            if extractor_info["link_extraction_enabled"]:
                # Conservative estimate based on file size and type
                if file_size > 50_000:  # Larger files likely have more links
                    estimated_links = 3
                elif file_size > 10_000:
                    estimated_links = 1
                    
            estimates.append({
                "filename": file.filename,
                "file_size_bytes": file_size,
                "estimated_tokens": estimated_tokens,
                "estimated_links": estimated_links,
                "extractor_type": extractor_info["extractor_function"],
                "processing_description": extractor_info["expected_token_usage"],
                "link_extraction_description": extractor_info["expected_link_extraction"]
            })
            
            total_estimated_tokens += estimated_tokens
            total_estimated_links += estimated_links
            
        except Exception as e:
            estimates.append({
                "filename": file.filename,
                "error": f"Failed to analyze file: {str(e)}",
                "estimated_tokens": 0,
                "estimated_links": 0
            })
    
    return {
        "file_estimates": estimates,
        "total_estimated_tokens": total_estimated_tokens,
        "total_estimated_links": total_estimated_links,
        "note": "These are estimates only. Actual token usage and link count may vary based on content complexity and number of embedded images/links."
    }